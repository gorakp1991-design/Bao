import { useEffect, useMemo, useState } from "react";
import { QUESTIONS } from "@/data/quizzes";
import { CanvasStage } from "@/components/3d/canvas-stage";
import { BiologyModel } from "@/components/3d/model-registry";
import { useAppStore } from "@/store/app-store";
import { useProgress } from "@/store/progress-store";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { QuizQuestion } from "@/data/types";
import { cn } from "@/lib/utils";

export function QuizEngine({ topic }: { topic?: string }) {
  const level = useAppStore((s) => s.classLevel);
  const selected = useAppStore((s) => s.selectedPart);
  const selectPart = useAppStore((s) => s.selectPart);
  const setTopic = useAppStore((s) => s.setTopic);
  const addQuiz = useProgress((s) => s.addQuiz);
  const bank = useMemo(() => {
    const pool = QUESTIONS.filter((q) => q.level <= level + 1 && (!topic || q.topic === topic || topic === "mixed"));
    return (pool.length ? pool : QUESTIONS).slice(0, 8);
  }, [level, topic]);
  const [i, setI] = useState(0);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const [picked, setPicked] = useState<string[]>([]);
  const [status, setStatus] = useState<"idle" | "correct" | "wrong">("idle");
  const [started] = useState(() => Date.now());
  const q = bank[i];

  if (!q) return <p className="p-6 text-fg-muted">No questions for this filter.</p>;

  const submit = (value: string | string[]) => {
    if (status !== "idle") return;
    const ok = Array.isArray(q.answer) ? arraysEqual(value as string[], q.answer) : (value as string) === q.answer;
    setStatus(ok ? "correct" : "wrong");
    if (ok) setScore((s) => s + 1);
  };

  const next = () => {
    const finished = i + 1 >= bank.length;
    const finalScore = score + (status === "correct" ? 0 : 0);
    if (finished) {
      setDone(true);
      addQuiz({
        id: `run-${started}`,
        score: finalScore,
        total: bank.length,
        at: Date.now(),
        topic: topic ?? "mixed",
      });
      return;
    }
    setI((n) => n + 1);
    setPicked([]);
    setStatus("idle");
    selectPart(null);
  };

  if (done) {
    return (
      <div className="mx-auto max-w-lg p-6 text-center">
        <p className="font-mono text-xs tracking-[0.2em] text-accent">SESSION COMPLETE</p>
        <h2 className="mt-2 font-display text-3xl">
          {score}/{bank.length}
        </h2>
        <p className="mt-2 text-sm text-fg-muted">
          Accuracy {Math.round((score / bank.length) * 100)}% · {Math.round((Date.now() - started) / 1000)}s
        </p>
        <Button
          className="mt-6"
          onClick={() => {
            setI(0);
            setScore(0);
            setDone(false);
            setStatus("idle");
          }}
        >
          Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="mx-auto grid max-w-5xl gap-6 p-4 md:grid-cols-[1.1fr_0.9fr]">
      <div>
        <div className="mb-3 flex items-center gap-2">
          <Badge tone="accent">
            {i + 1}/{bank.length}
          </Badge>
          <Badge>{q.kind}</Badge>
          <span className="ml-auto font-mono text-xs text-fg-subtle">Score {score}</span>
        </div>
        <h2 className="font-display text-2xl">{q.prompt}</h2>
        {q.kind === "mcq" || q.kind === "tf" ? (
          <div className="mt-4 grid gap-2">
            {q.options?.map((opt) => (
              <button
                key={opt}
                type="button"
                disabled={status !== "idle"}
                onClick={() => submit(opt)}
                className={cn(
                  "min-h-11 rounded-xl border border-border px-4 py-3 text-left text-sm hover:bg-surface-2",
                  status !== "idle" && opt === q.answer && "border-accent bg-accent/10",
                )}
              >
                {opt}
              </button>
            ))}
          </div>
        ) : null}
        {q.kind === "sequence" ? (
          <SequenceQuestion q={q} picked={picked} setPicked={setPicked} status={status} onSubmit={submit} />
        ) : null}
        {q.kind === "hotspot" ? (
          <p className="mt-3 text-sm text-fg-muted">Select the structure in the 3D viewport, then confirm.</p>
        ) : null}
        {status !== "idle" ? (
          <div className="mt-4 rounded-xl border border-border bg-surface-2 p-4 text-sm text-fg-muted">
            <p className={status === "correct" ? "text-accent" : "text-danger"}>{status === "correct" ? "Correct" : "Not quite"}</p>
            <p className="mt-1">{q.explain}</p>
            <Button className="mt-3" onClick={next}>
              {i + 1 >= bank.length ? "See results" : "Next"}
            </Button>
          </div>
        ) : q.kind === "hotspot" ? (
          <Button
            className="mt-4"
            onClick={() => {
              if (selected) submit(selected);
            }}
          >
            Confirm selection {selected ? `(${selected})` : ""}
          </Button>
        ) : null}
      </div>
      {q.kind === "hotspot" ? (
        <div className="h-[360px] overflow-hidden rounded-2xl border border-border">
          <HotspotStage topic={q.hotspotTarget === "left-ventricle" ? "heart" : "animal-cell"} onReady={setTopic} />
        </div>
      ) : (
        <aside className="rounded-2xl border border-border bg-surface p-5 text-sm text-fg-muted">
          <p className="font-mono text-[10px] tracking-[0.2em] text-fg-subtle">HINT</p>
          <p className="mt-2">Use the 3D lab if you want to inspect the structure before answering. Weak topics are tracked on the dashboard.</p>
        </aside>
      )}
    </div>
  );
}

function HotspotStage({ topic, onReady }: { topic: string; onReady: (id: string) => void }) {
  useEffect(() => {
    onReady(topic);
  }, [topic, onReady]);
  return (
    <CanvasStage>
      <BiologyModel topicId={topic} />
    </CanvasStage>
  );
}

function SequenceQuestion({
  q,
  picked,
  setPicked,
  status,
  onSubmit,
}: {
  q: QuizQuestion;
  picked: string[];
  setPicked: (v: string[]) => void;
  status: string;
  onSubmit: (v: string[]) => void;
}) {
  const remaining = (q.options ?? []).filter((o) => !picked.includes(o));
  return (
    <div className="mt-4 space-y-3">
      <div className="flex flex-wrap gap-2">
        {picked.map((p) => (
          <span key={p} className="rounded-full bg-accent/15 px-3 py-1 text-sm text-accent">
            {p}
          </span>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        {remaining.map((o) => (
          <Button key={o} variant="secondary" size="sm" disabled={status !== "idle"} onClick={() => setPicked([...picked, o])}>
            {o}
          </Button>
        ))}
      </div>
      {picked.length === (q.options?.length ?? 0) && status === "idle" ? (
        <Button onClick={() => onSubmit(picked)}>Check order</Button>
      ) : null}
    </div>
  );
}

function arraysEqual(a: string[], b: string[]) {
  return a.length === b.length && a.every((v, i) => v === b[i]);
}
