import { Pause, Play, RotateCcw, FastForward, Rewind } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAppStore } from "@/store/app-store";
import { getProcess, stageAt } from "@/data/processes";
import { usePlayback } from "@/hooks/use-media";
import type { Speed } from "@/data/types";
import { cn } from "@/lib/utils";

const SPEEDS: Speed[] = [0.25, 0.5, 1, 2, 4];

export function Timeline({ processId }: { processId: string }) {
  const process = getProcess(processId);
  usePlayback(process.duration);
  const progress = useAppStore((s) => s.progress);
  const playing = useAppStore((s) => s.playing);
  const speed = useAppStore((s) => s.speed);
  const setPlaying = useAppStore((s) => s.setPlaying);
  const setProgress = useAppStore((s) => s.setProgress);
  const setSpeed = useAppStore((s) => s.setSpeed);
  const stage = stageAt(process, progress);

  return (
    <div className="glass rounded-xl p-3 md:p-4">
      <div className="mb-2 flex items-center justify-between gap-3">
        <div>
          <p className="font-mono text-[10px] tracking-[0.22em] text-fg-subtle">4D TIMELINE</p>
          <p className="text-sm text-fg">{stage.name}</p>
        </div>
        <p className="font-mono text-xs tabular-nums text-fg-muted">{(progress * process.duration).toFixed(1)}s</p>
      </div>
      <input
        type="range"
        min={0}
        max={1000}
        value={Math.round(progress * 1000)}
        aria-label="Scrub simulation timeline"
        onChange={(e) => {
          setPlaying(false);
          setProgress(Number(e.target.value) / 1000);
        }}
        className="h-2 w-full cursor-pointer appearance-none rounded-full bg-surface-3 accent-accent"
      />
      <div className="mt-1 flex justify-between text-[10px] text-fg-subtle">
        {process.stages.map((s) => (
          <button
            key={s.id}
            type="button"
            className={cn("truncate px-0.5", s.id === stage.id ? "text-accent" : "")}
            onClick={() => setProgress(s.start + 0.01)}
          >
            {s.name}
          </button>
        ))}
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Button size="icon" variant="secondary" aria-label="Rewind" onClick={() => setProgress(Math.max(0, progress - 0.08))}>
          <Rewind className="size-4" />
        </Button>
        <Button
          size="icon"
          aria-label={playing ? "Pause" : "Play"}
          onClick={() => {
            if (progress >= 1) setProgress(0);
            setPlaying(!playing);
          }}
        >
          {playing ? <Pause className="size-4" /> : <Play className="size-4 ml-0.5" />}
        </Button>
        <Button size="icon" variant="secondary" aria-label="Reset" onClick={() => { setProgress(0); setPlaying(false); }}>
          <RotateCcw className="size-4" />
        </Button>
        <Button size="icon" variant="secondary" aria-label="Forward" onClick={() => setProgress(Math.min(1, progress + 0.08))}>
          <FastForward className="size-4" />
        </Button>
        <div className="ml-auto flex items-center gap-1">
          {SPEEDS.map((sp) => (
            <button
              key={sp}
              type="button"
              onClick={() => setSpeed(sp)}
              className={cn(
                "h-9 min-w-11 rounded-md px-2 font-mono text-[11px]",
                speed === sp ? "bg-accent text-accent-fg" : "text-fg-muted hover:bg-surface-3",
              )}
            >
              {sp}x
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
