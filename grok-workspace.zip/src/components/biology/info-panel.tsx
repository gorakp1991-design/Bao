import { Link } from "@tanstack/react-router";
import { getPart, getTopic } from "@/data/catalog";
import { useAppStore } from "@/store/app-store";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export function InfoPanel({ topicId }: { topicId: string }) {
  const topic = getTopic(topicId);
  const selected = useAppStore((s) => s.selectedPart);
  const level = useAppStore((s) => s.classLevel);
  const part = getPart(topic, selected);
  const setTutorOpen = useAppStore((s) => s.setTutorOpen);

  const title = part?.name ?? topic.name;
  const fn = part?.function ?? topic.function;
  const structure = part?.structure ?? topic.structure;
  const fact = part?.fact ?? topic.facts[0];

  return (
    <div className="flex h-full flex-col gap-4 overflow-y-auto p-4">
      <div>
        <p className="font-mono text-[10px] tracking-[0.22em] text-fg-subtle">SELECTED OBJECT</p>
        <h2 className="mt-1 font-display text-xl text-fg">{title}</h2>
        <div className="mt-2 flex flex-wrap gap-2">
          <Badge tone="accent">{part ? "Structure" : "Model"}</Badge>
          <Badge>Class {level}</Badge>
        </div>
      </div>
      <Section k="Function" v={fn} />
      <Section k="Structure" v={structure} />
      {part ? <Section k="Location" v={part.location} /> : null}
      <Section k="Key fact" v={fact ?? ""} />
      {!part ? <p className="text-sm leading-relaxed text-fg-muted">{topic.explain[level]}</p> : null}
      <p className="text-[11px] leading-relaxed text-fg-subtle">{topic.ncert}</p>
      {topic.facts[2] ? <p className="text-[11px] italic text-fg-subtle">{topic.facts[2]}</p> : null}
      <div className="mt-auto flex flex-col gap-2">
        <Button onClick={() => setTutorOpen(true)}>Ask BIO-BOT</Button>
        {topic.processes[0] ? (
          <Button variant="secondary" asChild>
            <Link to="/four-d" search={{ process: topic.processes[0] }}>
              Open 4D process
            </Link>
          </Button>
        ) : (
          <Button variant="secondary" asChild>
            <Link to="/learn">Learn more</Link>
          </Button>
        )}
      </div>
    </div>
  );
}

function Section({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <p className="font-mono text-[10px] tracking-[0.18em] text-accent">{k.toUpperCase()}</p>
      <p className="mt-1 text-sm leading-relaxed text-fg-muted">{v}</p>
    </div>
  );
}
