import {
  Aperture,
  Eye,
  EyeOff,
  Layers,
  Maximize,
  RotateCcw,
  Scan,
  SplitSquareHorizontal,
} from "lucide-react";
import { resetCamera } from "@/components/3d/canvas-stage";
import { Button } from "@/components/ui/button";
import { useAppStore } from "@/store/app-store";
import { cn } from "@/lib/utils";

export function ViewerToolbar() {
  const labels = useAppStore((s) => s.labels);
  const transparency = useAppStore((s) => s.transparency);
  const exploded = useAppStore((s) => s.exploded);
  const isolated = useAppStore((s) => s.isolatedPart);
  const selected = useAppStore((s) => s.selectedPart);
  const compare = useAppStore((s) => s.compare);
  const setLabels = useAppStore((s) => s.setLabels);
  const setTransparency = useAppStore((s) => s.setTransparency);
  const setExploded = useAppStore((s) => s.setExploded);
  const setIsolated = useAppStore((s) => s.setIsolated);
  const setCompare = useAppStore((s) => s.setCompare);
  const resetView = useAppStore((s) => s.resetView);

  const fullscreen = () => {
    const el = document.getElementById("bio-viewport");
    if (!el) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void el.requestFullscreen();
  };

  return (
    <div className="pointer-events-auto flex flex-wrap gap-1 rounded-xl border border-border bg-surface/80 p-1 backdrop-blur-md">
      <Tool icon={RotateCcw} label="Reset camera" onClick={() => { resetCamera(); resetView(); }} />
      <Tool icon={labels ? Eye : EyeOff} label="Toggle labels" onClick={() => setLabels(!labels)} active={labels} />
      <Tool icon={Aperture} label="Transparency" onClick={() => setTransparency(!transparency)} active={transparency} />
      <Tool icon={Layers} label="Exploded view" onClick={() => setExploded(!exploded)} active={exploded} />
      <Tool
        icon={Scan}
        label="Isolate selection"
        onClick={() => setIsolated(isolated ? null : selected)}
        active={Boolean(isolated)}
      />
      <Tool icon={SplitSquareHorizontal} label="Compare" onClick={() => setCompare(!compare)} active={compare} />
      <Tool icon={Maximize} label="Fullscreen" onClick={fullscreen} />
    </div>
  );
}

function Tool({
  icon: Icon,
  label,
  onClick,
  active,
}: {
  icon: typeof Eye;
  label: string;
  onClick: () => void;
  active?: boolean;
}) {
  return (
    <Button
      size="icon"
      variant="ghost"
      aria-label={label}
      title={label}
      onClick={onClick}
      className={cn("size-10", active && "bg-accent/15 text-accent")}
    >
      <Icon className="size-4" />
    </Button>
  );
}
