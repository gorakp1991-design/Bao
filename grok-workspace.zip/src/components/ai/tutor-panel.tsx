import { useState } from "react";
import { biologyTutor } from "@/lib/tutor";
import { SUGGESTED_PROMPTS } from "@/data/knowledge";
import { getProcess, stageAt } from "@/data/processes";
import { useAppStore } from "@/store/app-store";
import { useProgress } from "@/store/progress-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { getTopic } from "@/data/catalog";

type Msg = { role: "user" | "bot"; text: string; source?: string };

export function TutorDrawer() {
  const open = useAppStore((s) => s.tutorOpen);
  const setOpen = useAppStore((s) => s.setTutorOpen);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-bg/50" onClick={() => setOpen(false)}>
      <aside className="flex h-full w-full max-w-md flex-col bg-surface" onClick={(e) => e.stopPropagation()}>
        <TutorBody onClose={() => setOpen(false)} />
      </aside>
    </div>
  );
}

export function TutorBody({ onClose }: { onClose?: () => void }) {
  const topicId = useAppStore((s) => s.selectedTopic);
  const processId = useAppStore((s) => s.selectedProcess);
  const selected = useAppStore((s) => s.selectedPart);
  const level = useAppStore((s) => s.classLevel);
  const progress = useAppStore((s) => s.progress);
  const topic = getTopic(topicId);
  const process = getProcess(processId);
  const stage = stageAt(process, progress);
  const bump = useProgress((s) => s.bumpChat);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "bot",
      text: `BIO-BOT online. You are viewing ${topic.name}${selected ? ` → ${selected}` : ""}. Ask anything about this model.`,
      source: "local",
    },
  ]);

  const send = async (text: string) => {
    const message = text.trim();
    if (!message || busy) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", text: message }]);
    setBusy(true);
    bump();
    const res = await biologyTutor(message, {
      model: topicId,
      topic: topicId,
      stage: stage.id,
      selected,
      level,
    });
    setMessages((m) => [...m, { role: "bot", text: res.text, source: res.source }]);
    setBusy(false);
  };

  return (
    <div className="flex h-full flex-col">
      <header className="flex items-center justify-between border-b border-border px-4 py-3">
        <div>
          <p className="font-display text-base">BIO-BOT</p>
          <p className="text-xs text-fg-subtle">
            Context: {topic.name}
            {selected ? ` / ${selected}` : ""} · Class {level}
          </p>
        </div>
        {onClose ? (
          <Button variant="ghost" size="sm" onClick={onClose}>
            Close
          </Button>
        ) : null}
      </header>
      <div className="flex-1 space-y-3 overflow-y-auto p-4">
        {messages.map((m, i) => (
          <div key={i} className={m.role === "user" ? "ml-8 rounded-xl bg-surface-3 px-3 py-2 text-sm" : "mr-6 rounded-xl bg-surface-2 px-3 py-2 text-sm whitespace-pre-wrap text-fg-muted"}>
            {m.role === "bot" && m.source ? (
              <Badge tone={m.source === "ai" ? "accent" : "muted"} className="mb-2">
                {m.source === "ai" ? "Grok" : "On-device"}
              </Badge>
            ) : null}
            {m.text}
          </div>
        ))}
        {busy ? <p className="text-xs text-fg-subtle">Thinking…</p> : null}
      </div>
      <div className="flex flex-wrap gap-1 px-3 pb-2">
        {SUGGESTED_PROMPTS.map((p) => (
          <button
            key={p}
            type="button"
            className="rounded-full border border-border px-2.5 py-1 text-[11px] text-fg-muted hover:text-fg"
            onClick={() => void send(p)}
          >
            {p}
          </button>
        ))}
      </div>
      <form
        className="flex gap-2 border-t border-border p-3"
        onSubmit={(e) => {
          e.preventDefault();
          void send(input);
        }}
      >
        <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask about this structure…" />
        <Button type="submit" disabled={busy}>
          Send
        </Button>
      </form>
    </div>
  );
}
