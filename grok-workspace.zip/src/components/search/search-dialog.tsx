import { Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { TOPICS } from "@/data/catalog";
import { PROCESSES } from "@/data/processes";
import { QUESTIONS } from "@/data/quizzes";
import { useAppStore } from "@/store/app-store";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function SearchDialog() {
  const open = useAppStore((s) => s.searchOpen);
  const setOpen = useAppStore((s) => s.setSearchOpen);
  const setTopic = useAppStore((s) => s.setTopic);
  const setProcess = useAppStore((s) => s.setProcess);
  const [q, setQ] = useState("");

  const results = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (s.length < 1) {
      return {
        models: TOPICS.slice(0, 6),
        processes: PROCESSES.slice(0, 4),
        quizzes: QUESTIONS.slice(0, 3),
      };
    }
    return {
      models: TOPICS.filter((t) => `${t.name} ${t.summary} ${t.parts.map((p) => p.name).join(" ")}`.toLowerCase().includes(s)),
      processes: PROCESSES.filter((p) => `${p.name} ${p.summary}`.toLowerCase().includes(s)),
      quizzes: QUESTIONS.filter((item) => item.prompt.toLowerCase().includes(s)),
    };
  }, [q]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 grid place-items-start bg-bg/60 p-4 pt-[12vh]" onClick={() => setOpen(false)}>
      <div
        className="glass w-full max-w-xl rounded-2xl p-4"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-label="Search biology"
      >
        <Input
          autoFocus
          placeholder="Search mitochondria, mitosis, heart…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <div className="mt-4 max-h-[50vh] space-y-4 overflow-y-auto">
          <Group title="3D models">
            {results.models.map((t) => (
              <Link
                key={t.id}
                to="/lab"
                search={{ topic: t.id }}
                className="block rounded-lg px-3 py-2 text-sm hover:bg-surface-3"
                onClick={() => {
                  setTopic(t.id);
                  setOpen(false);
                }}
              >
                <span className="text-fg">{t.name}</span>
                <span className="ml-2 text-fg-subtle">{t.summary}</span>
              </Link>
            ))}
          </Group>
          <Group title="4D processes">
            {results.processes.map((p) => (
              <Link
                key={p.id}
                to="/four-d"
                search={{ process: p.id }}
                className="block rounded-lg px-3 py-2 text-sm hover:bg-surface-3"
                onClick={() => {
                  setProcess(p.id);
                  setOpen(false);
                }}
              >
                {p.name}
              </Link>
            ))}
          </Group>
          <Group title="Quizzes">
            {results.quizzes.map((item) => (
              <Link key={item.id} to="/quiz" className="block rounded-lg px-3 py-2 text-sm hover:bg-surface-3" onClick={() => setOpen(false)}>
                {item.prompt}
              </Link>
            ))}
          </Group>
          <Group title="Also">
            <Link to="/tutor" className="block rounded-lg px-3 py-2 text-sm hover:bg-surface-3" onClick={() => setOpen(false)}>
              Ask BIO-BOT
            </Link>
            <Link to="/learn" className="block rounded-lg px-3 py-2 text-sm hover:bg-surface-3" onClick={() => setOpen(false)}>
              Learning paths
            </Link>
          </Group>
        </div>
        <div className="mt-3 flex justify-end">
          <Button variant="ghost" onClick={() => setOpen(false)}>
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}

function Group({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section>
      <p className="mb-1 font-mono text-[10px] tracking-[0.2em] text-fg-subtle">{title.toUpperCase()}</p>
      <div className="space-y-0.5">{children}</div>
    </section>
  );
}
