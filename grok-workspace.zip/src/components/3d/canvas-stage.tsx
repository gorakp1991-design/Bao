import { Canvas } from "@react-three/fiber";
import { OrbitControls, ContactShadows } from "@react-three/drei";
import { Component, Suspense, useEffect, useRef, useState, type ReactNode } from "react";
import { useAppStore } from "@/store/app-store";

type Props = {
  children: ReactNode;
  camera?: [number, number, number];
  autoRotate?: boolean;
  className?: string;
  onReady?: () => void;
};

class SceneErrorBoundary extends Component<{ children: ReactNode }, { err: string | null }> {
  state = { err: null as string | null };
  static getDerivedStateFromError(error: unknown) {
    return { err: error instanceof Error ? error.message : "Scene failed" };
  }
  render() {
    if (this.state.err) {
      return (
        <mesh>
          <icosahedronGeometry args={[1.2, 1]} />
          <meshStandardMaterial color="#3ee0c5" wireframe />
        </mesh>
      );
    }
    return this.props.children;
  }
}

function Platform() {
  return (
    <group position={[0, -2.85, 0]}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <circleGeometry args={[3.6, 48]} />
        <meshStandardMaterial color="#0c1219" metalness={0.25} roughness={0.7} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]}>
        <ringGeometry args={[3.45, 3.62, 64]} />
        <meshBasicMaterial color="#3ee0c5" transparent opacity={0.28} />
      </mesh>
    </group>
  );
}

export function CanvasStage({
  children,
  camera = [0, 0.8, 8],
  autoRotate,
  className,
}: Props) {
  const [mounted, setMounted] = useState(false);
  const quality = useAppStore((s) => s.quality);
  const reduced = useAppStore((s) => s.reducedMotion);
  const playing = useAppStore((s) => s.playing);
  const controls = useRef<React.ComponentRef<typeof OrbitControls>>(null);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    const onReset = () => {
      controls.current?.reset();
    };
    window.addEventListener("bioverse-reset-camera", onReset);
    return () => window.removeEventListener("bioverse-reset-camera", onReset);
  }, []);

  if (!mounted) {
    return (
      <div className={`relative grid place-items-center bg-bg-deep ${className ?? "h-full w-full"}`}>
        <p className="font-mono text-xs tracking-[0.25em] text-fg-subtle">INITIALISING VIEWPORT</p>
      </div>
    );
  }

  const dpr: [number, number] | number = quality === "high" ? [1, 2] : quality === "medium" ? [1, 1.5] : 1;
  const rotate = Boolean(autoRotate) && !reduced && !playing;

  return (
    <div className={`relative h-full w-full touch-none ${className ?? ""}`} style={{ touchAction: "none" }}>
      <Canvas
        dpr={dpr}
        shadows={quality === "high"}
        gl={{ antialias: quality !== "low", alpha: true, powerPreference: "high-performance" }}
        camera={{ position: camera, fov: 42, near: 0.1, far: 80 }}
        frameloop={playing || rotate ? "always" : "demand"}
        performance={{ min: 0.4 }}
        onPointerMissed={() => useAppStore.getState().selectPart(null)}
      >
        <color attach="background" args={["#07090f"]} />
        <fog attach="fog" args={["#07090f", 12, 28]} />
        <ambientLight intensity={0.42} />
        <pointLight position={[6, 8, 6]} intensity={1.15} color="#d7fff6" />
        <pointLight position={[-7, -2, -4]} intensity={0.45} color="#7aa2ff" />
        <spotLight position={[0, 10, 2]} intensity={0.55} angle={0.5} penumbra={0.8} color="#3ee0c5" />
        <OrbitControls
          ref={controls}
          makeDefault
          enableDamping
          dampingFactor={0.08}
          autoRotate={rotate}
          autoRotateSpeed={0.6}
          minDistance={3}
          maxDistance={18}
          maxPolarAngle={Math.PI * 0.92}
        />
        <Platform />
        {quality !== "low" ? (
          <ContactShadows position={[0, -2.84, 0]} opacity={0.35} scale={10} blur={2.4} far={6} />
        ) : null}
        <Suspense fallback={null}>
          <SceneErrorBoundary>{children}</SceneErrorBoundary>
        </Suspense>
      </Canvas>
    </div>
  );
}

export function resetCamera() {
  window.dispatchEvent(new Event("bioverse-reset-camera"));
}
