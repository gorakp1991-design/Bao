import { Canvas, useFrame } from "@react-three/fiber";
import { useMemo, useRef, useState, useEffect } from "react";
import * as THREE from "three";
import { DNAModel } from "@/components/3d/models/dna";

function Drift() {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (!ref.current) return;
    const d = Math.min(dt, 0.1);
    ref.current.rotation.y += d * 0.18;
    ref.current.rotation.x = Math.sin(performance.now() / 4000) * 0.12;
  });
  return (
    <group ref={ref}>
      <DNAModel />
    </group>
  );
}

function Dust({ count = 80 }: { count?: number }) {
  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      arr[i * 3] = (Math.random() - 0.5) * 14;
      arr[i * 3 + 1] = (Math.random() - 0.5) * 10;
      arr[i * 3 + 2] = (Math.random() - 0.5) * 10;
    }
    return arr;
  }, [count]);
  return (
    <points>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial size={0.035} color="#3ee0c5" transparent opacity={0.55} />
    </points>
  );
}

export function HeroScene() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return <div className="h-full w-full bg-bg-deep" />;
  return (
    <Canvas camera={{ position: [0, 0.4, 9], fov: 40 }} dpr={[1, 1.5]} gl={{ antialias: true, alpha: true }}>
      <color attach="background" args={["#07090f"]} />
      <ambientLight intensity={0.45} />
      <pointLight position={[4, 6, 6]} intensity={1.1} color="#e8fff8" />
      <pointLight position={[-5, -2, -3]} intensity={0.4} color="#7aa2ff" />
      <Drift />
      <Dust />
    </Canvas>
  );
}
