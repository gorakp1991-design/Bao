import { type ThreeEvent } from "@react-three/fiber";
import { useState } from "react";
import { useAppStore } from "@/store/app-store";
import { useProgress } from "@/store/progress-store";

export function usePart(id: string) {
  const selectedPart = useAppStore((s) => s.selectedPart);
  const selectPart = useAppStore((s) => s.selectPart);
  const isolated = useAppStore((s) => s.isolatedPart);
  const exploded = useAppStore((s) => s.exploded);
  const transparency = useAppStore((s) => s.transparency);
  const topic = useAppStore((s) => s.selectedTopic);
  const markExplored = useProgress((s) => s.markExplored);
  const [hovered, setHovered] = useState(false);
  const selected = selectedPart === id;
  const dimmed = isolated !== null && isolated !== id;
  const active = selected || hovered;

  const bind = {
    onClick: (e: ThreeEvent<MouseEvent>) => {
      e.stopPropagation();
      selectPart(id);
      markExplored(topic);
    },
    onPointerOver: (e: ThreeEvent<PointerEvent>) => {
      e.stopPropagation();
      setHovered(true);
    },
    onPointerOut: () => setHovered(false),
  };

  return { selected, hovered, dimmed, exploded, transparency, bind, active };
}

export function partMaterial(opts: {
  color: string;
  active?: boolean;
  dimmed?: boolean;
  transparency?: boolean;
  metalness?: number;
  roughness?: number;
  opacity?: number;
}) {
  const opacity = opts.dimmed
    ? 0.08
    : opts.opacity ?? (opts.transparency ? 0.72 : 0.96);
  return {
    color: opts.color,
    emissive: opts.active ? "#3ee0c5" : opts.color,
    emissiveIntensity: opts.active ? 0.45 : 0.08,
    metalness: opts.metalness ?? 0.15,
    roughness: opts.roughness ?? 0.45,
    transparent: opacity < 0.98,
    opacity,
    depthWrite: opacity > 0.85,
  };
}
