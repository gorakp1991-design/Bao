import { Html } from "@react-three/drei";
import { getTopic } from "@/data/catalog";
import { partMaterial, usePart } from "@/components/3d/bio-part";
import { useAppStore } from "@/store/app-store";

const PALETTE = ["#3ee0c5", "#7ee0a8", "#6b8cff", "#e7c27a", "#e8897a", "#93a0b4"];

export function GenericModel({ topicId }: { topicId: string }) {
  const topic = getTopic(topicId);
  const labels = useAppStore((s) => s.labels);
  const exploded = useAppStore((s) => s.exploded);
  const core = usePart(topic.parts[0]?.id ?? topic.id);

  return (
    <group>
      <mesh {...core.bind}>
        <icosahedronGeometry args={[0.85, 1]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#3ee0c5", active: core.active, dimmed: core.dimmed, opacity: 0.9 })}
        />
      </mesh>
      {topic.parts.map((part, i) => (
        <OrbitPart key={part.id} id={part.id} name={part.name} index={i} total={topic.parts.length} exploded={exploded} labels={labels} />
      ))}
    </group>
  );
}

function OrbitPart({
  id,
  name,
  index,
  total,
  exploded,
  labels,
}: {
  id: string;
  name: string;
  index: number;
  total: number;
  exploded: boolean;
  labels: boolean;
}) {
  const { bind, active, dimmed } = usePart(id);
  const a = (index / Math.max(1, total)) * Math.PI * 2;
  const r = exploded ? 2.4 : 1.6;
  const y = Math.sin(index * 1.3) * (exploded ? 1.1 : 0.45);
  return (
    <mesh position={[Math.cos(a) * r, y, Math.sin(a) * r]} {...bind}>
      <sphereGeometry args={[0.22, 14, 12]} />
      <meshStandardMaterial {...partMaterial({ color: PALETTE[index % PALETTE.length]!, active, dimmed, opacity: 0.95 })} />
      {labels && (active || exploded) ? (
        <Html center distanceFactor={10}>
          <span className="rounded-full border border-border bg-surface px-2 py-0.5 font-mono text-[10px] text-fg-muted whitespace-nowrap">
            {name}
          </span>
        </Html>
      ) : null}
    </mesh>
  );
}
