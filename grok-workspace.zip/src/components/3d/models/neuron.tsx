import { useMemo } from "react";
import * as THREE from "three";
import { useAppStore } from "@/store/app-store";
import { partMaterial, usePart } from "@/components/3d/bio-part";

export function NeuronModel({ signal = 0 }: { signal?: number }) {
  const dendrites = usePart("dendrites");
  const soma = usePart("soma");
  const axon = usePart("axon");
  const myelin = usePart("myelin");
  const terminals = usePart("terminals");
  const labels = useAppStore((s) => s.labels);
  void labels;

  const axonCurve = useMemo(() => {
    const pts = [
      new THREE.Vector3(0.7, 0, 0),
      new THREE.Vector3(1.4, -0.15, 0.1),
      new THREE.Vector3(2.4, -0.05, 0),
      new THREE.Vector3(3.4, 0.2, -0.15),
      new THREE.Vector3(4.3, 0.05, 0),
    ];
    return new THREE.CatmullRomCurve3(pts);
  }, []);

  const pulse = axonCurve.getPoint(Math.min(0.98, Math.max(0, signal)));

  return (
    <group position={[-1.4, 0.2, 0]}>
      <mesh {...soma.bind}>
        <sphereGeometry args={[0.7, 24, 18]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#8bd3dd", active: soma.active, dimmed: soma.dimmed, opacity: 0.92 })}
        />
      </mesh>
      {[
        [0.9, 0.8, 0.2],
        [1.1, 0.2, 0.7],
        [0.7, -0.7, 0.4],
        [1.0, 0.5, -0.7],
      ].map((d, i) => (
        <group key={i} {...dendrites.bind}>
          <mesh position={[-(d[0] as number), d[1] as number, d[2] as number]} rotation={[0.3 * i, 0.2, 0.5]}>
            <cylinderGeometry args={[0.03, 0.08, 1.1, 8]} />
            <meshStandardMaterial
              {...partMaterial({ color: "#7ee0c5", active: dendrites.active, dimmed: dendrites.dimmed, opacity: 1 })}
            />
          </mesh>
          <mesh position={[-(d[0] as number) * 1.45, (d[1] as number) * 1.35, (d[2] as number) * 1.2]}>
            <sphereGeometry args={[0.08, 8, 8]} />
            <meshStandardMaterial color="#7ee0c5" />
          </mesh>
        </group>
      ))}
      <mesh {...axon.bind}>
        <tubeGeometry args={[axonCurve, 48, 0.07, 8, false]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#93a0b4", active: axon.active, dimmed: axon.dimmed, opacity: 1 })}
        />
      </mesh>
      {[0.22, 0.4, 0.58, 0.75].map((t) => {
        const p = axonCurve.getPoint(t);
        return (
          <mesh key={t} position={p} {...myelin.bind}>
            <sphereGeometry args={[0.16, 12, 10]} />
            <meshStandardMaterial
              {...partMaterial({ color: "#e8eef6", active: myelin.active, dimmed: myelin.dimmed, opacity: 0.85 })}
            />
          </mesh>
        );
      })}
      {[0, 1, 2].map((i) => (
        <mesh key={i} position={[4.4, 0.2 * (i - 1), 0.15 * (i - 1)]} {...terminals.bind}>
          <sphereGeometry args={[0.14, 12, 12]} />
          <meshStandardMaterial
            {...partMaterial({ color: "#e7c27a", active: terminals.active, dimmed: terminals.dimmed, opacity: 1 })}
          />
        </mesh>
      ))}
      {signal > 0.02 ? (
        <mesh position={pulse}>
          <sphereGeometry args={[0.14, 12, 12]} />
          <meshStandardMaterial color="#3ee0c5" emissive="#3ee0c5" emissiveIntensity={1.2} />
        </mesh>
      ) : null}
      {signal > 0.85
        ? Array.from({ length: 8 }).map((_, i) => (
            <mesh key={i} position={[4.6 + (i % 3) * 0.12, Math.sin(i) * 0.2, Math.cos(i) * 0.2]}>
              <sphereGeometry args={[0.045, 8, 8]} />
              <meshStandardMaterial color="#e7c27a" emissive="#e7c27a" emissiveIntensity={0.8} />
            </mesh>
          ))
        : null}
    </group>
  );
}
