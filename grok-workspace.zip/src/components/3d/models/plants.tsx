import { useAppStore } from "@/store/app-store";
import { partMaterial, usePart } from "@/components/3d/bio-part";

export function ChloroplastModel() {
  const thylakoid = usePart("thylakoid");
  const granum = usePart("granum");
  const stroma = usePart("stroma");
  const exploded = useAppStore((s) => s.exploded);
  return (
    <group rotation={[0.3, 0.5, 0]}>
      <mesh scale={[1.7, 1, 0.9]} {...stroma.bind}>
        <sphereGeometry args={[1.15, 28, 18]} />
        <meshPhysicalMaterial color="#3d9a5f" transparent opacity={0.22} roughness={0.3} />
      </mesh>
      {[-0.35, 0.05, 0.4].map((x, i) => (
        <group key={i} position={[exploded ? x * 2.2 : x, 0, 0]} {...granum.bind}>
          {[0, 1, 2, 3, 4].map((n) => (
            <mesh key={n} position={[0, n * 0.09 - 0.18, 0]} {...thylakoid.bind}>
              <cylinderGeometry args={[0.38 - i * 0.04, 0.38 - i * 0.04, 0.07, 16]} />
              <meshStandardMaterial
                {...partMaterial({ color: "#2f7a4a", active: thylakoid.active || granum.active, dimmed: thylakoid.dimmed, opacity: 0.95 })}
              />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  );
}

export function FlowerModel() {
  const petal = usePart("petal");
  const sepal = usePart("sepal");
  const stamen = usePart("stamen");
  const carpel = usePart("carpel");
  return (
    <group>
      {Array.from({ length: 6 }).map((_, i) => {
        const a = (i / 6) * Math.PI * 2;
        return (
          <mesh key={i} position={[Math.cos(a) * 0.85, 0.15, Math.sin(a) * 0.85]} rotation={[0.9, a, 0]} {...petal.bind}>
            <sphereGeometry args={[0.45, 12, 10]} />
            <meshStandardMaterial
              {...partMaterial({ color: "#e8b4c8", active: petal.active, dimmed: petal.dimmed, opacity: 0.9 })}
            />
          </mesh>
        );
      })}
      {Array.from({ length: 5 }).map((_, i) => {
        const a = (i / 5) * Math.PI * 2 + 0.3;
        return (
          <mesh key={i} position={[Math.cos(a) * 0.55, -0.25, Math.sin(a) * 0.55]} rotation={[1.1, a, 0]} {...sepal.bind}>
            <sphereGeometry args={[0.28, 10, 8]} />
            <meshStandardMaterial
              {...partMaterial({ color: "#3d9a5f", active: sepal.active, dimmed: sepal.dimmed, opacity: 0.9 })}
            />
          </mesh>
        );
      })}
      {Array.from({ length: 5 }).map((_, i) => {
        const a = (i / 5) * Math.PI * 2;
        return (
          <mesh key={i} position={[Math.cos(a) * 0.25, 0.55, Math.sin(a) * 0.25]} {...stamen.bind}>
            <cylinderGeometry args={[0.03, 0.03, 0.7, 6]} />
            <meshStandardMaterial color="#e7c27a" />
          </mesh>
        );
      })}
      <mesh position={[0, 0.35, 0]} {...carpel.bind}>
        <capsuleGeometry args={[0.12, 0.55, 6, 10]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#7ee0a8", active: carpel.active, dimmed: carpel.dimmed, opacity: 1 })}
        />
      </mesh>
    </group>
  );
}

export function LeafModel() {
  const epi = usePart("epidermis");
  const pal = usePart("palisade");
  const spo = usePart("spongy");
  const sto = usePart("stomata");
  const vein = usePart("vein");
  const exploded = useAppStore((s) => s.exploded);
  const gap = exploded ? 0.35 : 0.08;
  return (
    <group rotation={[0.4, 0.2, 0]}>
      <mesh position={[0, gap * 2, 0]} {...epi.bind}>
        <boxGeometry args={[3.2, 0.08, 1.6]} />
        <meshPhysicalMaterial color="#cde8c8" transparent opacity={0.35} />
      </mesh>
      <mesh position={[0, gap, 0]} {...pal.bind}>
        <boxGeometry args={[3, 0.35, 1.4]} />
        <meshStandardMaterial {...partMaterial({ color: "#3d9a5f", active: pal.active, dimmed: pal.dimmed, opacity: 0.9 })} />
      </mesh>
      <mesh position={[0, 0, 0]} {...spo.bind}>
        <boxGeometry args={[3, 0.4, 1.4]} />
        <meshStandardMaterial {...partMaterial({ color: "#5fb36f", active: spo.active, dimmed: spo.dimmed, opacity: 0.55 })} />
      </mesh>
      <mesh position={[0, -gap, 0]} {...epi.bind}>
        <boxGeometry args={[3.2, 0.08, 1.6]} />
        <meshPhysicalMaterial color="#cde8c8" transparent opacity={0.35} />
      </mesh>
      <mesh position={[0, gap * 0.5, 0]} {...vein.bind}>
        <boxGeometry args={[3.1, 0.06, 0.12]} />
        <meshStandardMaterial color="#d7c4a3" />
      </mesh>
      {[-0.8, 0, 0.8].map((x) => (
        <mesh key={x} position={[x, -gap * 1.2, 0.55]} {...sto.bind}>
          <torusGeometry args={[0.08, 0.03, 8, 12]} />
          <meshStandardMaterial {...partMaterial({ color: "#3ee0c5", active: sto.active, dimmed: sto.dimmed, opacity: 1 })} />
        </mesh>
      ))}
    </group>
  );
}

export function RootModel() {
  const hair = usePart("root-hair");
  const cap = usePart("cap");
  const xylem = usePart("xylem");
  const phloem = usePart("phloem");
  return (
    <group rotation={[0, 0.3, 0]}>
      <mesh position={[0, 0.4, 0]}>
        <cylinderGeometry args={[0.45, 0.55, 2.6, 12]} />
        <meshStandardMaterial color="#c4a574" roughness={0.7} />
      </mesh>
      <mesh position={[0, -1.15, 0]} {...cap.bind}>
        <coneGeometry args={[0.5, 0.55, 10]} />
        <meshStandardMaterial {...partMaterial({ color: "#a8845a", active: cap.active, dimmed: cap.dimmed, opacity: 1 })} />
      </mesh>
      <mesh position={[0, 0.3, 0]} {...xylem.bind}>
        <cylinderGeometry args={[0.12, 0.12, 2.1, 8]} />
        <meshStandardMaterial color="#e7c27a" />
      </mesh>
      {Array.from({ length: 6 }).map((_, i) => {
        const a = (i / 6) * Math.PI * 2;
        return (
          <mesh key={i} position={[Math.cos(a) * 0.22, 0.3, Math.sin(a) * 0.22]} {...phloem.bind}>
            <cylinderGeometry args={[0.05, 0.05, 2.1, 6]} />
            <meshStandardMaterial color="#3d9a5f" />
          </mesh>
        );
      })}
      {Array.from({ length: 12 }).map((_, i) => {
        const a = (i / 12) * Math.PI * 2;
        const y = -0.2 + (i % 4) * 0.25;
        return (
          <mesh key={i} position={[Math.cos(a) * 0.7, y, Math.sin(a) * 0.7]} rotation={[0.6, a, 0]} {...hair.bind}>
            <cylinderGeometry args={[0.015, 0.03, 0.55, 6]} />
            <meshStandardMaterial {...partMaterial({ color: "#e8d5b5", active: hair.active, dimmed: hair.dimmed, opacity: 1 })} />
          </mesh>
        );
      })}
    </group>
  );
}
