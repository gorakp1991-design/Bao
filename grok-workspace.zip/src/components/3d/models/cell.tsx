import { Html } from "@react-three/drei";
import { useAppStore } from "@/store/app-store";
import { partMaterial, usePart } from "@/components/3d/bio-part";

function Label({ text, show }: { text: string; show: boolean }) {
  if (!show) return null;
  return (
    <Html distanceFactor={10} center>
      <span className="rounded-full border border-border bg-surface/90 px-2 py-0.5 font-mono text-[10px] text-fg-muted whitespace-nowrap">
        {text}
      </span>
    </Html>
  );
}

function Bean({
  id,
  position,
  explodedPos,
  rotation,
  color,
  label,
}: {
  id: string;
  position: [number, number, number];
  explodedPos: [number, number, number];
  rotation?: [number, number, number];
  color: string;
  label: string;
}) {
  const { active, dimmed, transparency, exploded, bind } = usePart(id);
  const labels = useAppStore((s) => s.labels);
  const pos = exploded ? explodedPos : position;
  const mat = partMaterial({ color, active, dimmed, transparency, opacity: 0.95 });
  return (
    <group position={pos} rotation={rotation} {...bind}>
      <mesh>
        <sphereGeometry args={[0.28, 18, 14]} />
        <meshStandardMaterial {...mat} />
      </mesh>
      <mesh scale={[1.55, 0.72, 0.78]} position={[0.08, 0, 0]}>
        <sphereGeometry args={[0.28, 18, 14]} />
        <meshStandardMaterial {...mat} />
      </mesh>
      <mesh>
        <torusGeometry args={[0.14, 0.018, 8, 16]} />
        <meshStandardMaterial color="#5c2a24" roughness={0.5} />
      </mesh>
      <Label text={label} show={labels && (active || exploded)} />
    </group>
  );
}

export function AnimalCell() {
  const membrane = usePart("membrane");
  const cyto = usePart("cytoplasm");
  const nucleus = usePart("nucleus");
  const nucleolus = usePart("nucleolus");
  const er = usePart("er");
  const golgi = usePart("golgi");
  const lyso = usePart("lysosome");
  const centriole = usePart("centriole");
  const ribo = usePart("ribosome");
  const labels = useAppStore((s) => s.labels);
  const exploded = useAppStore((s) => s.exploded);
  const isolated = useAppStore((s) => s.isolatedPart);

  const hide = (id: string) => isolated !== null && isolated !== id && isolated !== "cytoplasm" && isolated !== "membrane";

  return (
    <group>
      <mesh {...membrane.bind} visible={!hide("membrane")}>
        <sphereGeometry args={[2.55, 48, 32]} />
        <meshPhysicalMaterial
          color="#3d8f9e"
          transparent
          opacity={membrane.transparency ? 0.14 : 0.32}
          roughness={0.2}
          metalness={0.05}
          transmission={membrane.transparency ? 0.6 : 0}
          thickness={0.4}
          emissive="#3ee0c5"
          emissiveIntensity={membrane.active ? 0.35 : 0.05}
        />
      </mesh>
      <mesh {...cyto.bind} visible={!hide("cytoplasm")}>
        <sphereGeometry args={[2.35, 32, 24]} />
        <meshPhysicalMaterial color="#16303a" transparent opacity={0.12} roughness={0.8} />
      </mesh>

      <group position={exploded ? [-0.2, 0.15, 0.15] : [-0.15, 0.2, 0.1]} visible={!hide("nucleus")} {...nucleus.bind}>
        <mesh>
          <sphereGeometry args={[0.85, 32, 24]} />
          <meshStandardMaterial
            {...partMaterial({
              color: "#6b8cff",
              active: nucleus.active,
              dimmed: nucleus.dimmed,
              transparency: true,
              opacity: 0.55,
            })}
          />
        </mesh>
        <mesh position={[0.12, 0.1, 0.1]} {...nucleolus.bind}>
          <sphereGeometry args={[0.22, 16, 16]} />
          <meshStandardMaterial
            {...partMaterial({ color: "#c4b5fd", active: nucleolus.active, dimmed: nucleolus.dimmed, opacity: 1 })}
          />
        </mesh>
        <Label text="Nucleus" show={labels && (nucleus.active || exploded)} />
      </group>

      {!hide("mitochondria") ? (
        <>
          <Bean id="mitochondria" position={[1.15, 0.35, 0.45]} explodedPos={[2.4, 0.8, 0.9]} rotation={[0.4, 0.6, 0.2]} color="#e8897a" label="Mitochondrion" />
          <Bean id="mitochondria" position={[-1.2, -0.55, 0.7]} explodedPos={[-2.5, -1.1, 1.2]} rotation={[0.2, -0.5, 0.4]} color="#e8897a" label="Mitochondrion" />
          <Bean id="mitochondria" position={[0.35, -1.15, -0.6]} explodedPos={[0.8, -2.2, -1.1]} rotation={[-0.4, 0.2, 0.1]} color="#e8897a" label="Mitochondrion" />
        </>
      ) : null}

      <group position={exploded ? [1.8, 0.9, -0.4] : [0.9, 0.55, -0.55]} visible={!hide("er")} {...er.bind}>
        {[0, 1, 2, 3].map((i) => (
          <mesh key={i} position={[0, i * 0.12 - 0.18, 0]} rotation={[0.2, 0.4, 0.1]}>
            <torusGeometry args={[0.42, 0.045, 8, 24]} />
            <meshStandardMaterial
              {...partMaterial({ color: "#d4a574", active: er.active, dimmed: er.dimmed, opacity: 0.9 })}
            />
          </mesh>
        ))}
        <Label text="ER" show={labels && (er.active || exploded)} />
      </group>

      <group position={exploded ? [-1.9, 1.1, -0.5] : [-0.85, 0.85, -0.7]} visible={!hide("golgi")} {...golgi.bind}>
        {[0, 1, 2, 3].map((i) => (
          <mesh key={i} position={[0, i * 0.08, 0]} scale={[1 - i * 0.08, 0.35, 0.7]}>
            <boxGeometry args={[0.7, 0.07, 0.45]} />
            <meshStandardMaterial
              {...partMaterial({ color: "#e7c27a", active: golgi.active, dimmed: golgi.dimmed, opacity: 0.92 })}
            />
          </mesh>
        ))}
        <Label text="Golgi" show={labels && (golgi.active || exploded)} />
      </group>

      <mesh position={exploded ? [2.1, -0.9, 0.2] : [1.35, -0.55, 0.85]} visible={!hide("lysosome")} {...lyso.bind}>
        <sphereGeometry args={[0.2, 16, 16]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#c084fc", active: lyso.active, dimmed: lyso.dimmed, opacity: 0.9 })}
        />
        <Label text="Lysosome" show={labels && (lyso.active || exploded)} />
      </mesh>

      <group position={exploded ? [0.2, -2.1, 1.1] : [0.55, -0.85, 1.15]} visible={!hide("centriole")} {...centriole.bind}>
        <mesh rotation={[0.6, 0.2, 0.1]}>
          <cylinderGeometry args={[0.08, 0.08, 0.28, 8]} />
          <meshStandardMaterial
            {...partMaterial({ color: "#94a3b8", active: centriole.active, dimmed: centriole.dimmed, opacity: 1 })}
          />
        </mesh>
        <mesh position={[0.12, 0.05, 0]} rotation={[0.1, 0.8, 0.6]}>
          <cylinderGeometry args={[0.08, 0.08, 0.28, 8]} />
          <meshStandardMaterial
            {...partMaterial({ color: "#94a3b8", active: centriole.active, dimmed: centriole.dimmed, opacity: 1 })}
          />
        </mesh>
        <Label text="Centriole" show={labels && (centriole.active || exploded)} />
      </group>

      {!hide("ribosome")
        ? (
            [
              [0.4, 0.9, 1.1],
              [-1.4, 0.2, -0.9],
              [1.5, -0.2, -1],
              [-0.6, -1.3, 0.3],
              [0.1, 1.4, -0.8],
            ] as [number, number, number][]
          ).map((p, i) => (
            <mesh key={i} position={p} {...ribo.bind}>
              <sphereGeometry args={[0.08, 10, 10]} />
              <meshStandardMaterial
                {...partMaterial({ color: "#cbd5e1", active: ribo.active, dimmed: ribo.dimmed, opacity: 1 })}
              />
            </mesh>
          ))
        : null}
    </group>
  );
}

export function PlantCell() {
  const wall = usePart("wall");
  const membrane = usePart("membrane");
  const vacuole = usePart("vacuole");
  const nucleus = usePart("nucleus");
  const chloro = usePart("chloroplast");
  const golgi = usePart("golgi");
  const mito = usePart("mitochondria");
  const labels = useAppStore((s) => s.labels);
  const exploded = useAppStore((s) => s.exploded);

  return (
    <group>
      <mesh {...wall.bind}>
        <boxGeometry args={[4.4, 3.2, 2.6]} />
        <meshPhysicalMaterial
          color="#a3c585"
          transparent
          opacity={0.18}
          roughness={0.35}
          emissive="#7ee0a8"
          emissiveIntensity={wall.active ? 0.3 : 0.04}
        />
      </mesh>
      <mesh {...membrane.bind}>
        <boxGeometry args={[4.05, 2.9, 2.3]} />
        <meshPhysicalMaterial color="#3d8f9e" transparent opacity={0.1} roughness={0.25} />
      </mesh>
      <mesh position={exploded ? [1.6, 0, 0] : [0.35, -0.15, 0]} {...vacuole.bind}>
        <sphereGeometry args={[1.15, 24, 18]} />
        <meshPhysicalMaterial
          color="#67e8f9"
          transparent
          opacity={0.28}
          roughness={0.15}
          emissive="#67e8f9"
          emissiveIntensity={vacuole.active ? 0.25 : 0.06}
        />
        <Label text="Vacuole" show={labels && (vacuole.active || exploded)} />
      </mesh>
      <group position={exploded ? [-1.8, 0.6, 0.4] : [-1.15, 0.55, 0.35]} {...nucleus.bind}>
        <mesh>
          <sphereGeometry args={[0.55, 24, 18]} />
          <meshStandardMaterial
            {...partMaterial({ color: "#6b8cff", active: nucleus.active, dimmed: nucleus.dimmed, opacity: 0.7 })}
          />
        </mesh>
      </group>
      {(
        [
          [
            [-1.4, -0.7, 0.55],
            [-2.4, -1.3, 0.9],
          ],
          [
            [1.5, 0.85, 0.4],
            [2.5, 1.4, 0.8],
          ],
          [
            [0.9, -0.95, -0.5],
            [1.8, -1.7, -0.9],
          ],
        ] as [[number, number, number], [number, number, number]][]
      ).map((pair, i) => (
        <mesh key={i} position={exploded ? pair[1] : pair[0]} rotation={[0.4, 0.3 * i, 0.2]} {...chloro.bind}>
          <sphereGeometry args={[0.32, 16, 12]} />
          <meshStandardMaterial
            {...partMaterial({ color: "#3d9a5f", active: chloro.active, dimmed: chloro.dimmed, opacity: 0.95 })}
          />
        </mesh>
      ))}
      <group position={exploded ? [-0.2, 1.6, -0.6] : [-0.4, 0.9, -0.55]} {...golgi.bind}>
        {[0, 1, 2].map((i) => (
          <mesh key={i} position={[0, i * 0.07, 0]} scale={[1, 0.4, 0.7]}>
            <boxGeometry args={[0.55, 0.06, 0.35]} />
            <meshStandardMaterial
              {...partMaterial({ color: "#e7c27a", active: golgi.active, dimmed: golgi.dimmed, opacity: 0.9 })}
            />
          </mesh>
        ))}
      </group>
      <mesh position={exploded ? [2.2, -1.1, 0.6] : [1.45, -0.35, 0.7]} rotation={[0.2, 0.5, 0]} {...mito.bind}>
        <sphereGeometry args={[0.22, 14, 12]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#e8897a", active: mito.active, dimmed: mito.dimmed, opacity: 0.95 })}
        />
      </mesh>
    </group>
  );
}
