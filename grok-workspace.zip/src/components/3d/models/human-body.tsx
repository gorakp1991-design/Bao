import { useAppStore } from "@/store/app-store";
import { partMaterial, usePart } from "@/components/3d/bio-part";

function Bone({
  position,
  radius,
  length,
  rotation,
}: {
  position: [number, number, number];
  radius: number;
  length: number;
  rotation?: [number, number, number];
}) {
  const { bind, active, dimmed } = usePart("skeletal");
  return (
    <mesh position={position} rotation={rotation} {...bind}>
      <capsuleGeometry args={[radius, length, 4, 8]} />
      <meshStandardMaterial {...partMaterial({ color: "#d7dce5", active, dimmed, opacity: 0.92 })} />
    </mesh>
  );
}

function Skull() {
  const { bind, active, dimmed } = usePart("skeletal");
  return (
    <mesh position={[0, 1.85, 0]} {...bind}>
      <sphereGeometry args={[0.38, 16, 12]} />
      <meshStandardMaterial {...partMaterial({ color: "#e8eef6", active, dimmed, opacity: 0.95 })} />
    </mesh>
  );
}

export function HumanBodyModel() {
  const systems = useAppStore((s) => s.bodySystems);
  const skin = usePart("skin");
  const muscular = usePart("muscular");
  const nervous = usePart("nervous");
  const circ = usePart("circulatory");
  const resp = usePart("respiratory");
  const dig = usePart("digestive");
  const uri = usePart("urinary");
  const endo = usePart("endocrine");
  const repro = usePart("reproductive");

  return (
    <group position={[0, -0.4, 0]}>
      {systems.skin ? (
        <mesh position={[0, 0.2, 0]} {...skin.bind}>
          <capsuleGeometry args={[0.95, 2.4, 6, 16]} />
          <meshPhysicalMaterial color="#e8c4b0" transparent opacity={0.18} roughness={0.5} />
        </mesh>
      ) : null}

      {systems.skeletal ? (
        <group>
          <Skull />
          <Bone position={[0, 1.15, 0]} radius={0.12} length={0.7} />
          <Bone position={[0, 0.35, 0]} radius={0.22} length={0.9} />
          <Bone position={[-0.55, 0.7, 0]} radius={0.08} length={0.9} rotation={[0, 0, 0.7]} />
          <Bone position={[0.55, 0.7, 0]} radius={0.08} length={0.9} rotation={[0, 0, -0.7]} />
          <Bone position={[-0.22, -0.85, 0]} radius={0.1} length={1.2} />
          <Bone position={[0.22, -0.85, 0]} radius={0.1} length={1.2} />
        </group>
      ) : null}

      {systems.muscular ? (
        <group>
          <mesh position={[-0.42, 0.55, 0.12]} rotation={[0, 0, 0.5]} {...muscular.bind}>
            <capsuleGeometry args={[0.14, 0.7, 4, 8]} />
            <meshStandardMaterial
              {...partMaterial({ color: "#c45c6a", active: muscular.active, dimmed: muscular.dimmed, opacity: 0.85 })}
            />
          </mesh>
          <mesh position={[0.42, 0.55, 0.12]} rotation={[0, 0, -0.5]} {...muscular.bind}>
            <capsuleGeometry args={[0.14, 0.7, 4, 8]} />
            <meshStandardMaterial
              {...partMaterial({ color: "#c45c6a", active: muscular.active, dimmed: muscular.dimmed, opacity: 0.85 })}
            />
          </mesh>
        </group>
      ) : null}

      {systems.nervous ? (
        <group>
          <mesh position={[0, 1.85, 0]} {...nervous.bind}>
            <sphereGeometry args={[0.28, 12, 12]} />
            <meshStandardMaterial color="#e7c27a" emissive="#e7c27a" emissiveIntensity={0.25} />
          </mesh>
          <mesh position={[0, 0.6, 0.12]} {...nervous.bind}>
            <cylinderGeometry args={[0.05, 0.05, 2.4, 8]} />
            <meshStandardMaterial color="#e7c27a" />
          </mesh>
        </group>
      ) : null}

      {systems.circulatory ? (
        <group>
          <mesh position={[0.12, 0.85, 0.22]} {...circ.bind}>
            <sphereGeometry args={[0.22, 12, 10]} />
            <meshStandardMaterial color="#e8897a" emissive="#e8897a" emissiveIntensity={0.4} />
          </mesh>
          <mesh position={[0, 0.1, 0.18]} {...circ.bind}>
            <cylinderGeometry args={[0.04, 0.04, 1.6, 8]} />
            <meshStandardMaterial color="#c45c6a" />
          </mesh>
        </group>
      ) : null}

      {systems.respiratory ? (
        <group>
          <mesh position={[-0.18, 0.95, 0.2]} scale={[0.55, 0.8, 0.4]} {...resp.bind}>
            <sphereGeometry args={[0.35, 12, 10]} />
            <meshStandardMaterial
              {...partMaterial({ color: "#e8b4b8", active: resp.active, dimmed: resp.dimmed, opacity: 0.8 })}
            />
          </mesh>
          <mesh position={[0.22, 0.95, 0.2]} scale={[0.5, 0.75, 0.38]} {...resp.bind}>
            <sphereGeometry args={[0.35, 12, 10]} />
            <meshStandardMaterial
              {...partMaterial({ color: "#e8b4b8", active: resp.active, dimmed: resp.dimmed, opacity: 0.8 })}
            />
          </mesh>
        </group>
      ) : null}

      {systems.digestive ? (
        <mesh position={[0, 0.15, 0.22]} {...dig.bind}>
          <torusGeometry args={[0.28, 0.07, 8, 16]} />
          <meshStandardMaterial
            {...partMaterial({ color: "#d4a574", active: dig.active, dimmed: dig.dimmed, opacity: 0.9 })}
          />
        </mesh>
      ) : null}

      {systems.urinary ? (
        <group>
          <mesh position={[-0.22, 0.35, 0.18]} {...uri.bind}>
            <sphereGeometry args={[0.14, 10, 10]} />
            <meshStandardMaterial color="#c45c6a" />
          </mesh>
          <mesh position={[0.22, 0.35, 0.18]} {...uri.bind}>
            <sphereGeometry args={[0.14, 10, 10]} />
            <meshStandardMaterial color="#c45c6a" />
          </mesh>
        </group>
      ) : null}

      {systems.endocrine ? (
        <mesh position={[0, 1.45, 0.2]} {...endo.bind}>
          <sphereGeometry args={[0.08, 8, 8]} />
          <meshStandardMaterial color="#3ee0c5" emissive="#3ee0c5" emissiveIntensity={0.5} />
        </mesh>
      ) : null}

      {systems.reproductive ? (
        <mesh position={[0, -0.35, 0.2]} {...repro.bind}>
          <sphereGeometry args={[0.16, 10, 10]} />
          <meshStandardMaterial
            {...partMaterial({ color: "#e7c27a", active: repro.active, dimmed: repro.dimmed, opacity: 0.85 })}
          />
        </mesh>
      ) : null}
    </group>
  );
}
