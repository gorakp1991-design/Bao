import { useMemo } from "react";
import * as THREE from "three";
import { Html } from "@react-three/drei";
import { useAppStore } from "@/store/app-store";
import { partMaterial, usePart } from "@/components/3d/bio-part";

const PAIR: Array<["A" | "T" | "G" | "C", "A" | "T" | "G" | "C"]> = [
  ["A", "T"],
  ["G", "C"],
  ["T", "A"],
  ["C", "G"],
  ["A", "T"],
  ["G", "C"],
  ["A", "T"],
  ["C", "G"],
  ["T", "A"],
  ["G", "C"],
  ["A", "T"],
  ["C", "G"],
  ["G", "C"],
  ["T", "A"],
];

const BASE_COLOR = { A: "#f07178", T: "#64b5f6", G: "#ffd166", C: "#06d6a0" };
const BASE_ID = { A: "adenine", T: "thymine", G: "guanine", C: "cytosine" };

function Nucleotide({
  base,
  position,
  id,
  labels,
}: {
  base: "A" | "T" | "G" | "C";
  position: [number, number, number];
  id: string;
  labels: boolean;
}) {
  const { active, dimmed, transparency, bind } = usePart(id);
  return (
    <mesh position={position} {...bind}>
      <sphereGeometry args={[0.16, 16, 16]} />
      <meshStandardMaterial {...partMaterial({ color: BASE_COLOR[base], active, dimmed, transparency, opacity: 1 })} />
      {labels && active ? (
        <Html distanceFactor={8} center>
          <span className="rounded-full bg-surface px-2 py-0.5 font-mono text-[10px] text-accent shadow-panel">
            {base}
          </span>
        </Html>
      ) : null}
    </mesh>
  );
}

function Bond({ from, to }: { from: THREE.Vector3; to: THREE.Vector3 }) {
  const { bind } = usePart("base-pair");
  const mid = from.clone().lerp(to, 0.5);
  const len = from.distanceTo(to);
  const quat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), to.clone().sub(from).normalize());
  return (
    <mesh position={mid.toArray() as [number, number, number]} quaternion={quat} {...bind}>
      <cylinderGeometry args={[0.035, 0.035, Math.max(0.05, len - 0.28), 6]} />
      <meshStandardMaterial color="#d7e3f0" transparent opacity={0.55} />
    </mesh>
  );
}

export function DNAModel({
  replication = 0,
  transcription = 0,
  mutationAt = -1,
}: {
  replication?: number;
  transcription?: number;
  mutationAt?: number;
}) {
  const labels = useAppStore((s) => s.labels);
  const { bind: backboneBind, active: bbActive, dimmed, transparency } = usePart("backbone");

  const strands = useMemo(() => {
    const ptsA: THREE.Vector3[] = [];
    const ptsB: THREE.Vector3[] = [];
    const n = PAIR.length;
    for (let i = 0; i < n; i++) {
      const t = i / (n - 1);
      const y = (t - 0.5) * 6.2;
      const a = i * 0.52;
      const unzip = replication > 0 ? smooth(Math.max(0, replication * 2 - Math.abs(t - 0.5) * 2)) : 0;
      const r = 0.95 + unzip * 0.55;
      const split = unzip * 0.85;
      ptsA.push(new THREE.Vector3(Math.cos(a) * r - split, y, Math.sin(a) * r));
      ptsB.push(new THREE.Vector3(Math.cos(a + Math.PI) * r + split, y, Math.sin(a + Math.PI) * r));
    }
    return {
      a: new THREE.CatmullRomCurve3(ptsA),
      b: new THREE.CatmullRomCurve3(ptsB),
      ptsA,
      ptsB,
    };
  }, [replication]);

  const rna = useMemo(() => {
    if (transcription <= 0) return null;
    const pts: THREE.Vector3[] = [];
    const count = Math.max(2, Math.floor(transcription * PAIR.length));
    for (let i = 0; i < count; i++) {
      const y = (i / (PAIR.length - 1) - 0.5) * 6.2;
      pts.push(new THREE.Vector3(1.7 + i * 0.02, y * 0.7, 0.2));
    }
    return new THREE.CatmullRomCurve3(pts);
  }, [transcription]);

  return (
    <group>
      <mesh {...backboneBind}>
        <tubeGeometry args={[strands.a, 64, 0.055, 8, false]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#9fb0c4", active: bbActive, dimmed, transparency, metalness: 0.35, opacity: 1 })}
        />
      </mesh>
      <mesh>
        <tubeGeometry args={[strands.b, 64, 0.055, 8, false]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#7ee0c5", active: bbActive, dimmed, transparency, metalness: 0.35, opacity: 1 })}
        />
      </mesh>
      {PAIR.map((pair, i) => {
        const left = mutationAt === i && pair[0] === "C" ? "T" : pair[0];
        const a = strands.ptsA[i]!;
        const b = strands.ptsB[i]!;
        return (
          <group key={i}>
            <Bond from={a} to={b} />
            <Nucleotide base={left} position={a.toArray() as [number, number, number]} id={BASE_ID[left]} labels={labels} />
            <Nucleotide
              base={pair[1]}
              position={b.toArray() as [number, number, number]}
              id={BASE_ID[pair[1]]}
              labels={labels}
            />
          </group>
        );
      })}
      {replication > 0.45
        ? PAIR.map((pair, i) => {
            const t = i / (PAIR.length - 1);
            if (Math.abs(t - 0.5) > replication * 0.55) return null;
            const a = strands.ptsA[i]!;
            const extra = new THREE.Vector3(a.x * 1.55, a.y, a.z * 1.55);
            return (
              <mesh key={`n${i}`} position={extra.toArray()}>
                <sphereGeometry args={[0.12, 12, 12]} />
                <meshStandardMaterial color={BASE_COLOR[pair[1]]} emissive={BASE_COLOR[pair[1]]} emissiveIntensity={0.35} />
              </mesh>
            );
          })
        : null}
      {rna ? (
        <mesh>
          <tubeGeometry args={[rna, 32, 0.04, 6, false]} />
          <meshStandardMaterial color="#e7c27a" emissive="#e7c27a" emissiveIntensity={0.3} />
        </mesh>
      ) : null}
    </group>
  );
}

function smooth(x: number) {
  const t = Math.min(1, Math.max(0, x));
  return t * t * (3 - 2 * t);
}

export { PAIR, BASE_COLOR };
