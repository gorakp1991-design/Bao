import { Html } from "@react-three/drei";
import { useAppStore } from "@/store/app-store";
import { partMaterial, usePart } from "@/components/3d/bio-part";
import { lerp } from "@/lib/utils";

function Tag({ text, on }: { text: string; on: boolean }) {
  if (!on) return null;
  return (
    <Html center distanceFactor={9}>
      <span className="rounded-full border border-border bg-surface px-2 py-0.5 font-mono text-[10px] text-fg-muted whitespace-nowrap">
        {text}
      </span>
    </Html>
  );
}

function Chamber({
  id,
  label,
  color,
  pos,
  explode,
  scale = [1, 1, 1],
}: {
  id: string;
  label: string;
  color: string;
  pos: [number, number, number];
  explode: [number, number, number];
  scale?: [number, number, number];
}) {
  const { active, dimmed, transparency, exploded, bind } = usePart(id);
  const labels = useAppStore((s) => s.labels);
  const p: [number, number, number] = exploded ? explode : pos;
  return (
    <mesh position={p} scale={scale} {...bind}>
      <sphereGeometry args={[0.72, 24, 18]} />
      <meshStandardMaterial {...partMaterial({ color, active, dimmed, transparency, opacity: 0.88 })} />
      <Tag text={label} on={labels && (active || exploded)} />
    </mesh>
  );
}

export function HeartModel() {
  const aorta = usePart("aorta");
  const pa = usePart("pulmonary-artery");
  const valves = usePart("valves");
  const exploded = useAppStore((s) => s.exploded);
  const labels = useAppStore((s) => s.labels);
  const k = exploded ? 1 : 0;

  return (
    <group rotation={[0.15, 0.4, 0]}>
      <Chamber id="left-ventricle" label="Left ventricle" color="#e8897a" pos={[-0.45, -0.55, 0.1]} explode={[-1.35, -0.9, 0.2]} scale={[1.05, 1.2, 0.95]} />
      <Chamber id="right-ventricle" label="Right ventricle" color="#f0a898" pos={[0.5, -0.45, 0.05]} explode={[1.4, -0.8, 0.15]} scale={[0.9, 1, 0.9]} />
      <Chamber id="left-atrium" label="Left atrium" color="#c45c6a" pos={[-0.4, 0.55, 0.15]} explode={[-1.3, 1.15, 0.3]} scale={[0.85, 0.7, 0.8]} />
      <Chamber id="right-atrium" label="Right atrium" color="#d98b96" pos={[0.48, 0.5, 0.1]} explode={[1.35, 1.1, 0.25]} scale={[0.82, 0.68, 0.78]} />
      <mesh position={[lerp(0, 0, k), lerp(1.35, 2.1, k), 0]} {...aorta.bind}>
        <cylinderGeometry args={[0.16, 0.2, 1.1, 12]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#e7c27a", active: aorta.active, dimmed: aorta.dimmed, opacity: 0.95 })}
        />
        <Tag text="Aorta" on={labels && (aorta.active || exploded)} />
      </mesh>
      <mesh position={[lerp(0.15, 0.8, k), lerp(1.15, 1.9, k), 0.15]} rotation={[0.4, 0, 0.5]} {...pa.bind}>
        <cylinderGeometry args={[0.13, 0.16, 0.9, 12]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#7aa2ff", active: pa.active, dimmed: pa.dimmed, opacity: 0.95 })}
        />
        <Tag text="Pulmonary artery" on={labels && (pa.active || exploded)} />
      </mesh>
      <mesh position={[0, 0.05, 0.55]} {...valves.bind}>
        <torusGeometry args={[0.22, 0.04, 8, 18]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#e8eef6", active: valves.active, dimmed: valves.dimmed, opacity: 0.85 })}
        />
      </mesh>
    </group>
  );
}

export function LungsModel() {
  const lungs = usePart("alveoli");
  const bronchi = usePart("bronchi");
  const trachea = usePart("trachea");
  const dia = usePart("diaphragm");
  const exploded = useAppStore((s) => s.exploded);
  return (
    <group>
      <mesh position={exploded ? [-1.6, 0.2, 0] : [-0.85, 0.15, 0]} scale={[0.9, 1.25, 0.7]} {...lungs.bind}>
        <sphereGeometry args={[1, 24, 18]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#e8b4b8", active: lungs.active, dimmed: lungs.dimmed, transparency: true, opacity: 0.7 })}
        />
      </mesh>
      <mesh position={exploded ? [1.6, 0.2, 0] : [0.85, 0.15, 0]} scale={[0.82, 1.2, 0.68]} {...lungs.bind}>
        <sphereGeometry args={[1, 24, 18]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#e8b4b8", active: lungs.active, dimmed: lungs.dimmed, transparency: true, opacity: 0.7 })}
        />
      </mesh>
      <mesh position={[0, 1.55, 0]} {...trachea.bind}>
        <cylinderGeometry args={[0.16, 0.16, 1.1, 12]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#d7c4a3", active: trachea.active, dimmed: trachea.dimmed, opacity: 1 })}
        />
      </mesh>
      <mesh position={[-0.25, 0.9, 0]} rotation={[0, 0, 0.6]} {...bronchi.bind}>
        <cylinderGeometry args={[0.1, 0.12, 0.7, 10]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#d7c4a3", active: bronchi.active, dimmed: bronchi.dimmed, opacity: 1 })}
        />
      </mesh>
      <mesh position={[0.25, 0.9, 0]} rotation={[0, 0, -0.6]} {...bronchi.bind}>
        <cylinderGeometry args={[0.1, 0.12, 0.7, 10]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#d7c4a3", active: bronchi.active, dimmed: bronchi.dimmed, opacity: 1 })}
        />
      </mesh>
      <mesh position={[0, -1.5, 0]} rotation={[0.2, 0, 0]} {...dia.bind}>
        <sphereGeometry args={[1.4, 24, 12, 0, Math.PI * 2, 0, Math.PI / 3]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#c45c6a", active: dia.active, dimmed: dia.dimmed, opacity: 0.55 })}
        />
      </mesh>
    </group>
  );
}

export function KidneyModel() {
  const cortex = usePart("cortex");
  const medulla = usePart("medulla");
  const nephron = usePart("nephron");
  const pelvis = usePart("pelvis");
  const exploded = useAppStore((s) => s.exploded);
  return (
    <group rotation={[0, 0.4, 0.15]}>
      <mesh scale={[1.1, 1.45, 0.7]} {...cortex.bind}>
        <sphereGeometry args={[1.1, 28, 20]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#c45c6a", active: cortex.active, dimmed: cortex.dimmed, transparency: true, opacity: 0.45 })}
        />
      </mesh>
      <mesh scale={[0.7, 1, 0.45]} position={exploded ? [1.3, 0, 0] : [0, 0, 0]} {...medulla.bind}>
        <sphereGeometry args={[1, 20, 16]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#e8897a", active: medulla.active, dimmed: medulla.dimmed, opacity: 0.85 })}
        />
      </mesh>
      <mesh position={exploded ? [0.2, 0.4, 0.6] : [0.15, 0.25, 0.35]} {...nephron.bind}>
        <torusGeometry args={[0.18, 0.05, 8, 16]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#3ee0c5", active: nephron.active, dimmed: nephron.dimmed, opacity: 1 })}
        />
      </mesh>
      <mesh position={exploded ? [0, -1.8, 0] : [0, -1.2, 0]} {...pelvis.bind}>
        <coneGeometry args={[0.28, 0.7, 10]} />
        <meshStandardMaterial
          {...partMaterial({ color: "#e7c27a", active: pelvis.active, dimmed: pelvis.dimmed, opacity: 0.9 })}
        />
      </mesh>
    </group>
  );
}

export function DigestiveModel() {
  const stomach = usePart("stomach");
  const si = usePart("small-intestine");
  const liver = usePart("liver");
  const pancreas = usePart("pancreas");
  const li = usePart("large-intestine");
  const exploded = useAppStore((s) => s.exploded);
  return (
    <group>
      <mesh position={exploded ? [-1.6, 1.1, 0] : [-0.6, 0.85, 0]} rotation={[0.3, 0.2, -0.4]} scale={[1.1, 0.7, 0.7]} {...stomach.bind}>
        <sphereGeometry args={[0.7, 20, 14]} />
        <meshStandardMaterial {...partMaterial({ color: "#e8897a", active: stomach.active, dimmed: stomach.dimmed, opacity: 0.9 })} />
      </mesh>
      <mesh position={exploded ? [1.7, 1.2, 0] : [0.7, 1.05, 0]} rotation={[0, 0.3, 0.2]} scale={[1.3, 0.7, 0.9]} {...liver.bind}>
        <sphereGeometry args={[0.75, 20, 14]} />
        <meshStandardMaterial {...partMaterial({ color: "#a84c3a", active: liver.active, dimmed: liver.dimmed, opacity: 0.92 })} />
      </mesh>
      <mesh position={exploded ? [0, 0.2, 1.2] : [0.1, 0.35, 0.4]} rotation={[0, 0, 0.4]} {...pancreas.bind}>
        <cylinderGeometry args={[0.12, 0.16, 1.1, 10]} />
        <meshStandardMaterial {...partMaterial({ color: "#e7c27a", active: pancreas.active, dimmed: pancreas.dimmed, opacity: 0.95 })} />
      </mesh>
      <mesh position={exploded ? [0, -0.6, 0] : [0, -0.2, 0]} {...si.bind}>
        <torusGeometry args={[0.7, 0.12, 8, 32]} />
        <meshStandardMaterial {...partMaterial({ color: "#d4a574", active: si.active, dimmed: si.dimmed, opacity: 0.9 })} />
      </mesh>
      <mesh position={exploded ? [0, -1.8, 0] : [0, -1.15, 0]} {...li.bind}>
        <torusGeometry args={[1.05, 0.16, 8, 24, Math.PI * 1.4]} />
        <meshStandardMaterial {...partMaterial({ color: "#c45c6a", active: li.active, dimmed: li.dimmed, opacity: 0.88 })} />
      </mesh>
    </group>
  );
}

export function CirculatoryModel() {
  return (
    <group>
      <HeartModel />
      {Array.from({ length: 10 }).map((_, i) => {
        const a = (i / 10) * Math.PI * 2;
        return (
          <mesh key={i} position={[Math.cos(a) * 2.3, Math.sin(a * 1.4) * 0.4, Math.sin(a) * 2.3]}>
            <sphereGeometry args={[0.06, 8, 8]} />
            <meshStandardMaterial color={i % 2 ? "#e8897a" : "#7aa2ff"} emissive={i % 2 ? "#e8897a" : "#7aa2ff"} emissiveIntensity={0.4} />
          </mesh>
        );
      })}
    </group>
  );
}

export function RespiratoryModel() {
  return <LungsModel />;
}

export function NucleusModel() {
  const envelope = usePart("envelope");
  const pore = usePart("pore");
  const nucleolus = usePart("nucleolus");
  const chromatin = usePart("chromatin");
  return (
    <group>
      <mesh {...envelope.bind}>
        <sphereGeometry args={[1.6, 32, 24]} />
        <meshPhysicalMaterial color="#6b8cff" transparent opacity={0.25} roughness={0.2} />
      </mesh>
      {Array.from({ length: 8 }).map((_, i) => {
        const a = (i / 8) * Math.PI * 2;
        return (
          <mesh key={i} position={[Math.cos(a) * 1.55, Math.sin(a * 0.7) * 0.4, Math.sin(a) * 1.55]} {...pore.bind}>
            <sphereGeometry args={[0.12, 10, 10]} />
            <meshStandardMaterial {...partMaterial({ color: "#3ee0c5", active: pore.active, dimmed: pore.dimmed, opacity: 1 })} />
          </mesh>
        );
      })}
      <mesh {...nucleolus.bind}>
        <sphereGeometry args={[0.4, 16, 16]} />
        <meshStandardMaterial {...partMaterial({ color: "#c4b5fd", active: nucleolus.active, dimmed: nucleolus.dimmed, opacity: 1 })} />
      </mesh>
      <mesh rotation={[0.5, 0.3, 0]} {...chromatin.bind}>
        <torusGeometry args={[0.85, 0.05, 8, 32]} />
        <meshStandardMaterial {...partMaterial({ color: "#93a0b4", active: chromatin.active, dimmed: chromatin.dimmed, opacity: 0.8 })} />
      </mesh>
    </group>
  );
}

export function MitochondriaModel() {
  const outer = usePart("outer-membrane");
  const inner = usePart("inner-membrane");
  const matrix = usePart("matrix");
  const cristae = usePart("cristae");
  const exploded = useAppStore((s) => s.exploded);
  return (
    <group rotation={[0.3, 0.6, 0]}>
      <mesh scale={[1.8, 1, 1]} {...outer.bind}>
        <sphereGeometry args={[1.15, 28, 20]} />
        <meshPhysicalMaterial color="#e8897a" transparent opacity={0.22} roughness={0.3} />
      </mesh>
      <mesh scale={[1.5, 0.82, 0.82]} position={exploded ? [2.1, 0, 0] : [0, 0, 0]} {...inner.bind}>
        <sphereGeometry args={[1.05, 24, 18]} />
        <meshPhysicalMaterial color="#c45c6a" transparent opacity={0.35} roughness={0.35} />
      </mesh>
      <mesh position={exploded ? [2.1, 0, 0] : [0, 0, 0]} {...matrix.bind}>
        <sphereGeometry args={[0.55, 16, 16]} />
        <meshStandardMaterial {...partMaterial({ color: "#e7c27a", active: matrix.active, dimmed: matrix.dimmed, opacity: 0.7 })} />
      </mesh>
      {[-0.35, 0, 0.35].map((y) => (
        <mesh key={y} position={[exploded ? 2.1 : 0, y, 0]} rotation={[0.2, 0.4, 0]} {...cristae.bind}>
          <torusGeometry args={[0.55, 0.04, 8, 20]} />
          <meshStandardMaterial {...partMaterial({ color: "#f0a898", active: cristae.active, dimmed: cristae.dimmed, opacity: 0.9 })} />
        </mesh>
      ))}
    </group>
  );
}

export function RibosomeModel() {
  const small = usePart("small-subunit");
  const large = usePart("large-subunit");
  const epa = usePart("epa");
  const exploded = useAppStore((s) => s.exploded);
  return (
    <group>
      <mesh position={[0, exploded ? 0.7 : 0.28, 0]} {...small.bind}>
        <sphereGeometry args={[0.7, 24, 18]} />
        <meshStandardMaterial {...partMaterial({ color: "#93a0b4", active: small.active, dimmed: small.dimmed, opacity: 0.95 })} />
      </mesh>
      <mesh position={[0, exploded ? -0.8 : -0.45, 0]} scale={[1.15, 0.9, 1.1]} {...large.bind}>
        <sphereGeometry args={[0.95, 24, 18]} />
        <meshStandardMaterial {...partMaterial({ color: "#6b7789", active: large.active, dimmed: large.dimmed, opacity: 0.95 })} />
      </mesh>
      {[-0.25, 0, 0.25].map((x, i) => (
        <mesh key={i} position={[x, 0, 0.7]} {...epa.bind}>
          <sphereGeometry args={[0.12, 10, 10]} />
          <meshStandardMaterial color={["#3ee0c5", "#e7c27a", "#e8897a"][i]} />
        </mesh>
      ))}
    </group>
  );
}

export function ChromosomeModel() {
  const chromatid = usePart("chromatid");
  const centromere = usePart("centromere");
  const telomere = usePart("telomere");
  return (
    <group rotation={[0.2, 0.4, 0.1]}>
      {[-0.18, 0.18].map((x) => (
        <group key={x} position={[x, 0, 0]} {...chromatid.bind}>
          <mesh position={[0, 0.7, 0]}>
            <capsuleGeometry args={[0.16, 1.1, 6, 12]} />
            <meshStandardMaterial {...partMaterial({ color: "#6b8cff", active: chromatid.active, dimmed: chromatid.dimmed, opacity: 1 })} />
          </mesh>
          <mesh position={[0, -0.7, 0]}>
            <capsuleGeometry args={[0.16, 1.1, 6, 12]} />
            <meshStandardMaterial {...partMaterial({ color: "#6b8cff", active: chromatid.active, dimmed: chromatid.dimmed, opacity: 1 })} />
          </mesh>
        </group>
      ))}
      <mesh {...centromere.bind}>
        <sphereGeometry args={[0.22, 12, 12]} />
        <meshStandardMaterial {...partMaterial({ color: "#e7c27a", active: centromere.active, dimmed: centromere.dimmed, opacity: 1 })} />
      </mesh>
      {[-1.35, 1.35].map((y) => (
        <mesh key={y} position={[0.18, y, 0]} {...telomere.bind}>
          <sphereGeometry args={[0.12, 10, 10]} />
          <meshStandardMaterial {...partMaterial({ color: "#3ee0c5", active: telomere.active, dimmed: telomere.dimmed, opacity: 1 })} />
        </mesh>
      ))}
    </group>
  );
}

export function RNAModel() {
  const mrna = usePart("mrna");
  const trna = usePart("trna");
  const rrna = usePart("rrna");
  return (
    <group>
      {Array.from({ length: 18 }).map((_, i) => {
        const y = (i / 17 - 0.5) * 4.5;
        const x = Math.sin(i * 0.7) * 0.35;
        return (
          <mesh key={i} position={[x, y, 0]} {...mrna.bind}>
            <sphereGeometry args={[0.14, 10, 10]} />
            <meshStandardMaterial color={["#f07178", "#ffd166", "#06d6a0", "#64b5f6"][i % 4]} />
          </mesh>
        );
      })}
      <mesh position={[1.6, 0.4, 0.3]} {...trna.bind}>
        <capsuleGeometry args={[0.12, 0.7, 6, 10]} />
        <meshStandardMaterial {...partMaterial({ color: "#e7c27a", active: trna.active, dimmed: trna.dimmed, opacity: 1 })} />
      </mesh>
      <mesh position={[-1.5, -0.2, 0]} {...rrna.bind}>
        <sphereGeometry args={[0.55, 16, 16]} />
        <meshStandardMaterial {...partMaterial({ color: "#93a0b4", active: rrna.active, dimmed: rrna.dimmed, opacity: 0.9 })} />
      </mesh>
    </group>
  );
}
