import { useMemo } from "react";
import * as THREE from "three";
import { Html } from "@react-three/drei";
import { DNAModel } from "@/components/3d/models/dna";
import { NeuronModel } from "@/components/3d/models/neuron";
import { HeartModel } from "@/components/3d/models/organs";
import { ChloroplastModel } from "@/components/3d/models/plants";
import { lerp, smoothstep } from "@/lib/utils";
import { getProcess, stageAt } from "@/data/processes";
import { useAppStore } from "@/store/app-store";

export function ProcessScene({ processId, t }: { processId: string; t: number }) {
  switch (processId) {
    case "dna-replication":
      return <DNAModel replication={t} />;
    case "transcription":
      return <DNAModel transcription={t} />;
    case "neural-signal":
      return <NeuronModel signal={t} />;
    case "blood-circulation":
      return <CirculationScene t={t} />;
    case "photosynthesis":
      return <PhotosynthesisScene t={t} />;
    case "mitosis":
      return <MitosisScene t={t} />;
    case "meiosis":
      return <MeiosisScene t={t} />;
    case "translation":
      return <TranslationScene t={t} />;
    case "cellular-respiration":
      return <RespirationScene t={t} />;
    default:
      return <GenericProcessScene processId={processId} t={t} />;
  }
}

function Chromosome({ position, split, color }: { position: [number, number, number]; split: number; color: string }) {
  return (
    <group position={position}>
      <mesh position={[-0.08 - split * 0.35, 0, 0]}>
        <capsuleGeometry args={[0.07, 0.55, 4, 8]} />
        <meshStandardMaterial color={color} />
      </mesh>
      <mesh position={[0.08 + split * 0.35, 0, 0]}>
        <capsuleGeometry args={[0.07, 0.55, 4, 8]} />
        <meshStandardMaterial color={color} />
      </mesh>
    </group>
  );
}

function MitosisScene({ t }: { t: number }) {
  const labels = useAppStore((s) => s.labels);
  const process = getProcess("mitosis");
  const stage = stageAt(process, t);
  const condense = smoothstep(0.12, 0.32, t);
  const align = smoothstep(0.32, 0.5, t);
  const split = smoothstep(0.5, 0.68, t);
  const nuclei = smoothstep(0.68, 0.86, t);
  const pinch = smoothstep(0.84, 1, t);
  const xs = [-0.55, -0.18, 0.18, 0.55];

  return (
    <group>
      <mesh position={[-pinch * 1.35, 0, 0]} scale={[1 - pinch * 0.15, 1, 1]}>
        <sphereGeometry args={[2.2, 32, 24]} />
        <meshPhysicalMaterial color="#3d8f9e" transparent opacity={0.12} />
      </mesh>
      <mesh position={[pinch * 1.35, 0, 0]} scale={[1 - pinch * 0.15, 1, 1]} visible={pinch > 0.15}>
        <sphereGeometry args={[2.2, 32, 24]} />
        <meshPhysicalMaterial color="#3d8f9e" transparent opacity={0.12} />
      </mesh>
      <mesh scale={1 - condense * 0.9} visible={nuclei < 0.2}>
        <sphereGeometry args={[0.9, 24, 18]} />
        <meshPhysicalMaterial color="#6b8cff" transparent opacity={0.35 * (1 - condense)} />
      </mesh>
      {xs.map((x0, i) => {
        const yAlign = lerp((i % 2 ? 0.45 : -0.4) * (1 - align), 0, align);
        const ySplit = split * (i % 2 ? 1.15 : -1.15);
        const x = lerp(x0 * 0.4, x0, align);
        return (
          <Chromosome
            key={i}
            position={[x, yAlign + ySplit, 0]}
            split={split}
            color={i % 2 ? "#6b8cff" : "#3ee0c5"}
          />
        );
      })}
      {nuclei > 0.2 ? (
        <>
          <mesh position={[0, 1.05, 0]} scale={nuclei}>
            <sphereGeometry args={[0.55, 16, 12]} />
            <meshPhysicalMaterial color="#6b8cff" transparent opacity={0.35} />
          </mesh>
          <mesh position={[0, -1.05, 0]} scale={nuclei}>
            <sphereGeometry args={[0.55, 16, 12]} />
            <meshPhysicalMaterial color="#6b8cff" transparent opacity={0.35} />
          </mesh>
        </>
      ) : null}
      {labels ? (
        <Html position={[0, 2.4, 0]} center>
          <span className="rounded-full bg-surface px-3 py-1 font-mono text-[11px] tracking-wide text-accent">
            {stage.name}
          </span>
        </Html>
      ) : null}
    </group>
  );
}

function MeiosisScene({ t }: { t: number }) {
  const pair = smoothstep(0, 0.22, t);
  const reduce = smoothstep(0.38, 0.55, t);
  const four = smoothstep(0.64, 1, t);
  return (
    <group>
      <mesh>
        <sphereGeometry args={[2.3, 32, 24]} />
        <meshPhysicalMaterial color="#3d8f9e" transparent opacity={0.1} />
      </mesh>
      {[-0.4, 0.4].map((x) => (
        <Chromosome key={x} position={[x * (1 + reduce), lerp(0, x > 0 ? 0.9 : -0.9, reduce), 0]} split={four} color="#c4b5fd" />
      ))}
      {[-0.15, 0.15].map((x) => (
        <Chromosome key={`h${x}`} position={[x * (1 + reduce * 0.4) * pair, 0, 0.2]} split={four * 0.6} color="#3ee0c5" />
      ))}
      {four > 0.4
        ? [
            [-1.2, 0.9],
            [1.2, 0.9],
            [-1.2, -0.9],
            [1.2, -0.9],
          ].map((p, i) => (
            <mesh key={i} position={[p[0]!, p[1]!, 0]} scale={four}>
              <sphereGeometry args={[0.45, 14, 12]} />
              <meshPhysicalMaterial color="#6b8cff" transparent opacity={0.25} />
            </mesh>
          ))
        : null}
    </group>
  );
}

function TranslationScene({ t }: { t: number }) {
  const n = Math.floor(lerp(2, 12, t));
  return (
    <group>
      {Array.from({ length: 16 }).map((_, i) => (
        <mesh key={i} position={[(i - 8) * 0.28, 0.35, 0]}>
          <boxGeometry args={[0.22, 0.22, 0.22]} />
          <meshStandardMaterial color={["#f07178", "#ffd166", "#06d6a0", "#64b5f6"][i % 4]} />
        </mesh>
      ))}
      <mesh position={[lerp(-1.6, 1.6, t), 0, 0]}>
        <sphereGeometry args={[0.55, 16, 16]} />
        <meshStandardMaterial color="#93a0b4" />
      </mesh>
      {Array.from({ length: n }).map((_, i) => (
        <mesh key={i} position={[-1.4 + i * 0.22, -0.55, 0]}>
          <sphereGeometry args={[0.1, 10, 10]} />
          <meshStandardMaterial color="#e7c27a" />
        </mesh>
      ))}
    </group>
  );
}

function PhotosynthesisScene({ t }: { t: number }) {
  const bubbles = Math.floor(t * 10);
  return (
    <group>
      <ChloroplastModel />
      <mesh position={[-2.2, 1.2, 0]}>
        <sphereGeometry args={[0.18, 12, 12]} />
        <meshStandardMaterial color="#93a0b4" emissive="#e7c27a" emissiveIntensity={0.3 + t} />
      </mesh>
      {Array.from({ length: bubbles }).map((_, i) => (
        <mesh key={i} position={[1.6 + (i % 3) * 0.15, -0.8 + (i * 0.22 + t) % 2.2, 0.2]}>
          <sphereGeometry args={[0.07, 8, 8]} />
          <meshStandardMaterial color="#7ee0a8" emissive="#7ee0a8" emissiveIntensity={0.6} />
        </mesh>
      ))}
    </group>
  );
}

function CirculationScene({ t }: { t: number }) {
  const a = t * Math.PI * 2;
  return (
    <group>
      <HeartModel />
      <mesh position={[Math.cos(a) * 2.4, Math.sin(a * 2) * 0.5, Math.sin(a) * 2.4]}>
        <sphereGeometry args={[0.12, 10, 10]} />
        <meshStandardMaterial color="#e8897a" emissive="#e8897a" emissiveIntensity={0.8} />
      </mesh>
    </group>
  );
}

function RespirationScene({ t }: { t: number }) {
  return (
    <group>
      <mesh scale={[1.8, 1, 1]}>
        <sphereGeometry args={[1.1, 24, 16]} />
        <meshPhysicalMaterial color="#e8897a" transparent opacity={0.2} />
      </mesh>
      {Array.from({ length: 8 }).map((_, i) => (
        <mesh key={i} position={[Math.cos(i) * 0.5, Math.sin(i + t * 6) * 0.35, Math.sin(i) * 0.4]}>
          <sphereGeometry args={[0.08, 8, 8]} />
          <meshStandardMaterial color={t > 0.7 ? "#3ee0c5" : "#e7c27a"} />
        </mesh>
      ))}
    </group>
  );
}

function GenericProcessScene({ processId, t }: { processId: string; t: number }) {
  const process = getProcess(processId);
  const stage = stageAt(process, t);
  const curve = useMemo(
    () => new THREE.CatmullRomCurve3([new THREE.Vector3(-2, 0, 0), new THREE.Vector3(0, 0.6, 0), new THREE.Vector3(2, 0, 0)]),
    [],
  );
  const p = curve.getPoint(t);
  const labels = useAppStore((s) => s.labels);
  return (
    <group>
      <mesh>
        <torusGeometry args={[1.6, 0.04, 8, 48]} />
        <meshStandardMaterial color="#1e2634" />
      </mesh>
      {process.stages.map((s, i) => {
        const a = (i / process.stages.length) * Math.PI * 2;
        const on = stage.id === s.id;
        return (
          <mesh key={s.id} position={[Math.cos(a) * 1.6, 0, Math.sin(a) * 1.6]}>
            <sphereGeometry args={[on ? 0.16 : 0.1, 12, 12]} />
            <meshStandardMaterial color={on ? "#3ee0c5" : "#6b7789"} emissive={on ? "#3ee0c5" : "#000"} emissiveIntensity={on ? 0.6 : 0} />
          </mesh>
        );
      })}
      <mesh position={p}>
        <icosahedronGeometry args={[0.28, 0]} />
        <meshStandardMaterial color="#7ee0a8" emissive="#7ee0a8" emissiveIntensity={0.4} />
      </mesh>
      {labels ? (
        <Html position={[0, 2.1, 0]} center>
          <span className="rounded-full bg-surface px-3 py-1 font-mono text-[11px] text-accent">{stage.name}</span>
        </Html>
      ) : null}
    </group>
  );
}
