import { DNAModel } from "@/components/3d/models/dna";
import { AnimalCell, PlantCell } from "@/components/3d/models/cell";
import {
  HeartModel,
  LungsModel,
  KidneyModel,
  DigestiveModel,
  CirculatoryModel,
  RespiratoryModel,
  NucleusModel,
  MitochondriaModel,
  RibosomeModel,
  ChromosomeModel,
  RNAModel,
} from "@/components/3d/models/organs";
import { NeuronModel } from "@/components/3d/models/neuron";
import { HumanBodyModel } from "@/components/3d/models/human-body";
import { ChloroplastModel, FlowerModel, LeafModel, RootModel } from "@/components/3d/models/plants";
import { GenericModel } from "@/components/3d/models/generic";
import { useAppStore } from "@/store/app-store";

export function BiologyModel({ topicId }: { topicId: string }) {
  const compare = useAppStore((s) => s.compare);
  switch (topicId) {
    case "dna":
      return <DNAModel />;
    case "rna":
      return <RNAModel />;
    case "animal-cell":
      return compare ? (
        <group>
          <group position={[-2.4, 0, 0]} scale={0.72}>
            <AnimalCell />
          </group>
          <group position={[2.4, 0, 0]} scale={0.72}>
            <PlantCell />
          </group>
        </group>
      ) : (
        <AnimalCell />
      );
    case "plant-cell":
      return compare ? (
        <group>
          <group position={[-2.4, 0, 0]} scale={0.72}>
            <AnimalCell />
          </group>
          <group position={[2.4, 0, 0]} scale={0.72}>
            <PlantCell />
          </group>
        </group>
      ) : (
        <PlantCell />
      );
    case "heart":
      return <HeartModel />;
    case "lungs":
      return <LungsModel />;
    case "kidney":
      return <KidneyModel />;
    case "digestive-system":
      return <DigestiveModel />;
    case "respiratory-system":
      return <RespiratoryModel />;
    case "circulatory-system":
      return <CirculatoryModel />;
    case "nucleus":
      return <NucleusModel />;
    case "mitochondria":
      return <MitochondriaModel />;
    case "ribosome":
      return <RibosomeModel />;
    case "chromosome":
      return <ChromosomeModel />;
    case "neuron":
      return <NeuronModel />;
    case "human-body":
      return <HumanBodyModel />;
    case "chloroplast":
      return <ChloroplastModel />;
    case "flower":
      return <FlowerModel />;
    case "leaf":
      return <LeafModel />;
    case "root":
      return <RootModel />;
    default:
      return <GenericModel topicId={topicId} />;
  }
}
