import { useState } from "react";
import { List, Info } from "lucide-react";
import { CATEGORY_LABEL, TOPICS } from "@/data/catalog";
import { useAppStore } from "@/store/app-store";
import { InfoPanel } from "@/components/biology/info-panel";
import { ViewerToolbar } from "@/components/biology/viewer-toolbar";
import { Timeline } from "@/components/biology/timeline";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-media";
import { useProgress } from "@/store/progress-store";

export function LabFrame({
  children,
  topicId,
  processId,
  explore,
  onExplorePick,
}: {
  children: React.ReactNode;
  topicId: string;
  processId?: string;
  explore?: { id: string; name: string }[];
  onExplorePick?: (id: string) => void;
}) {
  const mobile = useIsMobile();
  const [left, setLeft] = useState(false);
  const [right, setRight] = useState(false);
  const setTopic = useAppStore((s) => s.setTopic);
  const current = processId ?? useAppStore((s) => s.selectedTopic);
  const mark = useProgress((s) => s.markExplored);
  const items = explore ?? TOPICS.map((t) => ({ id: t.id, name: t.name }));

  const pick = (id: string) => {
    if (onExplorePick) onExplorePick(id);
    else {
      setTopic(id);
      mark(id);
    }
    setLeft(false);
  };

  return (
    <div className="relative flex h-full bg-bg-deep">
      <aside className="hidden w-[260px] shrink-0 overflow-y-auto border-r border-border bg-surface/60 md:block">
        <ExploreList items={items} current={current} onPick={pick} />
      </aside>
      <div className="relative min-w-0 flex-1" id="bio-viewport">
        {children}
        <div className="pointer-events-none absolute inset-x-0 top-3 z-10 flex justify-center px-3">
          <ViewerToolbar />
        </div>
        <div className="absolute bottom-3 left-3 right-3 z-10 md:left-4 md:right-4">
          {processId ? <Timeline processId={processId} /> : <MiniHint />}
        </div>
        {mobile ? (
          <div className="absolute bottom-28 left-3 right-3 z-10 flex justify-between">
            <Button size="icon" variant="secondary" aria-label="Explore" onClick={() => setLeft(true)}>
              <List className="size-4" />
            </Button>
            <Button size="icon" variant="secondary" aria-label="Info" onClick={() => setRight(true)}>
              <Info className="size-4" />
            </Button>
          </div>
        ) : null}
      </div>
      <aside className="hidden w-[300px] shrink-0 overflow-hidden border-l border-border bg-surface/60 md:block">
        <InfoPanel topicId={topicId} />
      </aside>
      {left ? (
        <Sheet onClose={() => setLeft(false)}>
          <ExploreList items={items} current={current} onPick={pick} />
        </Sheet>
      ) : null}
      {right ? (
        <Sheet onClose={() => setRight(false)}>
          <InfoPanel topicId={topicId} />
        </Sheet>
      ) : null}
    </div>
  );
}

function MiniHint() {
  return (
    <p className="text-center font-mono text-[10px] tracking-[0.2em] text-fg-subtle">
      DRAG TO ORBIT · PINCH TO ZOOM · TAP STRUCTURES
    </p>
  );
}

function ExploreList({
  items,
  current,
  onPick,
}: {
  items: { id: string; name: string }[];
  current: string;
  onPick: (id: string) => void;
}) {
  return (
    <div className="p-3">
      <p className="px-2 pb-2 font-mono text-[10px] tracking-[0.22em] text-fg-subtle">EXPLORE</p>
      <ul className="space-y-0.5">
        {items.map((item) => {
          const cat = TOPICS.find((t) => t.id === item.id)?.category;
          return (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => onPick(item.id)}
                className={cn(
                  "flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left text-sm",
                  current === item.id ? "bg-accent/15 text-accent" : "text-fg-muted hover:bg-surface-3 hover:text-fg",
                )}
              >
                {item.name}
                {cat ? <span className="text-[10px] text-fg-subtle">{CATEGORY_LABEL[cat]}</span> : null}
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function Sheet({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="absolute inset-0 z-20 bg-bg/50 md:hidden" onClick={onClose}>
      <div
        className="absolute inset-x-0 bottom-0 max-h-[70vh] overflow-y-auto rounded-t-2xl bg-surface pb-16"
        onClick={(e) => e.stopPropagation()}
      >
        {children}
      </div>
    </div>
  );
}
