import { useAppStore } from "@/store/app-store";
import { Button } from "@/components/ui/button";
import type { ClassLevel, Quality } from "@/data/types";

export function SettingsDrawer() {
  const open = useAppStore((s) => s.settingsOpen);
  const setOpen = useAppStore((s) => s.setSettingsOpen);
  const quality = useAppStore((s) => s.quality);
  const setQuality = useAppStore((s) => s.setQuality);
  const highContrast = useAppStore((s) => s.highContrast);
  const setHighContrast = useAppStore((s) => s.setHighContrast);
  const reduced = useAppStore((s) => s.reducedMotion);
  const setReduced = useAppStore((s) => s.setReducedMotion);
  const level = useAppStore((s) => s.classLevel);
  const setLevel = useAppStore((s) => s.setClassLevel);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-bg/50" onClick={() => setOpen(false)}>
      <aside
        className="glass flex h-full w-full max-w-sm flex-col gap-5 p-5"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-label="Settings"
      >
        <div className="flex items-center justify-between">
          <h2 className="font-display text-lg">Lab settings</h2>
          <Button variant="ghost" onClick={() => setOpen(false)}>
            Close
          </Button>
        </div>
        <Field label="Graphics quality">
          <div className="grid grid-cols-3 gap-2">
            {(["low", "medium", "high"] as Quality[]).map((q) => (
              <Button key={q} variant={quality === q ? "default" : "secondary"} onClick={() => setQuality(q)}>
                {q}
              </Button>
            ))}
          </div>
        </Field>
        <Field label="Learning level">
          <div className="grid grid-cols-4 gap-2">
            {([9, 10, 11, 12] as ClassLevel[]).map((n) => (
              <Button key={n} variant={level === n ? "default" : "secondary"} onClick={() => setLevel(n)}>
                {n}
              </Button>
            ))}
          </div>
        </Field>
        <label className="flex items-center justify-between gap-3 text-sm">
          High contrast
          <input type="checkbox" checked={highContrast} onChange={(e) => setHighContrast(e.target.checked)} />
        </label>
        <label className="flex items-center justify-between gap-3 text-sm">
          Reduced motion
          <input type="checkbox" checked={reduced} onChange={(e) => setReduced(e.target.checked)} />
        </label>
        <p className="text-xs leading-relaxed text-fg-subtle">
          Default quality is lower on phones. 3D models are procedural so the lab still runs if a file is missing.
        </p>
      </aside>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <p className="font-mono text-[10px] tracking-[0.2em] text-fg-subtle">{label.toUpperCase()}</p>
      {children}
    </div>
  );
}
