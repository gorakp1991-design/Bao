import { Link } from "@tanstack/react-router";
import { Bot, Search, Settings2, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAppStore } from "@/store/app-store";

export function TopBar() {
  const setSearchOpen = useAppStore((s) => s.setSearchOpen);
  const setTutorOpen = useAppStore((s) => s.setTutorOpen);
  const setSettingsOpen = useAppStore((s) => s.setSettingsOpen);
  const level = useAppStore((s) => s.classLevel);

  return (
    <header className="sticky top-0 z-40 flex h-14 items-center gap-2 border-b border-border bg-bg/90 px-3 backdrop-blur-md md:h-15 md:px-5">
      <Link to="/" className="flex items-center gap-2 pr-2">
        <span className="grid size-8 place-items-center rounded-md bg-accent/15 font-display text-xs text-accent">
          BV
        </span>
        <span className="font-display text-sm tracking-[0.18em] text-fg">BIOVERSE</span>
      </Link>
      <nav className="ml-4 hidden items-center gap-1 md:flex">
        <Nav to="/lab" label="Lab" />
        <Nav to="/four-d" label="4D" />
        <Nav to="/dna" label="DNA" />
        <Nav to="/human-body" label="Body" />
        <Nav to="/learn" label="Learn" />
        <Nav to="/quiz" label="Quiz" />
        <Nav to="/dashboard" label="Dashboard" />
      </nav>
      <div className="ml-auto flex items-center gap-1">
        <Button variant="secondary" size="sm" className="hidden sm:inline-flex" onClick={() => setSearchOpen(true)}>
          <Search className="size-4" />
          Search Biology
        </Button>
        <Button size="icon" variant="ghost" aria-label="Search" className="sm:hidden" onClick={() => setSearchOpen(true)}>
          <Search className="size-4" />
        </Button>
        <Button size="icon" variant="ghost" aria-label="AI Tutor" onClick={() => setTutorOpen(true)}>
          <Bot className="size-4" />
        </Button>
        <Button size="icon" variant="ghost" aria-label="Settings" onClick={() => setSettingsOpen(true)}>
          <Settings2 className="size-4" />
        </Button>
        <Button size="icon" variant="ghost" aria-label="Profile" title={`Class ${level} learner`}>
          <User className="size-4" />
        </Button>
      </div>
    </header>
  );
}

function Nav({ to, label }: { to: string; label: string }) {
  return (
    <Link
      to={to}
      className="rounded-md px-3 py-2 text-sm text-fg-muted hover:bg-surface-2 hover:text-fg data-[status=active]:text-accent"
      activeProps={{ className: "text-accent" }}
    >
      {label}
    </Link>
  );
}
