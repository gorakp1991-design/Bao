import { Link, useRouterState } from "@tanstack/react-router";
import { Bot, FlaskConical, Home, Layers3, GraduationCap } from "lucide-react";
import { TopBar } from "@/components/layout/top-bar";
import { SearchDialog } from "@/components/search/search-dialog";
import { TutorDrawer } from "@/components/ai/tutor-panel";
import { SettingsDrawer } from "@/components/layout/settings-drawer";
import { DemoController } from "@/components/demo/demo-controller";
import { useProgress } from "@/store/progress-store";
import { hydrateClientSettings, useAppStore } from "@/store/app-store";
import { useEffect } from "react";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Home", icon: Home },
  { to: "/lab", label: "Explore", icon: FlaskConical },
  { to: "/four-d", label: "4D", icon: Layers3 },
  { to: "/learn", label: "Learn", icon: GraduationCap },
  { to: "/tutor", label: "AI", icon: Bot },
] as const;

export function AppShell({ children, lab }: { children: React.ReactNode; lab?: boolean }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hydrate = useProgress((s) => s.hydrate);

  useEffect(() => {
    hydrate();
    hydrateClientSettings();
  }, [hydrate]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      const typing = tag === "INPUT" || tag === "TEXTAREA";
      if (e.key === "Escape") {
        const s = useAppStore.getState();
        s.setSearchOpen(false);
        s.setTutorOpen(false);
        s.setSettingsOpen(false);
      }
      if (!typing && e.key === "/") {
        e.preventDefault();
        useAppStore.getState().setSearchOpen(true);
      }
      if (!typing && e.key === " " && (pathname.includes("four-d") || pathname.includes("4d") || pathname.includes("dna") || pathname.includes("neuron"))) {
        e.preventDefault();
        const s = useAppStore.getState();
        s.setPlaying(!s.playing);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [pathname]);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-accent focus:px-3 focus:py-2 focus:text-accent-fg"
      >
        Skip to content
      </a>
      <TopBar />
      <div id="main" className={cn(lab ? "h-[calc(100dvh-3.5rem)]" : "pb-20 md:pb-0")}>
        {children}
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-surface/95 backdrop-blur-md md:hidden">
        <ul className="grid grid-cols-5">
          {NAV.map((item) => {
            const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "flex h-14 flex-col items-center justify-center gap-0.5 text-[10px]",
                    active ? "text-accent" : "text-fg-muted",
                  )}
                >
                  <Icon className="size-5" />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      <SearchDialog />
      <TutorDrawer />
      <SettingsDrawer />
      <DemoController />
    </div>
  );
}
