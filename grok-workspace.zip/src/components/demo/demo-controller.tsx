import { useEffect } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useAppStore } from "@/store/app-store";
import { useProgress } from "@/store/progress-store";
import { Button } from "@/components/ui/button";

const STEPS = [
  { title: "Lobby", copy: "BioVerse is a virtual biology laboratory. Next we enter the 3D lab.", to: "/", search: undefined as { topic?: string; process?: string } | undefined },
  { title: "Enter the lab", copy: "The viewport is a real WebGL scene. Drag to orbit the cell.", to: "/lab", search: { topic: "animal-cell" } },
  { title: "Inspect mitochondria", copy: "Click a bean-shaped mitochondrion. The inspector updates from the model.", to: "/lab", search: { topic: "animal-cell" }, part: "mitochondria" },
  { title: "4D mitosis", copy: "Time is the fourth axis. Press Play and watch chromosomes move through stages.", to: "/four-d", search: { process: "mitosis" }, play: true },
  { title: "DNA explorer", copy: "Rotate the helix and tap A, T, G or C to see complementary pairing.", to: "/dna", search: undefined },
  { title: "Ask BIO-BOT", copy: "The tutor knows which model you are viewing. Try “Why is this important?”", to: "/tutor", search: undefined, tutor: true },
  { title: "Quiz", copy: "Finish with a hotspot question — click the real 3D structure.", to: "/quiz", search: undefined },
];

export function DemoController() {
  const active = useAppStore((s) => s.demoActive);
  const step = useAppStore((s) => s.demoStep);
  const setDemo = useAppStore((s) => s.setDemo);
  const setTopic = useAppStore((s) => s.setTopic);
  const selectPart = useAppStore((s) => s.selectPart);
  const setProcess = useAppStore((s) => s.setProcess);
  const setPlaying = useAppStore((s) => s.setPlaying);
  const setTutorOpen = useAppStore((s) => s.setTutorOpen);
  const award = useProgress((s) => s.award);
  const navigate = useNavigate();

  const current = STEPS[step] ?? STEPS[0]!;

  useEffect(() => {
    if (!active) return;
    const s = STEPS[step];
    if (!s) return;
    if (s.search?.topic) setTopic(s.search.topic);
    if (s.search?.process) setProcess(s.search.process);
    if (s.part) selectPart(s.part);
    setPlaying(Boolean(s.play));
    setTutorOpen(Boolean(s.tutor));
    void navigate({ to: s.to, search: s.search } as never);
  }, [active, step, navigate, setTopic, selectPart, setProcess, setPlaying, setTutorOpen]);

  if (!active) return null;

  const last = step >= STEPS.length - 1;

  return (
    <div className="pointer-events-none fixed inset-x-0 top-16 z-40 flex justify-center px-3">
      <div className="pointer-events-auto glass max-w-lg rounded-2xl p-4">
        <p className="font-mono text-[10px] tracking-[0.22em] text-accent">
          DEMO {step + 1}/{STEPS.length}
        </p>
        <h3 className="mt-1 font-display text-lg">{current.title}</h3>
        <p className="mt-1 text-sm text-fg-muted">{current.copy}</p>
        <div className="mt-3 flex gap-2">
          <Button
            size="sm"
            onClick={() => {
              if (last) {
                award("demo-complete");
                setDemo(false);
                setTutorOpen(false);
                setPlaying(false);
                return;
              }
              setDemo(true, step + 1);
            }}
          >
            {last ? "Finish" : "Next"}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              setDemo(false);
              setTutorOpen(false);
              setPlaying(false);
            }}
          >
            Skip demo
          </Button>
        </div>
      </div>
    </div>
  );
}

export function startDemo() {
  useAppStore.getState().setDemo(true, 0);
}
