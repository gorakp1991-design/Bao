import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export function NotFound() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-bg px-6 text-center text-fg">
      <p className="font-mono text-xs tracking-[0.3em] text-accent">404</p>
      <h1 className="font-display text-3xl">This specimen is not in the catalogue</h1>
      <p className="max-w-md text-sm text-fg-muted">
        The page you requested is outside the BioVerse lab. Return to the lobby or enter the 3D lab.
      </p>
      <div className="flex gap-3">
        <Button asChild>
          <Link to="/">Lobby</Link>
        </Button>
        <Button variant="secondary" asChild>
          <Link to="/lab">Enter lab</Link>
        </Button>
      </div>
    </main>
  );
}
