import { create } from "zustand";
import type { ClassLevel, Quality, Speed } from "@/data/types";

function detectQuality(): Quality {
  if (typeof window === "undefined") return "medium";
  const mobile = window.matchMedia("(max-width: 768px)").matches;
  const cores = navigator.hardwareConcurrency ?? 4;
  const saveData = Boolean((navigator as Navigator & { connection?: { saveData?: boolean } }).connection?.saveData);
  if (saveData || mobile || cores <= 4) return "low";
  if (cores <= 8) return "medium";
  return "high";
}

function detectReducedMotion() {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

type AppState = {
  quality: Quality;
  labels: boolean;
  highContrast: boolean;
  reducedMotion: boolean;
  transparency: boolean;
  exploded: boolean;
  isolatedPart: string | null;
  compare: boolean;
  selectedTopic: string;
  selectedPart: string | null;
  selectedProcess: string;
  playing: boolean;
  speed: Speed;
  progress: number;
  classLevel: ClassLevel;
  tutorOpen: boolean;
  searchOpen: boolean;
  settingsOpen: boolean;
  demoActive: boolean;
  demoStep: number;
  bodySystems: Record<string, boolean>;
  setQuality: (q: Quality) => void;
  setLabels: (v: boolean) => void;
  setHighContrast: (v: boolean) => void;
  setReducedMotion: (v: boolean) => void;
  setTransparency: (v: boolean) => void;
  setExploded: (v: boolean) => void;
  setIsolated: (id: string | null) => void;
  setCompare: (v: boolean) => void;
  setTopic: (id: string) => void;
  selectPart: (id: string | null) => void;
  setProcess: (id: string) => void;
  setPlaying: (v: boolean) => void;
  setSpeed: (v: Speed) => void;
  setProgress: (v: number) => void;
  setClassLevel: (v: ClassLevel) => void;
  setTutorOpen: (v: boolean) => void;
  setSearchOpen: (v: boolean) => void;
  setSettingsOpen: (v: boolean) => void;
  setDemo: (active: boolean, step?: number) => void;
  toggleSystem: (id: string) => void;
  resetView: () => void;
};

const SYSTEMS = {
  skeletal: true,
  muscular: false,
  nervous: false,
  circulatory: true,
  respiratory: false,
  digestive: false,
  urinary: false,
  endocrine: false,
  reproductive: false,
  skin: false,
};

export const useAppStore = create<AppState>((set) => ({
  quality: "medium",
  labels: true,
  highContrast: false,
  reducedMotion: false,
  transparency: true,
  exploded: false,
  isolatedPart: null,
  compare: false,
  selectedTopic: "animal-cell",
  selectedPart: null,
  selectedProcess: "mitosis",
  playing: false,
  speed: 1,
  progress: 0,
  classLevel: 10,
  tutorOpen: false,
  searchOpen: false,
  settingsOpen: false,
  demoActive: false,
  demoStep: 0,
  bodySystems: { ...SYSTEMS },
  setQuality: (quality) => set({ quality }),
  setLabels: (labels) => set({ labels }),
  setHighContrast: (highContrast) => {
    set({ highContrast });
    if (typeof document !== "undefined") document.documentElement.classList.toggle("high-contrast", highContrast);
  },
  setReducedMotion: (reducedMotion) => {
    set({ reducedMotion });
    if (typeof document !== "undefined") document.documentElement.classList.toggle("reduce-motion", reducedMotion);
  },
  setTransparency: (transparency) => set({ transparency }),
  setExploded: (exploded) => set({ exploded }),
  setIsolated: (isolatedPart) => set({ isolatedPart }),
  setCompare: (compare) => set({ compare }),
  setTopic: (selectedTopic) =>
    set({
      selectedTopic,
      selectedPart: null,
      isolatedPart: null,
      exploded: false,
    }),
  selectPart: (selectedPart) => set({ selectedPart, isolatedPart: null }),
  setProcess: (selectedProcess) => set({ selectedProcess, progress: 0, playing: false }),
  setPlaying: (playing) => set({ playing }),
  setSpeed: (speed) => set({ speed }),
  setProgress: (progress) => set({ progress: Math.min(1, Math.max(0, progress)) }),
  setClassLevel: (classLevel) => set({ classLevel }),
  setTutorOpen: (tutorOpen) => set({ tutorOpen }),
  setSearchOpen: (searchOpen) => set({ searchOpen }),
  setSettingsOpen: (settingsOpen) => set({ settingsOpen }),
  setDemo: (demoActive, demoStep = 0) => set({ demoActive, demoStep }),
  toggleSystem: (id) =>
    set((s) => ({ bodySystems: { ...s.bodySystems, [id]: !s.bodySystems[id] } })),
  resetView: () =>
    set({
      exploded: false,
      isolatedPart: null,
      selectedPart: null,
      progress: 0,
      playing: false,
      transparency: true,
    }),
}));

export function hydrateClientSettings() {
  const s = useAppStore.getState();
  if (!s.reducedMotion && detectReducedMotion()) s.setReducedMotion(true);
  s.setQuality(detectQuality());
}
