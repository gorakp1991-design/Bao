import { create } from "zustand";
import type { BadgeId } from "@/data/types";

const KEY = "bioverse-progress-v1";

type QuizResult = {
  id: string;
  score: number;
  total: number;
  at: number;
  topic: string;
};

type ProgressState = {
  explored: string[];
  simulations: string[];
  quizzes: QuizResult[];
  badges: BadgeId[];
  recent: string[];
  chats: number;
  hydrated: boolean;
  markExplored: (id: string) => void;
  markSimulation: (id: string) => void;
  addQuiz: (r: QuizResult) => void;
  award: (id: BadgeId) => void;
  bumpChat: () => void;
  hydrate: () => void;
};

function load(): Partial<ProgressState> {
  if (typeof window === "undefined") return {};
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return {};
    return JSON.parse(raw) as Partial<ProgressState>;
  } catch {
    return {};
  }
}

function save(s: ProgressState) {
  if (typeof window === "undefined") return;
  const { hydrated: _h, ...rest } = s;
  localStorage.setItem(
    KEY,
    JSON.stringify({
      explored: rest.explored,
      simulations: rest.simulations,
      quizzes: rest.quizzes,
      badges: rest.badges,
      recent: rest.recent,
      chats: rest.chats,
    }),
  );
}

export const BADGE_META: Record<BadgeId, { name: string; hint: string }> = {
  "first-look": { name: "First Look", hint: "Open any 3D model" },
  "cell-navigator": { name: "Cell Navigator", hint: "Inspect three organelles" },
  "dna-decoder": { name: "DNA Decoder", hint: "Explore the DNA helix" },
  "time-traveler": { name: "Time Traveller", hint: "Finish a 4D simulation" },
  "quiz-ace": { name: "Quiz Ace", hint: "Score 90% or higher" },
  "tutor-chat": { name: "Lab Partner", hint: "Ask BIO-BOT a question" },
  "demo-complete": { name: "Demo Pilot", hint: "Complete the guided demo" },
  "body-explorer": { name: "Body Explorer", hint: "Open the human body lab" },
  "plant-scholar": { name: "Plant Scholar", hint: "Visit plant biology" },
};

export const useProgress = create<ProgressState>((set, get) => ({
  explored: [],
  simulations: [],
  quizzes: [],
  badges: [],
  recent: [],
  chats: 0,
  hydrated: false,
  hydrate: () => {
    if (get().hydrated) return;
    set({ ...load(), hydrated: true });
  },
  markExplored: (id) =>
    set((s) => {
      const explored = s.explored.includes(id) ? s.explored : [...s.explored, id];
      const recent = [id, ...s.recent.filter((x) => x !== id)].slice(0, 8);
      const badges = new Set(s.badges);
      badges.add("first-look");
      if (id === "dna") badges.add("dna-decoder");
      if (id === "human-body") badges.add("body-explorer");
      if (id === "plant-cell" || id === "leaf" || id === "chloroplast") badges.add("plant-scholar");
      if (explored.filter((x) => ["animal-cell", "plant-cell", "mitochondria", "nucleus"].includes(x)).length + (id === "animal-cell" ? 1 : 0) >= 1) {
        const organelleHits = explored.length >= 3;
        if (organelleHits) badges.add("cell-navigator");
      }
      const next = { ...s, explored, recent, badges: [...badges] as BadgeId[] };
      save(next);
      return next;
    }),
  markSimulation: (id) =>
    set((s) => {
      const simulations = s.simulations.includes(id) ? s.simulations : [...s.simulations, id];
      const badges = s.badges.includes("time-traveler") ? s.badges : [...s.badges, "time-traveler" as BadgeId];
      const next = { ...s, simulations, badges };
      save(next);
      return next;
    }),
  addQuiz: (r) =>
    set((s) => {
      const quizzes = [r, ...s.quizzes].slice(0, 40);
      const badges =
        r.total > 0 && r.score / r.total >= 0.9 && !s.badges.includes("quiz-ace")
          ? [...s.badges, "quiz-ace" as BadgeId]
          : s.badges;
      const next = { ...s, quizzes, badges };
      save(next);
      return next;
    }),
  award: (id) =>
    set((s) => {
      if (s.badges.includes(id)) return s;
      const next = { ...s, badges: [...s.badges, id] };
      save(next);
      return next;
    }),
  bumpChat: () =>
    set((s) => {
      const chats = s.chats + 1;
      const badges = s.badges.includes("tutor-chat") ? s.badges : [...s.badges, "tutor-chat" as BadgeId];
      const next = { ...s, chats, badges };
      save(next);
      return next;
    }),
}));
