import { useEffect, useState } from "react";
import { useAppStore } from "@/store/app-store";

export function useIsMobile() {
  const [mobile, setMobile] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 900px)");
    const apply = () => setMobile(mq.matches);
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);
  return mobile;
}

export function usePlayback(duration: number) {
  const playing = useAppStore((s) => s.playing);
  const speed = useAppStore((s) => s.speed);

  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min((now - last) / 1000, 0.1);
      last = now;
      const s = useAppStore.getState();
      const next = s.progress + (dt * s.speed) / Math.max(1, duration);
      if (next >= 1) {
        s.setProgress(1);
        s.setPlaying(false);
        return;
      }
      s.setProgress(next);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [playing, speed, duration]);
}
