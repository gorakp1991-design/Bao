import { getPart, getTopic, TOPIC_BY_ID } from "./catalog";
import { getProcess, stageAt } from "./processes";
import type { ClassLevel, TutorContext } from "./types";

function levelText(topicId: string, level: ClassLevel) {
  const t = getTopic(topicId);
  return t.explain[level];
}

export function localTutor(ctx: TutorContext, message: string): string {
  const q = message.trim().toLowerCase();
  const topic = getTopic(ctx.topic || ctx.model);
  const part = getPart(topic, ctx.selected);
  const process = ctx.stage ? getProcess(ctx.model) : getProcess(topic.processes[0] ?? "mitosis");
  const stage = ctx.stage ? process.stages.find((s) => s.id === ctx.stage) ?? stageAt(process, 0) : null;

  if (!q) {
    return intro(ctx, topic.name, part?.name ?? null, stage?.name ?? null);
  }

  if (/quiz|question|exam|mcq|test me/.test(q)) {
    return quizPrompt(topic, ctx.level);
  }
  if (/next|what happens next|then what/.test(q)) {
    return nextStep(ctx, topic, process);
  }
  if (/why.*important|importance|why does this matter/.test(q)) {
    return importance(topic, part, ctx.level);
  }
  if (/class\s*9|explain like.*9|simple|eli5|easy/.test(q)) {
    return `Class 9 view — ${topic.name}\n\n${topic.explain[9]}\n\n${part ? `Focus on ${part.name}: ${part.function}` : topic.facts[0]}`;
  }
  if (/class\s*10/.test(q)) {
    return `Class 10 view — ${topic.name}\n\n${topic.explain[10]}`;
  }
  if (/class\s*11/.test(q)) {
    return `Class 11 view — ${topic.name}\n\n${topic.explain[11]}\n\nNCERT: ${topic.ncert}`;
  }
  if (/class\s*12|ncert/.test(q)) {
    return `Class 12 / NCERT-level — ${topic.name}\n\n${topic.explain[12]}\n\n${topic.ncert}`;
  }
  if (/what happens here|what's happening|what is happening|current stage/.test(q)) {
    if (stage) return `${stage.name}\n\n${stage.detail}\n\n${process.note}`;
    return `${topic.summary}\n\n${levelText(topic.id, ctx.level)}`;
  }

  const hit = matchTopic(q);
  if (hit) {
    const t = getTopic(hit);
    const p = t.parts.find((x) => q.includes(x.name.toLowerCase()) || q.includes(x.id.replace("-", " ")));
    if (p) return formatPart(t.name, p, ctx.level);
    return `${t.name}\n\n${t.explain[ctx.level]}\n\nFunction: ${t.function}\n\nStructure: ${t.structure}\n\n${t.facts[0]}`;
  }

  if (part && (q.includes(part.name.toLowerCase()) || /this structure|this organelle|this part|selected/.test(q))) {
    return formatPart(topic.name, part, ctx.level);
  }

  if (/hello|hi |hey |who are you|help/.test(q)) {
    return intro(ctx, topic.name, part?.name ?? null, stage?.name ?? null);
  }

  return `${topic.name}\n\n${topic.explain[ctx.level]}\n\n${part ? `You have ${part.name} selected: ${part.function}` : `Try selecting a labelled structure, or ask “Why is this important?”`}\n\n${topic.ncert}`;
}

function intro(ctx: TutorContext, topic: string, part: string | null, stage: string | null) {
  const bits = [`You are exploring ${topic} at Class ${ctx.level} level.`];
  if (part) bits.push(`Selected structure: ${part}.`);
  if (stage) bits.push(`Current 4D stage: ${stage}.`);
  bits.push("Ask me to explain, why it matters, what happens next, or to give you a quiz.");
  return `BIO-BOT ready.\n\n${bits.join(" ")}`;
}

function formatPart(topic: string, part: { name: string; function: string; structure: string; location: string; fact: string }, level: ClassLevel) {
  return `${part.name} (${topic})\n\nFunction: ${part.function}\n\nStructure: ${part.structure}\n\nLocation: ${part.location}\n\nKey fact: ${part.fact}\n\n${level >= 11 ? "Use the Learn page for NCERT-linked exam phrasing." : "Remember the function in one sentence for your exam."}`;
}

function importance(topic: ReturnType<typeof getTopic>, part: ReturnType<typeof getPart>, level: ClassLevel) {
  if (part) {
    return `${part.name} matters because: ${part.function}\n\nWithout it, the cell or organ cannot complete its job. ${part.fact}\n\n${level >= 11 ? topic.explain[11] : topic.explain[9]}`;
  }
  return `Why ${topic.name} matters\n\n${topic.function}\n\n${topic.explain[level]}`;
}

function nextStep(ctx: TutorContext, topic: ReturnType<typeof getTopic>, process: ReturnType<typeof getProcess>) {
  if (ctx.stage) {
    const i = process.stages.findIndex((s) => s.id === ctx.stage);
    const n = process.stages[i + 1];
    if (n) return `Next: ${n.name}\n\n${n.detail}\n\nOpen 4D Simulator and press Play to watch this unfold.`;
    return `${process.name} is complete.\n\n${process.summary}\n\nTry a related process or take a quiz.`;
  }
  const pid = topic.processes[0];
  if (pid) {
    const p = getProcess(pid);
    return `A natural next step is the 4D process “${p.name}”.\n\nFirst stage: ${p.stages[0]?.name} — ${p.stages[0]?.summary}`;
  }
  return `Explore a related topic: ${topic.related.map((id) => getTopic(id).name).join(", ")}.`;
}

function quizPrompt(topic: ReturnType<typeof getTopic>, level: ClassLevel) {
  const bank: Record<string, string> = {
    dna: "State Chargaff’s pairing rules and why they matter for replication.",
    "animal-cell": "Name three organelles and one function of each.",
    mitochondria: "Why are mitochondria called the powerhouse of the cell?",
    heart: "Why is the left ventricular wall thicker than the right?",
    neuron: "What is saltatory conduction?",
    "plant-cell": "How does the vacuole help a herbaceous plant stay upright?",
  };
  const q = bank[topic.id] ?? `Write two key points about ${topic.name} at Class ${level} level.`;
  return `Exam-style prompt (${topic.name})\n\n${q}\n\nWhen you are ready, open Quizzes for auto-marked items, including 3D hotspot questions.`;
}

function matchTopic(q: string): string | null {
  const keys = Object.keys(TOPIC_BY_ID);
  for (const id of keys) {
    const t = TOPIC_BY_ID[id]!;
    if (q.includes(t.name.toLowerCase()) || q.includes(id.replace(/-/g, " "))) return id;
  }
  const aliases: Record<string, string> = {
    mito: "mitochondria",
    powerhouse: "mitochondria",
    helix: "dna",
    gene: "dna",
    "brain cell": "neuron",
    nerve: "neuron",
    pump: "heart",
    blood: "circulatory-system",
    breathe: "lungs",
    stoma: "leaf",
    chlorophyll: "chloroplast",
    sugar: "photosynthesis",
  };
  for (const [k, v] of Object.entries(aliases)) {
    if (q.includes(k)) return v;
  }
  return null;
}

export const SUGGESTED_PROMPTS = [
  "Explain this",
  "Why is this important?",
  "What happens next?",
  "Explain this like I am in Class 10.",
  "Explain this for Class 12.",
  "Give me a quiz",
  "Give me an exam question",
];
