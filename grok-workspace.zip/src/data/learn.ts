import type { ClassLevel } from "./types";

export type LearnModule = {
  id: string;
  title: string;
  classLevels: ClassLevel[];
  topic: string;
  process?: string;
  ncert: string;
  points: string[];
  exam: string[];
};

export const MODULES: LearnModule[] = [
  {
    id: "cell-basics",
    title: "The Fundamental Unit of Life",
    classLevels: [9, 10],
    topic: "animal-cell",
    ncert: "Class 9 — The Fundamental Unit of Life",
    points: [
      "All living organisms are made of cells (cell theory).",
      "Plasma membrane is selectively permeable.",
      "Nucleus houses DNA; cytoplasm holds organelles.",
      "Plant cells add wall, chloroplasts and a large vacuole.",
    ],
    exam: [
      "State the three main points of cell theory.",
      "Why is the plasma membrane called selectively permeable?",
      "List three differences between plant and animal cells.",
    ],
  },
  {
    id: "life-processes",
    title: "Life Processes",
    classLevels: [10],
    topic: "heart",
    process: "blood-circulation",
    ncert: "Class 10 — Life Processes",
    points: [
      "Nutrition, respiration, transport, excretion.",
      "Human heart: four chambers, double circulation.",
      "Alveoli are the site of gas exchange.",
      "Nephrons filter blood to form urine.",
    ],
    exam: [
      "Draw a labelled schematic of double circulation.",
      "Why is the left ventricle thicker than the right?",
      "Explain how alveoli are adapted for gas exchange.",
    ],
  },
  {
    id: "control",
    title: "Control and Coordination",
    classLevels: [10, 11],
    topic: "neuron",
    process: "neural-signal",
    ncert: "Class 10 Control and Coordination; Class 11 Neural Control",
    points: [
      "Neurons carry electrical impulses.",
      "Synapse uses chemical transmitters.",
      "Reflex arcs are rapid, involuntary pathways.",
      "Hormones provide slower chemical coordination.",
    ],
    exam: [
      "Trace the path of a spinal reflex.",
      "What is the role of myelin?",
      "Differentiate nervous and endocrine control.",
    ],
  },
  {
    id: "cell-cycle",
    title: "Cell Cycle and Cell Division",
    classLevels: [11, 12],
    topic: "chromosome",
    process: "mitosis",
    ncert: "Class 11 — Cell Cycle and Cell Division",
    points: [
      "Interphase includes G1, S and G2.",
      "Mitosis conserves chromosome number.",
      "Meiosis halves the number and increases variation.",
      "Crossing over occurs in prophase I.",
    ],
    exam: [
      "Compare mitosis and meiosis in a table.",
      "What is the significance of meiosis in sexual reproduction?",
      "Name the checkpoint that occurs at metaphase.",
    ],
  },
  {
    id: "molecular",
    title: "Molecular Basis of Inheritance",
    classLevels: [12],
    topic: "dna",
    process: "dna-replication",
    ncert: "Class 12 — Molecular Basis of Inheritance",
    points: [
      "DNA is a double helix with complementary bases.",
      "Replication is semi-conservative.",
      "Transcription produces RNA; translation produces protein.",
      "The genetic code is triplet, degenerate and nearly universal.",
    ],
    exam: [
      "State Chargaff’s rules.",
      "Describe Meselson and Stahl’s experiment in outline.",
      "Explain why the genetic code is described as degenerate.",
    ],
  },
  {
    id: "photo",
    title: "Photosynthesis in Higher Plants",
    classLevels: [11],
    topic: "chloroplast",
    process: "photosynthesis",
    ncert: "Class 11 — Photosynthesis in Higher Plants",
    points: [
      "Light reactions in thylakoids; Calvin cycle in stroma.",
      "Photolysis of water releases O2.",
      "ATP and NADPH fuel carbon fixation.",
      "C3, C4 and CAM differ in CO2 handling.",
    ],
    exam: [
      "Write the simplified net equation of photosynthesis.",
      "Where do light-dependent reactions occur?",
      "Why do C4 plants have an advantage in hot climates? (brief)",
    ],
  },
  {
    id: "plant-anatomy",
    title: "Leaf, Root and Transport",
    classLevels: [9, 10, 11],
    topic: "leaf",
    ncert: "Class 9 Tissues; Class 11 Transport in Plants",
    points: [
      "Xylem transports water; phloem transports sugars.",
      "Stomata regulate gas exchange and transpiration.",
      "Root hairs increase absorption area.",
      "Transpiration pull helps xylem ascent.",
    ],
    exam: [
      "Describe the pathway of water from soil to leaf.",
      "How do guard cells open a stoma?",
      "Differentiate xylem and phloem.",
    ],
  },
  {
    id: "human-phys",
    title: "Human Physiology Overview",
    classLevels: [11, 12],
    topic: "human-body",
    ncert: "Class 11 Human Physiology unit",
    points: [
      "Systems cooperate to keep homeostasis.",
      "Cardiac output = stroke volume × heart rate.",
      "Nephrons perform filtration, reabsorption, secretion.",
      "Sliding filament theory explains skeletal muscle contraction.",
    ],
    exam: [
      "Define homeostasis with one example.",
      "Outline the cardiac cycle.",
      "Explain sliding filament theory in brief.",
    ],
  },
];

export function modulesFor(level: ClassLevel) {
  return MODULES.filter((m) => m.classLevels.includes(level));
}
