import type { BioProcess } from "./types";

export const PROCESSES: BioProcess[] = [
  {
    id: "dna-replication",
    name: "DNA Replication",
    duration: 24,
    topic: "dna",
    summary: "Semi-conservative copying of the double helix before cell division.",
    note: "Visualization simplified for educational purposes. Fork geometry, primers and Okazaki fragments are stylised.",
    stages: [
      { id: "unwind", name: "Unwinding", start: 0, end: 0.16, summary: "Helicase unwinds the double helix at the origin.", detail: "Initiator proteins open the origin. Helicase (with topoisomerase relief) separates strands, forming a replication fork." },
      { id: "separate", name: "Strand separation", start: 0.16, end: 0.32, summary: "Hydrogen bonds break; SSB proteins keep strands apart.", detail: "Complementary bases are exposed as templates. Single-strand binding proteins prevent re-annealing." },
      { id: "primer", name: "Priming", start: 0.32, end: 0.48, summary: "Primase lays short RNA primers.", detail: "DNA polymerase cannot start a chain de novo; it needs a 3′-OH from an RNA primer." },
      { id: "polymerase", name: "Elongation", start: 0.48, end: 0.72, summary: "DNA polymerase adds complementary nucleotides.", detail: "Leading strand is continuous 5′→3′. Lagging strand is made as Okazaki fragments." },
      { id: "new-strands", name: "New strands form", start: 0.72, end: 0.88, summary: "Two daughter duplexes take shape.", detail: "DNA pol I (prokaryotes) or equivalent removes primers; ligase seals nicks." },
      { id: "complete", name: "Replication complete", start: 0.88, end: 1, summary: "Two identical double helices.", detail: "Each daughter DNA has one old strand and one new strand (semi-conservative)." },
    ],
  },
  {
    id: "transcription",
    name: "Transcription",
    duration: 20,
    topic: "dna",
    summary: "Copying a gene into messenger RNA.",
    note: "Visualization simplified for educational purposes. Eukaryotic splicing is omitted unless noted.",
    stages: [
      { id: "init", name: "Initiation", start: 0, end: 0.22, summary: "RNA polymerase binds the promoter.", detail: "Transcription factors help RNA polymerase recognise the promoter (TATA box in many eukaryotes)." },
      { id: "open", name: "Open complex", start: 0.22, end: 0.4, summary: "The DNA bubble opens.", detail: "A short stretch of DNA unwinds so the template strand can be read." },
      { id: "elong", name: "Elongation", start: 0.4, end: 0.72, summary: "RNA nucleotides are added 5′→3′.", detail: "Uracil pairs with adenine. The RNA–DNA hybrid is short-lived." },
      { id: "term", name: "Termination", start: 0.72, end: 0.88, summary: "The transcript is released.", detail: "Terminator sequences or protein factors stop polymerase." },
      { id: "done", name: "mRNA ready", start: 0.88, end: 1, summary: "The RNA message leaves for translation.", detail: "In eukaryotes, capping, splicing and polyadenylation occur first." },
    ],
  },
  {
    id: "translation",
    name: "Translation",
    duration: 22,
    topic: "ribosome",
    summary: "Ribosomes decode mRNA into a polypeptide.",
    note: "Visualization simplified for educational purposes.",
    stages: [
      { id: "init", name: "Initiation", start: 0, end: 0.2, summary: "Ribosome assembles on mRNA at the start codon.", detail: "AUG codes for methionine (formyl-Met in bacteria). Initiation factors and initiator tRNA join." },
      { id: "elong", name: "Elongation", start: 0.2, end: 0.55, summary: "tRNAs bring amino acids; peptide bonds form.", detail: "A site decoding, peptidyl transfer, then translocation. The chain grows N→C terminus." },
      { id: "term", name: "Termination", start: 0.55, end: 0.72, summary: "A stop codon ends the chain.", detail: "Release factors recognise UAA, UAG or UGA. The polypeptide is freed." },
      { id: "fold", name: "Folding", start: 0.72, end: 1, summary: "The chain folds into a functional shape.", detail: "Chaperones often assist. Some proteins need further modification." },
    ],
  },
  {
    id: "mitosis",
    name: "Mitosis",
    duration: 28,
    topic: "animal-cell",
    summary: "Nuclear division that produces two identical nuclei.",
    note: "Visualization simplified for educational purposes. Chromosome count is schematic, not a karyotype.",
    stages: [
      { id: "interphase", name: "Interphase", start: 0, end: 0.16, summary: "Cell grows; DNA is replicated (S phase).", detail: "G1, S and G2 prepare the cell. Chromosomes are not yet condensed." },
      { id: "prophase", name: "Prophase", start: 0.16, end: 0.34, summary: "Chromosomes condense; spindle begins to form.", detail: "Nuclear envelope breaks down in open mitosis. Centrosomes move apart." },
      { id: "metaphase", name: "Metaphase", start: 0.34, end: 0.5, summary: "Chromosomes line up at the equator.", detail: "Kinetochores attach to microtubules from opposite poles. The checkpoint waits for all attachments." },
      { id: "anaphase", name: "Anaphase", start: 0.5, end: 0.68, summary: "Sister chromatids separate to opposite poles.", detail: "Cohesin is cleaved. Chromatids are now daughter chromosomes." },
      { id: "telophase", name: "Telophase", start: 0.68, end: 0.84, summary: "Nuclei reform around each set of chromosomes.", detail: "Envelope reassembles; chromosomes decondense." },
      { id: "cytokinesis", name: "Cytokinesis", start: 0.84, end: 1, summary: "Cytoplasm divides into two cells.", detail: "Animal cells use an actin–myosin contractile ring. Plant cells build a cell plate." },
    ],
  },
  {
    id: "meiosis",
    name: "Meiosis",
    duration: 30,
    topic: "chromosome",
    summary: "Two divisions that produce haploid gametes and shuffle genes.",
    note: "Visualization simplified for educational purposes.",
    stages: [
      { id: "pro1", name: "Prophase I", start: 0, end: 0.22, summary: "Homologues pair and may recombine.", detail: "Synapsis and crossing over create chiasmata — a source of genetic variation." },
      { id: "meta1", name: "Metaphase I", start: 0.22, end: 0.38, summary: "Tetrads align; independent assortment.", detail: "Orientation of each pair is random, another source of variation." },
      { id: "ana1", name: "Anaphase I", start: 0.38, end: 0.52, summary: "Homologues separate; sisters stay together.", detail: "This is the reductional division (2n → n)." },
      { id: "telo1", name: "Telophase I", start: 0.52, end: 0.64, summary: "Two haploid cells form.", detail: "A brief interkinesis may follow; DNA is not replicated again." },
      { id: "meiosis2", name: "Meiosis II", start: 0.64, end: 0.86, summary: "Sister chromatids separate (equational).", detail: "Similar to mitosis but starting from haploid cells." },
      { id: "gametes", name: "Four haploid cells", start: 0.86, end: 1, summary: "Gametes (or spores) are produced.", detail: "In humans, sperm are four haploid cells; in oogenesis one ovum plus polar bodies is typical." },
    ],
  },
  {
    id: "photosynthesis",
    name: "Photosynthesis",
    duration: 24,
    topic: "chloroplast",
    summary: "Light-driven synthesis of sugars from CO2 and water.",
    note: "Visualization simplified for educational purposes. The Z-scheme is stylised.",
    stages: [
      { id: "light", name: "Light absorption", start: 0, end: 0.2, summary: "Pigments capture photons.", detail: "Chlorophyll in photosystems becomes excited. Energy funnels to reaction centres." },
      { id: "split", name: "Water splitting", start: 0.2, end: 0.38, summary: "PSII splits H2O, releasing O2.", detail: "Electrons replace those lost by P680. Protons enter the thylakoid lumen." },
      { id: "etc", name: "Electron transport", start: 0.38, end: 0.58, summary: "Electrons flow; ATP and NADPH form.", detail: "The cytochrome b6f complex contributes to the proton gradient. PSI reduces NADP+." },
      { id: "calvin", name: "Calvin cycle", start: 0.58, end: 0.82, summary: "CO2 is fixed into carbohydrate.", detail: "Rubisco carboxylates RuBP. ATP and NADPH reduce the products to sugars." },
      { id: "product", name: "Glucose and oxygen", start: 0.82, end: 1, summary: "Sugars are stored or exported; O2 is released.", detail: "Overall: 6CO2 + 6H2O + light → C6H12O6 + 6O2 (simplified net)." },
    ],
  },
  {
    id: "cellular-respiration",
    name: "Cellular Respiration",
    duration: 26,
    topic: "mitochondria",
    summary: "Oxidation of fuels to make ATP, with CO2 and H2O as products.",
    note: "Visualization simplified for educational purposes. ATP yields are approximate.",
    stages: [
      { id: "glyco", name: "Glycolysis", start: 0, end: 0.22, summary: "Glucose → two pyruvate in the cytosol.", detail: "Net 2 ATP and 2 NADH. Oxygen is not required for this stage." },
      { id: "pyruvate", name: "Pyruvate oxidation", start: 0.22, end: 0.4, summary: "Pyruvate becomes acetyl-CoA.", detail: "Occurs in the mitochondrial matrix in eukaryotes. CO2 is released." },
      { id: "krebs", name: "Krebs cycle", start: 0.4, end: 0.62, summary: "Acetyl-CoA is oxidised; coenzymes reduced.", detail: "Also called the citric acid cycle. More CO2, NADH and FADH2 are produced." },
      { id: "etc", name: "Electron transport", start: 0.62, end: 0.84, summary: "O2 is the terminal acceptor; protons are pumped.", detail: "Complexes I–IV. Oxygen is reduced to water." },
      { id: "atp", name: "ATP synthesis", start: 0.84, end: 1, summary: "ATP synthase uses the proton gradient.", detail: "Chemiosmosis. Aerobic respiration yields far more ATP than glycolysis alone." },
    ],
  },
  {
    id: "blood-circulation",
    name: "Blood Circulation",
    duration: 20,
    topic: "heart",
    summary: "Double circuit of pulmonary and systemic flow.",
    note: "Visualization simplified for educational purposes.",
    stages: [
      { id: "ra", name: "Right atrium fills", start: 0, end: 0.16, summary: "Deoxygenated blood returns via venae cavae.", detail: "Systemic veins empty into the right atrium." },
      { id: "rv", name: "Right ventricle pumps", start: 0.16, end: 0.34, summary: "Blood is sent to the lungs.", detail: "Through the pulmonary valve into pulmonary arteries." },
      { id: "lungs", name: "Lungs oxygenate", start: 0.34, end: 0.52, summary: "Gas exchange in alveolar capillaries.", detail: "CO2 leaves, O2 binds haemoglobin." },
      { id: "la", name: "Left atrium fills", start: 0.52, end: 0.68, summary: "Oxygenated blood returns via pulmonary veins.", detail: "Enters the left atrium then left ventricle." },
      { id: "lv", name: "Left ventricle ejects", start: 0.68, end: 0.86, summary: "Aorta distributes blood to the body.", detail: "Highest pressure chamber of the heart." },
      { id: "body", name: "Systemic delivery", start: 0.86, end: 1, summary: "Tissues take O2; blood returns to the right heart.", detail: "The loop repeats with every cardiac cycle." },
    ],
  },
  {
    id: "neural-signal",
    name: "Neural Signal Transmission",
    duration: 16,
    topic: "neuron",
    summary: "Action potential from dendrites to synaptic terminals.",
    note: "Visualization simplified for educational purposes.",
    stages: [
      { id: "stimulus", name: "Stimulus", start: 0, end: 0.14, summary: "Dendrites receive excitatory input.", detail: "Ligand-gated channels open; local depolarisation (EPSP) occurs." },
      { id: "hillock", name: "Threshold", start: 0.14, end: 0.3, summary: "Axon hillock reaches threshold.", detail: "If summed EPSPs exceed threshold, voltage-gated Na+ channels open." },
      { id: "propagate", name: "Propagation", start: 0.3, end: 0.62, summary: "The spike travels along the axon.", detail: "In myelinated axons, it jumps between nodes of Ranvier (saltatory conduction)." },
      { id: "terminal", name: "Terminal arrival", start: 0.62, end: 0.8, summary: "Depolarisation opens Ca2+ channels.", detail: "Calcium enters the bouton." },
      { id: "release", name: "Transmitter release", start: 0.8, end: 1, summary: "Vesicles fuse and transmitter crosses the cleft.", detail: "The next cell may be excited or inhibited depending on the receptor." },
    ],
  },
  {
    id: "muscle-contraction",
    name: "Muscle Contraction",
    duration: 18,
    topic: "human-body",
    summary: "Sliding-filament contraction of skeletal muscle.",
    note: "Visualization simplified for educational purposes.",
    stages: [
      { id: "impulse", name: "Nerve impulse", start: 0, end: 0.18, summary: "A motor neuron fires at the neuromuscular junction.", detail: "Acetylcholine depolarises the motor end plate." },
      { id: "calcium", name: "Calcium release", start: 0.18, end: 0.36, summary: "T-tubules trigger SR to release Ca2+.", detail: "Ryanodine receptors open on the sarcoplasmic reticulum." },
      { id: "troponin", name: "Troponin–tropomyosin", start: 0.36, end: 0.52, summary: "Ca2+ binds troponin; binding sites open.", detail: "Tropomyosin shifts off actin’s myosin-binding sites." },
      { id: "bridge", name: "Cross-bridge cycling", start: 0.52, end: 0.78, summary: "Myosin pulls actin (power stroke).", detail: "ATP is required to detach myosin heads (rigor without ATP)." },
      { id: "relax", name: "Relaxation", start: 0.78, end: 1, summary: "Ca2+ is pumped back; filaments slide apart.", detail: "Acetylcholinesterase clears ACh. The fibre lengthens." },
    ],
  },
  {
    id: "protein-folding",
    name: "Protein Folding",
    duration: 16,
    topic: "ribosome",
    summary: "A polypeptide finds a stable, functional 3D fold.",
    note: "Visualization simplified for educational purposes. Real folding landscapes are far more complex.",
    stages: [
      { id: "chain", name: "Nascent chain", start: 0, end: 0.22, summary: "Amino acids emerge from the ribosome.", detail: "Sequence (primary structure) is already determined." },
      { id: "secondary", name: "Secondary structure", start: 0.22, end: 0.48, summary: "Local helices and sheets form.", detail: "Hydrogen bonds along the backbone create α-helices and β-sheets." },
      { id: "tertiary", name: "Tertiary structure", start: 0.48, end: 0.78, summary: "The chain packs into a 3D domain.", detail: "Hydrophobic core, disulphides, ionic bonds and van der Waals contacts." },
      { id: "function", name: "Functional protein", start: 0.78, end: 1, summary: "The native fold can bind or catalyse.", detail: "Misfolding can lead to degradation or aggregation. Chaperones assist many proteins." },
    ],
  },
  {
    id: "fertilization",
    name: "Fertilisation",
    duration: 20,
    topic: "flower",
    summary: "Fusion of gametes to form a zygote — shown as a general concept.",
    note: "Visualization simplified for educational purposes. Animal and plant details differ; this is a schematic concept, not a clinical model.",
    stages: [
      { id: "approach", name: "Approach", start: 0, end: 0.22, summary: "Gametes are brought together.", detail: "In animals, sperm swim toward the egg. In flowering plants, a pollen tube grows to the ovule." },
      { id: "contact", name: "Recognition", start: 0.22, end: 0.44, summary: "Species-specific recognition occurs.", detail: "Bindin (animals) or pollen–stigma interactions (plants) help prevent the wrong fusion." },
      { id: "fusion", name: "Membrane fusion", start: 0.44, end: 0.66, summary: "Haploid nuclei are delivered.", detail: "Blocks to polyspermy (fast and slow) operate in many animals." },
      { id: "zygote", name: "Zygote", start: 0.66, end: 1, summary: "A diploid cell is formed.", detail: "In angiosperms, double fertilisation also makes endosperm. Development then begins." },
    ],
  },
  {
    id: "immune-response",
    name: "Immune Response",
    duration: 22,
    topic: "circulatory-system",
    summary: "Recognise, respond, remember — a schematic adaptive response.",
    note: "Visualization simplified for educational purposes. Not medical advice.",
    stages: [
      { id: "recognise", name: "Recognition", start: 0, end: 0.2, summary: "Innate sensors and lymphocytes detect antigen.", detail: "APCs process antigen and present peptides on MHC molecules." },
      { id: "activate", name: "Activation", start: 0.2, end: 0.42, summary: "Matching lymphocytes are activated.", detail: "Helper T cells provide signals; B cells can class-switch and affinity-mature." },
      { id: "expand", name: "Clonal expansion", start: 0.42, end: 0.62, summary: "Specific clones proliferate.", detail: "Clonal selection: only matching cells expand." },
      { id: "attack", name: "Effector phase", start: 0.62, end: 0.82, summary: "Antibodies and/or cytotoxic T cells act.", detail: "Neutralisation, opsonisation, killing of infected cells." },
      { id: "memory", name: "Memory", start: 0.82, end: 1, summary: "Memory cells remain.", detail: "A later exposure produces a faster, stronger secondary response — the principle of vaccination." },
    ],
  },
];

export const PROCESS_BY_ID: Record<string, BioProcess> = Object.fromEntries(
  PROCESSES.map((p) => [p.id, p]),
);

export function getProcess(id: string | null | undefined): BioProcess {
  if (id && PROCESS_BY_ID[id]) return PROCESS_BY_ID[id];
  return PROCESS_BY_ID["mitosis"]!;
}

export function stageAt(process: BioProcess, t: number) {
  const x = Math.min(1, Math.max(0, t));
  return process.stages.find((s) => x >= s.start && x < s.end) ?? process.stages[process.stages.length - 1]!;
}
