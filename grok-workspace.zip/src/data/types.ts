export type ClassLevel = 9 | 10 | 11 | 12;
export type Quality = "low" | "medium" | "high";
export type Speed = 0.25 | 0.5 | 1 | 2 | 4;

export type TopicCategory =
  | "cell"
  | "molecular"
  | "organ"
  | "system"
  | "plant"
  | "body";

export type BioPart = {
  id: string;
  name: string;
  function: string;
  structure: string;
  location: string;
  fact: string;
};

export type Topic = {
  id: string;
  name: string;
  category: TopicCategory;
  summary: string;
  function: string;
  structure: string;
  facts: string[];
  parts: BioPart[];
  related: string[];
  processes: string[];
  ncert: string;
  explain: Record<ClassLevel, string>;
};

export type ProcessStage = {
  id: string;
  name: string;
  start: number;
  end: number;
  summary: string;
  detail: string;
};

export type BioProcess = {
  id: string;
  name: string;
  duration: number;
  topic: string;
  summary: string;
  stages: ProcessStage[];
  note: string;
};

export type QuizKind = "mcq" | "tf" | "sequence" | "hotspot";

export type QuizQuestion = {
  id: string;
  kind: QuizKind;
  topic: string;
  prompt: string;
  options?: string[];
  answer: string | string[];
  explain: string;
  hotspotTarget?: string;
  level: ClassLevel;
};

export type TutorContext = {
  model: string;
  topic: string;
  stage: string | null;
  selected: string | null;
  level: ClassLevel;
};

export type BadgeId =
  | "first-look"
  | "cell-navigator"
  | "dna-decoder"
  | "time-traveler"
  | "quiz-ace"
  | "tutor-chat"
  | "demo-complete"
  | "body-explorer"
  | "plant-scholar";
