import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { LabFrame } from "@/components/layout/lab-frame";
import { CanvasStage } from "@/components/3d/canvas-stage";
import { ProcessScene } from "@/components/3d/process-scene";
import { useAppStore } from "@/store/app-store";

export const Route = createFileRoute("/neuron")({ component: NeuronPage });

function NeuronPage() {
  const setTopic = useAppStore((s) => s.setTopic);
  const setProcess = useAppStore((s) => s.setProcess);
  const t = useAppStore((s) => s.progress);
  useEffect(() => {
    setTopic("neuron");
    setProcess("neural-signal");
  }, [setTopic, setProcess]);
  return (
    <AppShell lab>
      <LabFrame topicId="neuron" processId="neural-signal">
        <CanvasStage>
          <ProcessScene processId="neural-signal" t={t} />
        </CanvasStage>
      </LabFrame>
    </AppShell>
  );
}
