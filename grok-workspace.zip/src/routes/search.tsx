import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { useAppStore } from "@/store/app-store";

export const Route = createFileRoute("/search")({ component: SearchPage });

function SearchPage() {
  const setOpen = useAppStore((s) => s.setSearchOpen);
  useEffect(() => setOpen(true), [setOpen]);
  return (
    <AppShell>
      <main className="mx-auto max-w-xl px-4 py-16 text-center">
        <h1 className="font-display text-3xl">Search Biology</h1>
        <p className="mt-2 text-sm text-fg-muted">The catalogue overlay is open. Query models, 4D processes, quizzes and BIO-BOT.</p>
      </main>
    </AppShell>
  );
}
