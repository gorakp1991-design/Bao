import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/app-shell";
import { Button } from "@/components/ui/button";
import { HeroScene } from "@/components/3d/hero-scene";
import { startDemo } from "@/components/demo/demo-controller";
import { TOPICS } from "@/data/catalog";
import { PROCESSES } from "@/data/processes";
import { ArrowRight, Box, Clock, Bot, FlaskConical, GraduationCap, Layers3 } from "lucide-react";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <AppShell>
      <main>
        <section className="relative isolate min-h-[calc(100dvh-3.5rem)] overflow-hidden hud-grid">
          <div className="absolute inset-0 -z-10">
            <HeroScene />
          </div>
          <div className="absolute inset-0 -z-10 bg-gradient-to-b from-bg/20 via-bg/55 to-bg" />
          <div className="mx-auto flex max-w-6xl flex-col justify-center px-5 py-16 md:py-24">
            <p className="font-mono text-xs tracking-[0.32em] text-accent">VIRTUAL BIOLOGY LABORATORY</p>
            <h1 className="mt-4 max-w-3xl font-display text-5xl leading-[1.05] tracking-tight md:text-7xl">
              BIOVERSE
            </h1>
            <p className="mt-4 max-w-xl font-display text-xl text-fg md:text-2xl">
              Experience Biology Beyond the Textbook.
            </p>
            <p className="mt-3 max-w-xl text-base leading-relaxed text-fg-muted">
              Explore cells, organs, DNA and biological processes in interactive 3D and 4D.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg">
                <Link to="/lab" search={{ topic: "animal-cell" }}>
                  Enter Bio Lab
                  <ArrowRight className="size-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="secondary">
                <Link to="/lab" search={{ topic: "dna" }}>
                  Explore 3D models
                </Link>
              </Button>
              <Button size="lg" variant="outline" onClick={() => startDemo()}>
                Start demo
              </Button>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-5 py-16">
          <p className="font-mono text-xs tracking-[0.28em] text-fg-subtle">WHY BIOVERSE?</p>
          <h2 className="mt-2 font-display text-3xl md:text-4xl">A lab, not a slideshow.</h2>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            <Feature icon={Box} title="3D learning" copy="Rotate, zoom and dissect structures. Click a mitochondrion and read what it actually does." />
            <Feature icon={Clock} title="4D simulation" copy="Scrub time through mitosis, replication, photosynthesis and more — spatial plus temporal." />
            <Feature icon={Bot} title="AI biology tutor" copy="BIO-BOT knows the model, stage and class level you are on. Works offline with a local tutor too." />
            <Feature icon={FlaskConical} title="Virtual lab" copy="Exploded views, isolation, labels and transparency — the tools of a teaching bench." />
            <Feature icon={GraduationCap} title="Interactive quizzes" copy="MCQ, true/false, sequence the process, and 3D hotspot questions." />
            <Feature icon={Layers3} title="Supported topics" copy={`${TOPICS.length} models and ${PROCESSES.length} time-based processes, from Class 9 to 12.`} />
          </div>
        </section>

        <section className="border-y border-border bg-surface/40 px-5 py-16">
          <div className="mx-auto max-w-6xl">
            <p className="font-mono text-xs tracking-[0.28em] text-fg-subtle">SUPPORTED TOPICS</p>
            <div className="mt-6 flex flex-wrap gap-2">
              {TOPICS.map((t) => (
                <Link
                  key={t.id}
                  to="/lab"
                  search={{ topic: t.id }}
                  className="rounded-full border border-border px-3 py-1.5 text-sm text-fg-muted hover:border-accent hover:text-accent"
                >
                  {t.name}
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
    </AppShell>
  );
}

function Feature({ icon: Icon, title, copy }: { icon: typeof Box; title: string; copy: string }) {
  return (
    <article className="rounded-2xl border border-border bg-surface p-5">
      <Icon className="size-5 text-accent" />
      <h3 className="mt-3 font-display text-lg">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-fg-muted">{copy}</p>
    </article>
  );
}
