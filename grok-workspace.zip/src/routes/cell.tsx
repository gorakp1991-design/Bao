import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { LabFrame } from "@/components/layout/lab-frame";
import { CanvasStage } from "@/components/3d/canvas-stage";
import { BiologyModel } from "@/components/3d/model-registry";
import { useAppStore } from "@/store/app-store";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/cell")({ component: CellPage });

function CellPage() {
  const setTopic = useAppStore((s) => s.setTopic);
  const topic = useAppStore((s) => s.selectedTopic);
  const compare = useAppStore((s) => s.compare);
  const setCompare = useAppStore((s) => s.setCompare);
  const exploded = useAppStore((s) => s.exploded);
  const setExploded = useAppStore((s) => s.setExploded);
  const selected = useAppStore((s) => s.selectedPart);
  const setIsolated = useAppStore((s) => s.setIsolated);
  const isolated = useAppStore((s) => s.isolatedPart);
  const id = topic === "plant-cell" ? "plant-cell" : "animal-cell";

  useEffect(() => {
    if (topic !== "plant-cell" && topic !== "animal-cell") setTopic("animal-cell");
  }, [topic, setTopic]);

  return (
    <AppShell lab>
      <LabFrame topicId={id} explore={[{ id: "animal-cell", name: "Animal Cell" }, { id: "plant-cell", name: "Plant Cell" }]}>
        <div className="relative h-full">
          <CanvasStage>
            <BiologyModel topicId={id} />
          </CanvasStage>
          <div className="absolute left-3 top-16 z-10 flex flex-wrap gap-2">
            <Button size="sm" variant={id === "animal-cell" ? "default" : "secondary"} onClick={() => setTopic("animal-cell")}>
              Animal
            </Button>
            <Button size="sm" variant={id === "plant-cell" ? "default" : "secondary"} onClick={() => setTopic("plant-cell")}>
              Plant
            </Button>
            <Button size="sm" variant={compare ? "default" : "secondary"} onClick={() => setCompare(!compare)}>
              Compare
            </Button>
            <Button size="sm" variant={exploded ? "default" : "secondary"} onClick={() => setExploded(!exploded)}>
              Explode view
            </Button>
            <Button size="sm" variant={isolated ? "default" : "secondary"} onClick={() => setIsolated(isolated ? null : selected)}>
              Isolate
            </Button>
          </div>
        </div>
      </LabFrame>
    </AppShell>
  );
}
