import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { LabFrame } from "@/components/layout/lab-frame";
import { CanvasStage } from "@/components/3d/canvas-stage";
import { HumanBodyModel } from "@/components/3d/models/human-body";
import { useAppStore } from "@/store/app-store";
import { useProgress } from "@/store/progress-store";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/human-body")({ component: BodyPage });

const SYSTEMS = [
  ["skeletal", "Skeletal"],
  ["muscular", "Muscular"],
  ["nervous", "Nervous"],
  ["circulatory", "Circulatory"],
  ["respiratory", "Respiratory"],
  ["digestive", "Digestive"],
  ["urinary", "Urinary"],
  ["endocrine", "Endocrine"],
  ["reproductive", "Reproductive"],
  ["skin", "Skin"],
] as const;

function BodyPage() {
  const setTopic = useAppStore((s) => s.setTopic);
  const systems = useAppStore((s) => s.bodySystems);
  const toggle = useAppStore((s) => s.toggleSystem);
  const mark = useProgress((s) => s.markExplored);

  useEffect(() => {
    setTopic("human-body");
    mark("human-body");
  }, [setTopic, mark]);

  return (
    <AppShell lab>
      <LabFrame topicId="human-body">
        <div className="relative h-full">
          <CanvasStage camera={[0, 0.4, 7]}>
            <HumanBodyModel />
          </CanvasStage>
          <div className="absolute left-3 top-16 z-10 max-w-[16rem] rounded-xl border border-border bg-surface/85 p-3">
            <p className="font-mono text-[10px] tracking-[0.18em] text-fg-subtle">SYSTEMS</p>
            <ul className="mt-2 space-y-1">
              {SYSTEMS.map(([id, label]) => (
                <li key={id}>
                  <button
                    type="button"
                    onClick={() => toggle(id)}
                    className={cn(
                      "flex h-10 w-full items-center justify-between rounded-md px-2 text-sm",
                      systems[id] ? "bg-accent/15 text-accent" : "text-fg-muted",
                    )}
                  >
                    {label}
                    <span className="font-mono text-[10px]">{systems[id] ? "ON" : "OFF"}</span>
                  </button>
                </li>
              ))}
            </ul>
            <Button
              className="mt-2 w-full"
              variant="secondary"
              size="sm"
              onClick={() => {
                SYSTEMS.forEach(([id]) => {
                  if (!systems[id]) toggle(id);
                });
              }}
            >
              Show all
            </Button>
          </div>
        </div>
      </LabFrame>
    </AppShell>
  );
}
