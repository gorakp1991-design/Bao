import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/app-shell";
import { TutorBody } from "@/components/ai/tutor-panel";

export const Route = createFileRoute("/tutor")({ component: TutorPage });

function TutorPage() {
  return (
    <AppShell>
      <div className="mx-auto h-[calc(100dvh-8rem)] max-w-2xl overflow-hidden rounded-2xl border border-border bg-surface md:mt-6">
        <TutorBody />
      </div>
    </AppShell>
  );
}
