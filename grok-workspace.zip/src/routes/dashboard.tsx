import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/app-shell";
import { useProgress, BADGE_META } from "@/store/progress-store";
import { TOPICS } from "@/data/catalog";
import { PROCESSES } from "@/data/processes";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { BadgeId } from "@/data/types";

export const Route = createFileRoute("/dashboard")({ component: DashPage });

function DashPage() {
  const explored = useProgress((s) => s.explored);
  const sims = useProgress((s) => s.simulations);
  const quizzes = useProgress((s) => s.quizzes);
  const badges = useProgress((s) => s.badges);
  const recent = useProgress((s) => s.recent);
  const quizAvg =
    quizzes.length === 0 ? 0 : Math.round((quizzes.reduce((a, q) => a + q.score / Math.max(1, q.total), 0) / quizzes.length) * 100);

  const weak = weakTopics(quizzes);
  const recommended = TOPICS.filter((t) => !explored.includes(t.id)).slice(0, 4);

  return (
    <AppShell>
      <main className="mx-auto max-w-5xl px-4 py-8">
        <p className="font-mono text-xs tracking-[0.22em] text-accent">LEARNER DASHBOARD</p>
        <h1 className="mt-2 font-display text-4xl">Progress</h1>
        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Stat label="Topics completed" value={`${explored.length}/${TOPICS.length}`} />
          <Stat label="3D models explored" value={String(explored.length)} />
          <Stat label="4D simulations" value={`${sims.length}/${PROCESSES.length}`} />
          <Stat label="Quiz average" value={`${quizAvg}%`} />
        </div>
        <section className="mt-8">
          <h2 className="font-display text-xl">Badges</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {(Object.keys(BADGE_META) as BadgeId[]).map((id) => (
              <span
                key={id}
                className={`rounded-full border px-3 py-1 text-xs ${badges.includes(id) ? "border-accent text-accent" : "border-border text-fg-subtle"}`}
                title={BADGE_META[id].hint}
              >
                {BADGE_META[id].name}
              </span>
            ))}
          </div>
        </section>
        <section className="mt-8 grid gap-6 md:grid-cols-2">
          <div>
            <h2 className="font-display text-xl">Recent</h2>
            <ul className="mt-3 space-y-2">
              {recent.length === 0 ? <li className="text-sm text-fg-muted">Explore a model to begin.</li> : null}
              {recent.map((id) => (
                <li key={id}>
                  <Link to="/lab" search={{ topic: id }} className="text-sm text-accent hover:underline">
                    {TOPICS.find((t) => t.id === id)?.name ?? id}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2 className="font-display text-xl">Recommended</h2>
            <ul className="mt-3 space-y-2">
              {recommended.map((t) => (
                <li key={t.id} className="text-sm text-fg-muted">
                  {t.name} — {t.summary}
                </li>
              ))}
            </ul>
          </div>
        </section>
        <section className="mt-8">
          <h2 className="font-display text-xl">Weak areas</h2>
          <p className="mt-2 text-sm text-fg-muted">
            {weak.length ? weak.join(", ") : "No quiz misses yet — take an assessment after a lab session."}
          </p>
        </section>
        <section className="mt-10 rounded-2xl border border-border bg-surface p-5">
          <h2 className="font-display text-xl">Coming soon</h2>
          <p className="mt-2 text-sm text-fg-muted">
            Teacher dashboard, classroom mode, assignments, live quiz, AR/VR, 3D model upload, and teacher-created simulations are designed into the architecture but not enabled in this build.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            {["Teacher dashboard", "Classroom mode", "Assignments", "Live quiz", "AR mode", "VR mode", "Model upload"].map((x) => (
              <Badge key={x} tone="muted">
                {x}
              </Badge>
            ))}
          </div>
          <Button className="mt-4" variant="secondary" asChild>
            <Link to="/ar">AR status</Link>
          </Button>
        </section>
      </main>
    </AppShell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-border bg-surface p-4">
      <p className="font-mono text-[10px] tracking-[0.18em] text-fg-subtle">{label.toUpperCase()}</p>
      <p className="mt-2 font-display text-3xl tabular-nums">{value}</p>
    </div>
  );
}

function weakTopics(quizzes: { topic: string; score: number; total: number }[]) {
  const map = new Map<string, { s: number; t: number }>();
  for (const q of quizzes) {
    const cur = map.get(q.topic) ?? { s: 0, t: 0 };
    cur.s += q.score;
    cur.t += q.total;
    map.set(q.topic, cur);
  }
  return [...map.entries()].filter(([, v]) => v.t > 0 && v.s / v.t < 0.6).map(([k]) => k);
}
