import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/app-shell";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/ar")({ component: ARPage });

function ARPage() {
  return (
    <AppShell>
      <main className="mx-auto max-w-lg px-4 py-16 text-center">
        <p className="font-mono text-xs tracking-[0.22em] text-accent">WEBXR</p>
        <h1 className="mt-2 font-display text-4xl">AR mode coming soon.</h1>
        <p className="mt-3 text-sm leading-relaxed text-fg-muted">
          The lab is structured so a future WebXR session can mount the same procedural models in an immersive camera. This build does not fake AR in a 2D browser.
        </p>
        <Button className="mt-6" asChild>
          <Link to="/lab">Return to 3D lab</Link>
        </Button>
      </main>
    </AppShell>
  );
}
