import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { LabFrame } from "@/components/layout/lab-frame";
import { CanvasStage } from "@/components/3d/canvas-stage";
import { BiologyModel } from "@/components/3d/model-registry";
import { ProcessScene } from "@/components/3d/process-scene";
import { useAppStore } from "@/store/app-store";

export const Route = createFileRoute("/plants")({ component: PlantsPage });

function PlantsPage() {
  const setTopic = useAppStore((s) => s.setTopic);
  const topic = useAppStore((s) => s.selectedTopic);
  const t = useAppStore((s) => s.progress);
  const id = ["plant-cell", "chloroplast", "flower", "leaf", "root"].includes(topic) ? topic : "leaf";

  useEffect(() => {
    if (!["plant-cell", "chloroplast", "flower", "leaf", "root"].includes(topic)) setTopic("leaf");
  }, [topic, setTopic]);

  const photo = id === "chloroplast";

  return (
    <AppShell lab>
      <LabFrame
        topicId={id}
        processId={photo ? "photosynthesis" : undefined}
        explore={[
          { id: "plant-cell", name: "Plant Cell" },
          { id: "chloroplast", name: "Chloroplast" },
          { id: "leaf", name: "Leaf" },
          { id: "root", name: "Root" },
          { id: "flower", name: "Flower" },
        ]}
      >
        <CanvasStage>
          {photo ? <ProcessScene processId="photosynthesis" t={t} /> : <BiologyModel topicId={id} />}
        </CanvasStage>
      </LabFrame>
    </AppShell>
  );
}
