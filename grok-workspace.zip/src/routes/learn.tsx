import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/app-shell";
import { modulesFor } from "@/data/learn";
import { getTopic } from "@/data/catalog";
import { useAppStore } from "@/store/app-store";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { ClassLevel } from "@/data/types";

export const Route = createFileRoute("/learn")({ component: LearnPage });

function LearnPage() {
  const level = useAppStore((s) => s.classLevel);
  const setLevel = useAppStore((s) => s.setClassLevel);
  const modules = modulesFor(level);

  return (
    <AppShell>
      <main className="mx-auto max-w-5xl px-4 py-8">
        <p className="font-mono text-xs tracking-[0.22em] text-accent">LEARNING MODE</p>
        <h1 className="mt-2 font-display text-4xl">Choose your class</h1>
        <p className="mt-2 max-w-2xl text-sm text-fg-muted">
          Explanations shift from simple Class 9 language to NCERT-level Class 12 terminology.
        </p>
        <div className="mt-5 flex flex-wrap gap-2">
          {([9, 10, 11, 12] as ClassLevel[]).map((n) => (
            <Button key={n} variant={level === n ? "default" : "secondary"} onClick={() => setLevel(n)}>
              Class {n}
            </Button>
          ))}
        </div>
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {modules.map((m) => {
            const topic = getTopic(m.topic);
            return (
              <article key={m.id} className="rounded-2xl border border-border bg-surface p-5">
                <Badge tone="accent">{m.ncert}</Badge>
                <h2 className="mt-3 font-display text-xl">{m.title}</h2>
                <p className="mt-2 text-sm text-fg-muted">{topic.explain[level]}</p>
                <p className="mt-3 font-mono text-[10px] tracking-[0.18em] text-fg-subtle">KEY POINTS</p>
                <ul className="mt-1 list-disc space-y-1 pl-4 text-sm text-fg-muted">
                  {m.points.map((p) => (
                    <li key={p}>{p}</li>
                  ))}
                </ul>
                <p className="mt-3 font-mono text-[10px] tracking-[0.18em] text-fg-subtle">EXAM QUESTIONS</p>
                <ul className="mt-1 space-y-1 text-sm text-fg-muted">
                  {m.exam.map((p) => (
                    <li key={p}>{p}</li>
                  ))}
                </ul>
                <div className="mt-4 flex flex-wrap gap-2">
                  <Button size="sm" asChild>
                    <Link to="/lab" search={{ topic: m.topic }}>
                      3D model
                    </Link>
                  </Button>
                  {m.process ? (
                    <Button size="sm" variant="secondary" asChild>
                      <Link to="/four-d" search={{ process: m.process }}>
                        Animation
                      </Link>
                    </Button>
                  ) : null}
                  <Button size="sm" variant="outline" asChild>
                    <Link to="/quiz">Quiz</Link>
                  </Button>
                </div>
              </article>
            );
          })}
        </div>
      </main>
    </AppShell>
  );
}
