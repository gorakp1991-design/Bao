import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { LabFrame } from "@/components/layout/lab-frame";
import { CanvasStage } from "@/components/3d/canvas-stage";
import { ProcessScene } from "@/components/3d/process-scene";
import { PROCESSES, getProcess } from "@/data/processes";
import { useAppStore } from "@/store/app-store";
import { useProgress } from "@/store/progress-store";

type Search = { process?: string };

export const Route = createFileRoute("/four-d")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    process: typeof s.process === "string" ? s.process : undefined,
  }),
  component: FourDPage,
});

function FourDPage() {
  const { process: q } = Route.useSearch();
  const selected = useAppStore((s) => s.selectedProcess);
  const setProcess = useAppStore((s) => s.setProcess);
  const setTopic = useAppStore((s) => s.setTopic);
  const progress = useAppStore((s) => s.progress);
  const mark = useProgress((s) => s.markSimulation);
  const navigate = useNavigate();
  const id = q ?? selected ?? "mitosis";
  const process = getProcess(id);

  useEffect(() => {
    setProcess(process.id);
    setTopic(process.topic);
  }, [process.id, process.topic, setProcess, setTopic]);

  useEffect(() => {
    if (progress >= 1) mark(process.id);
  }, [progress, process.id, mark]);

  return (
    <AppShell lab>
      <LabFrame
        topicId={process.topic}
        processId={process.id}
        explore={PROCESSES.map((p) => ({ id: p.id, name: p.name }))}
        onExplorePick={(pid) => {
          setProcess(pid);
          void navigate({ to: "/four-d", search: { process: pid } });
        }}
      >
        <CanvasStage>
          <ProcessScene processId={process.id} t={progress} />
        </CanvasStage>
      </LabFrame>
    </AppShell>
  );
}
