import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { LabFrame } from "@/components/layout/lab-frame";
import { CanvasStage } from "@/components/3d/canvas-stage";
import { BiologyModel } from "@/components/3d/model-registry";
import { useAppStore } from "@/store/app-store";
import { useProgress } from "@/store/progress-store";
import { getTopic } from "@/data/catalog";

type LabSearch = { topic?: string };

export const Route = createFileRoute("/lab")({
  validateSearch: (s: Record<string, unknown>): LabSearch => ({
    topic: typeof s.topic === "string" ? s.topic : undefined,
  }),
  component: LabPage,
});

function LabPage() {
  const { topic } = Route.useSearch();
  const selected = useAppStore((s) => s.selectedTopic);
  const setTopic = useAppStore((s) => s.setTopic);
  const mark = useProgress((s) => s.markExplored);
  const id = topic ?? selected ?? "animal-cell";

  useEffect(() => {
    setTopic(id);
    mark(id);
  }, [id, setTopic, mark]);

  const t = getTopic(id);

  return (
    <AppShell lab>
      <LabFrame topicId={t.id}>
        <CanvasStage autoRotate>
          <BiologyModel topicId={t.id} />
        </CanvasStage>
      </LabFrame>
    </AppShell>
  );
}
