import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { LabFrame } from "@/components/layout/lab-frame";
import { CanvasStage } from "@/components/3d/canvas-stage";
import { DNAModel, PAIR } from "@/components/3d/models/dna";
import { useAppStore } from "@/store/app-store";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/dna")({ component: DNAPage });

function DNAPage() {
  const setTopic = useAppStore((s) => s.setTopic);
  const [mode, setMode] = useState<"intact" | "replication" | "transcription">("intact");
  const [mutation, setMutation] = useState(false);
  const progress = useAppStore((s) => s.progress);
  const playing = useAppStore((s) => s.playing);

  useEffect(() => setTopic("dna"), [setTopic]);

  const seq = PAIR.map((p) => p[0]).join("");
  const mutSeq = mutation ? seq.slice(0, 3) + "T" + seq.slice(4) : seq;
  const t = mode === "intact" ? 0 : playing || progress > 0 ? progress : 0.65;

  return (
    <AppShell lab>
      <LabFrame topicId="dna" processId={mode === "intact" ? undefined : mode === "replication" ? "dna-replication" : "transcription"}>
        <div className="relative h-full">
          <CanvasStage autoRotate={mode === "intact"}>
            <DNAModel
              replication={mode === "replication" ? t : 0}
              transcription={mode === "transcription" ? t : 0}
              mutationAt={mutation ? 3 : -1}
            />
          </CanvasStage>
          <div className="pointer-events-auto absolute left-3 top-16 z-10 flex max-w-[min(100%-1.5rem,20rem)] flex-col gap-2 rounded-xl border border-border bg-surface/85 p-3 text-xs">
            <p className="font-mono tracking-[0.18em] text-fg-subtle">DNA EXPLORER</p>
            <div className="flex flex-wrap gap-1">
              <Button size="sm" variant={mode === "intact" ? "default" : "secondary"} onClick={() => setMode("intact")}>
                Helix
              </Button>
              <Button size="sm" variant={mode === "replication" ? "default" : "secondary"} onClick={() => setMode("replication")}>
                Replication
              </Button>
              <Button size="sm" variant={mode === "transcription" ? "default" : "secondary"} onClick={() => setMode("transcription")}>
                Transcription
              </Button>
            </div>
            <p className="font-mono text-fg">
              Normal {seq.slice(0, 6)}
            </p>
            <Button size="sm" variant={mutation ? "default" : "outline"} onClick={() => setMutation((v) => !v)}>
              {mutation ? "Clear mutation" : "Demonstrate mutation"}
            </Button>
            {mutation ? (
              <p className="text-fg-muted">
                Substitution at base 4: {seq.slice(0, 6)} → {mutSeq.slice(0, 6)}. A single-letter change in the template. Educational only — no clinical interpretation.
              </p>
            ) : (
              <p className="text-fg-muted">Tap A, T, G or C on the helix. Complementary pairing: A–T, G–C.</p>
            )}
            <Badge tone="muted">Visualization simplified</Badge>
          </div>
        </div>
      </LabFrame>
    </AppShell>
  );
}
