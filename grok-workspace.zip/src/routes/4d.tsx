import { createFileRoute, Navigate } from "@tanstack/react-router";

export const Route = createFileRoute("/4d")({
  validateSearch: (s: Record<string, unknown>) => ({
    process: typeof s.process === "string" ? s.process : undefined,
  }),
  component: function Redirect4D() {
    const { process } = Route.useSearch();
    return <Navigate to="/four-d" search={{ process }} />;
  },
});
