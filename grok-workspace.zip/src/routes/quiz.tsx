import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/app-shell";
import { QuizEngine } from "@/components/quiz/quiz-engine";

export const Route = createFileRoute("/quiz")({ component: QuizPage });

function QuizPage() {
  return (
    <AppShell>
      <main className="py-6">
        <div className="mx-auto max-w-5xl px-4">
          <p className="font-mono text-xs tracking-[0.22em] text-accent">ASSESSMENT</p>
          <h1 className="mt-2 font-display text-4xl">Interactive quizzes</h1>
        </div>
        <QuizEngine />
      </main>
    </AppShell>
  );
}
