import { createServerFn } from "@tanstack/react-start";
import { localTutor } from "@/data/knowledge";
import type { TutorContext } from "@/data/types";

export const askBioBot = createServerFn({ method: "POST" })
  .validator((input: { message: string; context: TutorContext }) => input)
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: true as const, source: "local" as const, text: localTutor(data.context, data.message) };
    }

    const { context, message } = data;
    const system = `You are BIO-BOT, a careful biology tutor inside BioVerse, a 3D/4D learning lab.
Current model: ${context.model}
Topic: ${context.topic}
4D stage: ${context.stage ?? "n/a"}
Selected structure: ${context.selected ?? "none"}
Student level: Class ${context.level} (India NCERT-aligned where relevant).
Rules:
- Be scientifically accurate. If you simplify, say so.
- Do not give medical, diagnostic, or personal genetic advice.
- Match complexity to Class ${context.level}.
- Prefer short structured answers (function, structure, why it matters).
- If the student asks for a quiz, give one question and wait.
Keep answers under 220 words.`;

    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          max_tokens: 500,
          temperature: 0.4,
          messages: [
            { role: "system", content: system },
            { role: "user", content: message },
          ],
        }),
      });
      if (!res.ok) {
        return { ok: true as const, source: "local" as const, text: localTutor(context, message) };
      }
      const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      const text = body.choices?.[0]?.message?.content?.trim();
      if (!text) return { ok: true as const, source: "local" as const, text: localTutor(context, message) };
      return { ok: true as const, source: "ai" as const, text };
    } catch {
      return { ok: true as const, source: "local" as const, text: localTutor(context, message) };
    }
  });

export async function biologyTutor(message: string, context: TutorContext) {
  try {
    const res = await askBioBot({ data: { message, context } });
    if (res.ok && res.text) return res;
  } catch {
    /* local fallback */
  }
  return { ok: true as const, source: "local" as const, text: localTutor(context, message) };
}
