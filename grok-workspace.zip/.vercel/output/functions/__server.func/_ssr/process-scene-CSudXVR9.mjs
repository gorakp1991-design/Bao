import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { c as Vector3, f as require_jsx_runtime, o as CatmullRomCurve3, r as Html } from "../_libs/@react-three/drei+[...].mjs";
import { a as smoothstep, i as lerp } from "./router-CT1d0R-w.mjs";
import { l as stageAt, o as getProcess } from "./knowledge-p4mtwHDd.mjs";
import { s as useAppStore } from "./app-shell-B4clKprH.mjs";
import { t as DNAModel } from "./dna-sHosS2ni.mjs";
import { d as NeuronModel, o as HeartModel, t as ChloroplastModel } from "./plants-nDbdV4PM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/process-scene-CSudXVR9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProcessScene({ processId, t }) {
	switch (processId) {
		case "dna-replication": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DNAModel, { replication: t });
		case "transcription": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DNAModel, { transcription: t });
		case "neural-signal": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeuronModel, { signal: t });
		case "blood-circulation": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirculationScene, { t });
		case "photosynthesis": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotosynthesisScene, { t });
		case "mitosis": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MitosisScene, { t });
		case "meiosis": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeiosisScene, { t });
		case "translation": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TranslationScene, { t });
		case "cellular-respiration": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RespirationScene, { t });
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GenericProcessScene, {
			processId,
			t
		});
	}
}
function Chromosome({ position, split, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				-.08 - split * .35,
				0,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("capsuleGeometry", { args: [
				.07,
				.55,
				4,
				8
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				.08 + split * .35,
				0,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("capsuleGeometry", { args: [
				.07,
				.55,
				4,
				8
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color })]
		})]
	});
}
function MitosisScene({ t }) {
	const labels = useAppStore((s) => s.labels);
	const process = getProcess("mitosis");
	const stage = stageAt(process, t);
	const condense = smoothstep(.12, .32, t);
	const align = smoothstep(.32, .5, t);
	const split = smoothstep(.5, .68, t);
	const nuclei = smoothstep(.68, .86, t);
	const pinch = smoothstep(.84, 1, t);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				-pinch * 1.35,
				0,
				0
			],
			scale: [
				1 - pinch * .15,
				1,
				1
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				2.2,
				32,
				24
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
				color: "#3d8f9e",
				transparent: true,
				opacity: .12
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				pinch * 1.35,
				0,
				0
			],
			scale: [
				1 - pinch * .15,
				1,
				1
			],
			visible: pinch > .15,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				2.2,
				32,
				24
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
				color: "#3d8f9e",
				transparent: true,
				opacity: .12
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			scale: 1 - condense * .9,
			visible: nuclei < .2,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.9,
				24,
				18
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
				color: "#6b8cff",
				transparent: true,
				opacity: .35 * (1 - condense)
			})]
		}),
		[
			-.55,
			-.18,
			.18,
			.55
		].map((x0, i) => {
			const yAlign = lerp((i % 2 ? .45 : -.4) * (1 - align), 0, align);
			const ySplit = split * (i % 2 ? 1.15 : -1.15);
			const x = lerp(x0 * .4, x0, align);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chromosome, {
				position: [
					x,
					yAlign + ySplit,
					0
				],
				split,
				color: i % 2 ? "#6b8cff" : "#3ee0c5"
			}, i);
		}),
		nuclei > .2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				1.05,
				0
			],
			scale: nuclei,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.55,
				16,
				12
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
				color: "#6b8cff",
				transparent: true,
				opacity: .35
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				-1.05,
				0
			],
			scale: nuclei,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.55,
				16,
				12
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
				color: "#6b8cff",
				transparent: true,
				opacity: .35
			})]
		})] }) : null,
		labels ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Html, {
			position: [
				0,
				2.4,
				0
			],
			center: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full bg-surface px-3 py-1 font-mono text-[11px] tracking-wide text-accent",
				children: stage.name
			})
		}) : null
	] });
}
function MeiosisScene({ t }) {
	const pair = smoothstep(0, .22, t);
	const reduce = smoothstep(.38, .55, t);
	const four = smoothstep(.64, 1, t);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
			2.3,
			32,
			24
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
			color: "#3d8f9e",
			transparent: true,
			opacity: .1
		})] }),
		[-.4, .4].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chromosome, {
			position: [
				x * (1 + reduce),
				lerp(0, x > 0 ? .9 : -.9, reduce),
				0
			],
			split: four,
			color: "#c4b5fd"
		}, x)),
		[-.15, .15].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chromosome, {
			position: [
				x * (1 + reduce * .4) * pair,
				0,
				.2
			],
			split: four * .6,
			color: "#3ee0c5"
		}, `h${x}`)),
		four > .4 ? [
			[-1.2, .9],
			[1.2, .9],
			[-1.2, -.9],
			[1.2, -.9]
		].map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				p[0],
				p[1],
				0
			],
			scale: four,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.45,
				14,
				12
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
				color: "#6b8cff",
				transparent: true,
				opacity: .25
			})]
		}, i)) : null
	] });
}
function TranslationScene({ t }) {
	const n = Math.floor(lerp(2, 12, t));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		Array.from({ length: 16 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				(i - 8) * .28,
				.35,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				.22,
				.22,
				.22
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: [
				"#f07178",
				"#ffd166",
				"#06d6a0",
				"#64b5f6"
			][i % 4] })]
		}, i)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				lerp(-1.6, 1.6, t),
				0,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.55,
				16,
				16
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#93a0b4" })]
		}),
		Array.from({ length: n }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				-1.4 + i * .22,
				-.55,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.1,
				10,
				10
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#e7c27a" })]
		}, i))
	] });
}
function PhotosynthesisScene({ t }) {
	const bubbles = Math.floor(t * 10);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChloroplastModel, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				-2.2,
				1.2,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.18,
				12,
				12
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#93a0b4",
				emissive: "#e7c27a",
				emissiveIntensity: .3 + t
			})]
		}),
		Array.from({ length: bubbles }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				1.6 + i % 3 * .15,
				-.8 + (i * .22 + t) % 2.2,
				.2
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.07,
				8,
				8
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#7ee0a8",
				emissive: "#7ee0a8",
				emissiveIntensity: .6
			})]
		}, i))
	] });
}
function CirculationScene({ t }) {
	const a = t * Math.PI * 2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeartModel, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			Math.cos(a) * 2.4,
			Math.sin(a * 2) * .5,
			Math.sin(a) * 2.4
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
			.12,
			10,
			10
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			color: "#e8897a",
			emissive: "#e8897a",
			emissiveIntensity: .8
		})]
	})] });
}
function RespirationScene({ t }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		scale: [
			1.8,
			1,
			1
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
			1.1,
			24,
			16
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
			color: "#e8897a",
			transparent: true,
			opacity: .2
		})]
	}), Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			Math.cos(i) * .5,
			Math.sin(i + t * 6) * .35,
			Math.sin(i) * .4
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
			.08,
			8,
			8
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: t > .7 ? "#3ee0c5" : "#e7c27a" })]
	}, i))] });
}
function GenericProcessScene({ processId, t }) {
	const process = getProcess(processId);
	const stage = stageAt(process, t);
	const p = (0, import_react.useMemo)(() => new CatmullRomCurve3([
		new Vector3(-2, 0, 0),
		new Vector3(0, .6, 0),
		new Vector3(2, 0, 0)
	]), []).getPoint(t);
	const labels = useAppStore((s) => s.labels);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
			1.6,
			.04,
			8,
			48
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#1e2634" })] }),
		process.stages.map((s, i) => {
			const a = i / process.stages.length * Math.PI * 2;
			const on = stage.id === s.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					Math.cos(a) * 1.6,
					0,
					Math.sin(a) * 1.6
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					on ? .16 : .1,
					12,
					12
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: on ? "#3ee0c5" : "#6b7789",
					emissive: on ? "#3ee0c5" : "#000",
					emissiveIntensity: on ? .6 : 0
				})]
			}, s.id);
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: p,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("icosahedronGeometry", { args: [.28, 0] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#7ee0a8",
				emissive: "#7ee0a8",
				emissiveIntensity: .4
			})]
		}),
		labels ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Html, {
			position: [
				0,
				2.1,
				0
			],
			center: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full bg-surface px-3 py-1 font-mono text-[11px] text-accent",
				children: stage.name
			})
		}) : null
	] });
}
//#endregion
export { ProcessScene as t };
