import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { n as Button, r as cn } from "./router-CT1d0R-w.mjs";
import { c as useProgress, i as QUESTIONS, r as Badge, s as useAppStore, t as AppShell } from "./app-shell-B4clKprH.mjs";
import { t as CanvasStage } from "./canvas-stage-CVhNXXzZ.mjs";
import { t as BiologyModel } from "./model-registry-BrpWUkKC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quiz-DRlrlsSP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QuizEngine({ topic }) {
	const level = useAppStore((s) => s.classLevel);
	const selected = useAppStore((s) => s.selectedPart);
	const selectPart = useAppStore((s) => s.selectPart);
	const setTopic = useAppStore((s) => s.setTopic);
	const addQuiz = useProgress((s) => s.addQuiz);
	const bank = (0, import_react.useMemo)(() => {
		const pool = QUESTIONS.filter((q) => q.level <= level + 1 && (!topic || q.topic === topic || topic === "mixed"));
		return (pool.length ? pool : QUESTIONS).slice(0, 8);
	}, [level, topic]);
	const [i, setI] = (0, import_react.useState)(0);
	const [score, setScore] = (0, import_react.useState)(0);
	const [done, setDone] = (0, import_react.useState)(false);
	const [picked, setPicked] = (0, import_react.useState)([]);
	const [status, setStatus] = (0, import_react.useState)("idle");
	const [started] = (0, import_react.useState)(() => Date.now());
	const q = bank[i];
	if (!q) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "p-6 text-fg-muted",
		children: "No questions for this filter."
	});
	const submit = (value) => {
		if (status !== "idle") return;
		const ok = Array.isArray(q.answer) ? arraysEqual(value, q.answer) : value === q.answer;
		setStatus(ok ? "correct" : "wrong");
		if (ok) setScore((s) => s + 1);
	};
	const next = () => {
		const finished = i + 1 >= bank.length;
		const finalScore = score + (status === "correct" ? 0 : 0);
		if (finished) {
			setDone(true);
			addQuiz({
				id: `run-${started}`,
				score: finalScore,
				total: bank.length,
				at: Date.now(),
				topic: topic ?? "mixed"
			});
			return;
		}
		setI((n) => n + 1);
		setPicked([]);
		setStatus("idle");
		selectPart(null);
	};
	if (done) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg p-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-[0.2em] text-accent",
				children: "SESSION COMPLETE"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "mt-2 font-display text-3xl",
				children: [
					score,
					"/",
					bank.length
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-fg-muted",
				children: [
					"Accuracy ",
					Math.round(score / bank.length * 100),
					"% · ",
					Math.round((Date.now() - started) / 1e3),
					"s"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-6",
				onClick: () => {
					setI(0);
					setScore(0);
					setDone(false);
					setStatus("idle");
				},
				children: "Retry"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-5xl gap-6 p-4 md:grid-cols-[1.1fr_0.9fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						tone: "accent",
						children: [
							i + 1,
							"/",
							bank.length
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: q.kind }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-auto font-mono text-xs text-fg-subtle",
						children: ["Score ", score]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: q.prompt
			}),
			q.kind === "mcq" || q.kind === "tf" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-2",
				children: q.options?.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: status !== "idle",
					onClick: () => submit(opt),
					className: cn("min-h-11 rounded-xl border border-border px-4 py-3 text-left text-sm hover:bg-surface-2", status !== "idle" && opt === q.answer && "border-accent bg-accent/10"),
					children: opt
				}, opt))
			}) : null,
			q.kind === "sequence" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SequenceQuestion, {
				q,
				picked,
				setPicked,
				status,
				onSubmit: submit
			}) : null,
			q.kind === "hotspot" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-fg-muted",
				children: "Select the structure in the 3D viewport, then confirm."
			}) : null,
			status !== "idle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-xl border border-border bg-surface-2 p-4 text-sm text-fg-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: status === "correct" ? "text-accent" : "text-danger",
						children: status === "correct" ? "Correct" : "Not quite"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1",
						children: q.explain
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-3",
						onClick: next,
						children: i + 1 >= bank.length ? "See results" : "Next"
					})
				]
			}) : q.kind === "hotspot" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "mt-4",
				onClick: () => {
					if (selected) submit(selected);
				},
				children: ["Confirm selection ", selected ? `(${selected})` : ""]
			}) : null
		] }), q.kind === "hotspot" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-[360px] overflow-hidden rounded-2xl border border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HotspotStage, {
				topic: q.hotspotTarget === "left-ventricle" ? "heart" : "animal-cell",
				onReady: setTopic
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "rounded-2xl border border-border bg-surface p-5 text-sm text-fg-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-[10px] tracking-[0.2em] text-fg-subtle",
				children: "HINT"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2",
				children: "Use the 3D lab if you want to inspect the structure before answering. Weak topics are tracked on the dashboard."
			})]
		})]
	});
}
function HotspotStage({ topic, onReady }) {
	(0, import_react.useEffect)(() => {
		onReady(topic);
	}, [topic, onReady]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CanvasStage, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BiologyModel, { topicId: topic }) });
}
function SequenceQuestion({ q, picked, setPicked, status, onSubmit }) {
	const remaining = (q.options ?? []).filter((o) => !picked.includes(o));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: picked.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-accent/15 px-3 py-1 text-sm text-accent",
					children: p
				}, p))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: remaining.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					size: "sm",
					disabled: status !== "idle",
					onClick: () => setPicked([...picked, o]),
					children: o
				}, o))
			}),
			picked.length === (q.options?.length ?? 0) && status === "idle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => onSubmit(picked),
				children: "Check order"
			}) : null
		]
	});
}
function arraysEqual(a, b) {
	return a.length === b.length && a.every((v, i) => v === b[i]);
}
function QuizPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "py-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-[0.22em] text-accent",
				children: "ASSESSMENT"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl",
				children: "Interactive quizzes"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizEngine, {})]
	}) });
}
//#endregion
export { QuizPage as component };
