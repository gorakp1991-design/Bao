import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { c as localTutor } from "./knowledge-p4mtwHDd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tutor-C4RBL667.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var askBioBot_createServerFn_handler = createServerRpc({
	id: "2252afb70cdb3ba2d68558a902897d512b17e0e5dd6299178c1542e7c916bafa",
	name: "askBioBot",
	filename: "src/lib/tutor.ts"
}, (opts) => askBioBot.__executeServer(opts));
var askBioBot = createServerFn({ method: "POST" }).validator((input) => input).handler(askBioBot_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: true,
		source: "local",
		text: localTutor(data.context, data.message)
	};
	const { context, message } = data;
	const system = `You are BIO-BOT, a careful biology tutor inside BioVerse, a 3D/4D learning lab.
Current model: ${context.model}
Topic: ${context.topic}
4D stage: ${context.stage ?? "n/a"}
Selected structure: ${context.selected ?? "none"}
Student level: Class ${context.level} (India NCERT-aligned where relevant).
Rules:
- Be scientifically accurate. If you simplify, say so.
- Do not give medical, diagnostic, or personal genetic advice.
- Match complexity to Class ${context.level}.
- Prefer short structured answers (function, structure, why it matters).
- If the student asks for a quiz, give one question and wait.
Keep answers under 220 words.`;
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				max_tokens: 500,
				temperature: .4,
				messages: [{
					role: "system",
					content: system
				}, {
					role: "user",
					content: message
				}]
			})
		});
		if (!res.ok) return {
			ok: true,
			source: "local",
			text: localTutor(context, message)
		};
		const text = (await res.json()).choices?.[0]?.message?.content?.trim();
		if (!text) return {
			ok: true,
			source: "local",
			text: localTutor(context, message)
		};
		return {
			ok: true,
			source: "ai",
			text
		};
	} catch {
		return {
			ok: true,
			source: "local",
			text: localTutor(context, message)
		};
	}
});
//#endregion
export { askBioBot_createServerFn_handler };
