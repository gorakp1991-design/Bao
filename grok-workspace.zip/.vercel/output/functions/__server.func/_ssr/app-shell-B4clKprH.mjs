import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as useNavigate, d as useRouterState, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { C as Bot, _ as FlaskConical, a as Search, g as GraduationCap, h as House, i as Settings2, p as Layers, t as User } from "../_libs/lucide-react.mjs";
import { n as Button, r as cn } from "./router-CT1d0R-w.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { c as localTutor, i as TOPICS, l as stageAt, n as PROCESSES, o as getProcess, r as SUGGESTED_PROMPTS, s as getTopic } from "./knowledge-p4mtwHDd.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-shell-B4clKprH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function detectQuality() {
	if (typeof window === "undefined") return "medium";
	const mobile = window.matchMedia("(max-width: 768px)").matches;
	const cores = navigator.hardwareConcurrency ?? 4;
	if (Boolean(navigator.connection?.saveData) || mobile || cores <= 4) return "low";
	if (cores <= 8) return "medium";
	return "high";
}
function detectReducedMotion() {
	if (typeof window === "undefined") return false;
	return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}
var SYSTEMS = {
	skeletal: true,
	muscular: false,
	nervous: false,
	circulatory: true,
	respiratory: false,
	digestive: false,
	urinary: false,
	endocrine: false,
	reproductive: false,
	skin: false
};
var useAppStore = create((set) => ({
	quality: "medium",
	labels: true,
	highContrast: false,
	reducedMotion: false,
	transparency: true,
	exploded: false,
	isolatedPart: null,
	compare: false,
	selectedTopic: "animal-cell",
	selectedPart: null,
	selectedProcess: "mitosis",
	playing: false,
	speed: 1,
	progress: 0,
	classLevel: 10,
	tutorOpen: false,
	searchOpen: false,
	settingsOpen: false,
	demoActive: false,
	demoStep: 0,
	bodySystems: { ...SYSTEMS },
	setQuality: (quality) => set({ quality }),
	setLabels: (labels) => set({ labels }),
	setHighContrast: (highContrast) => {
		set({ highContrast });
		if (typeof document !== "undefined") document.documentElement.classList.toggle("high-contrast", highContrast);
	},
	setReducedMotion: (reducedMotion) => {
		set({ reducedMotion });
		if (typeof document !== "undefined") document.documentElement.classList.toggle("reduce-motion", reducedMotion);
	},
	setTransparency: (transparency) => set({ transparency }),
	setExploded: (exploded) => set({ exploded }),
	setIsolated: (isolatedPart) => set({ isolatedPart }),
	setCompare: (compare) => set({ compare }),
	setTopic: (selectedTopic) => set({
		selectedTopic,
		selectedPart: null,
		isolatedPart: null,
		exploded: false
	}),
	selectPart: (selectedPart) => set({
		selectedPart,
		isolatedPart: null
	}),
	setProcess: (selectedProcess) => set({
		selectedProcess,
		progress: 0,
		playing: false
	}),
	setPlaying: (playing) => set({ playing }),
	setSpeed: (speed) => set({ speed }),
	setProgress: (progress) => set({ progress: Math.min(1, Math.max(0, progress)) }),
	setClassLevel: (classLevel) => set({ classLevel }),
	setTutorOpen: (tutorOpen) => set({ tutorOpen }),
	setSearchOpen: (searchOpen) => set({ searchOpen }),
	setSettingsOpen: (settingsOpen) => set({ settingsOpen }),
	setDemo: (demoActive, demoStep = 0) => set({
		demoActive,
		demoStep
	}),
	toggleSystem: (id) => set((s) => ({ bodySystems: {
		...s.bodySystems,
		[id]: !s.bodySystems[id]
	} })),
	resetView: () => set({
		exploded: false,
		isolatedPart: null,
		selectedPart: null,
		progress: 0,
		playing: false,
		transparency: true
	})
}));
function hydrateClientSettings() {
	const s = useAppStore.getState();
	if (!s.reducedMotion && detectReducedMotion()) s.setReducedMotion(true);
	s.setQuality(detectQuality());
}
function TopBar() {
	const setSearchOpen = useAppStore((s) => s.setSearchOpen);
	const setTutorOpen = useAppStore((s) => s.setTutorOpen);
	const setSettingsOpen = useAppStore((s) => s.setSettingsOpen);
	const level = useAppStore((s) => s.classLevel);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 flex h-14 items-center gap-2 border-b border-border bg-bg/90 px-3 backdrop-blur-md md:h-15 md:px-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "flex items-center gap-2 pr-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-8 place-items-center rounded-md bg-accent/15 font-display text-xs text-accent",
					children: "BV"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-sm tracking-[0.18em] text-fg",
					children: "BIOVERSE"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "ml-4 hidden items-center gap-1 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {
						to: "/lab",
						label: "Lab"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {
						to: "/four-d",
						label: "4D"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {
						to: "/dna",
						label: "DNA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {
						to: "/human-body",
						label: "Body"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {
						to: "/learn",
						label: "Learn"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {
						to: "/quiz",
						label: "Quiz"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {
						to: "/dashboard",
						label: "Dashboard"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-auto flex items-center gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						size: "sm",
						className: "hidden sm:inline-flex",
						onClick: () => setSearchOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" }), "Search Biology"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						"aria-label": "Search",
						className: "sm:hidden",
						onClick: () => setSearchOpen(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						"aria-label": "AI Tutor",
						onClick: () => setTutorOpen(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bot, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						"aria-label": "Settings",
						onClick: () => setSettingsOpen(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						"aria-label": "Profile",
						title: `Class ${level} learner`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4" })
					})
				]
			})
		]
	});
}
function Nav({ to, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		className: "rounded-md px-3 py-2 text-sm text-fg-muted hover:bg-surface-2 hover:text-fg data-[status=active]:text-accent",
		activeProps: { className: "text-accent" },
		children: label
	});
}
var QUESTIONS = [
	{
		id: "q1",
		kind: "mcq",
		topic: "mitochondria",
		prompt: "What is the primary role of mitochondria?",
		options: [
			"Photosynthesis",
			"ATP production by respiration",
			"Protein packaging",
			"Storing water"
		],
		answer: "ATP production by respiration",
		explain: "Mitochondria carry out aerobic respiration and make most of the cell’s ATP.",
		level: 9
	},
	{
		id: "q2",
		kind: "mcq",
		topic: "dna",
		prompt: "Which bases pair in DNA?",
		options: [
			"A–G and T–C",
			"A–T and G–C",
			"A–C and G–T",
			"A–U and G–C"
		],
		answer: "A–T and G–C",
		explain: "Adenine pairs with thymine; guanine pairs with cytosine. RNA uses U instead of T.",
		level: 10
	},
	{
		id: "q3",
		kind: "tf",
		topic: "plant-cell",
		prompt: "Plant cells have a cellulose cell wall and usually a large central vacuole.",
		options: ["True", "False"],
		answer: "True",
		explain: "Those are key differences from typical animal cells, along with chloroplasts in green tissues.",
		level: 9
	},
	{
		id: "q4",
		kind: "sequence",
		topic: "animal-cell",
		prompt: "Sequence the stages of mitosis.",
		options: [
			"Prophase",
			"Metaphase",
			"Anaphase",
			"Telophase"
		],
		answer: [
			"Prophase",
			"Metaphase",
			"Anaphase",
			"Telophase"
		],
		explain: "After interphase, chromosomes condense (prophase), align (metaphase), separate (anaphase) and nuclei reform (telophase), then cytokinesis.",
		level: 11
	},
	{
		id: "q5",
		kind: "hotspot",
		topic: "animal-cell",
		prompt: "Click the mitochondrion in the 3D cell.",
		answer: "mitochondria",
		hotspotTarget: "mitochondria",
		explain: "Mitochondria are the bean-shaped organelles in the cytoplasm — the sites of aerobic respiration.",
		level: 9
	},
	{
		id: "q6",
		kind: "mcq",
		topic: "photosynthesis",
		prompt: "Oxygen released in photosynthesis comes mainly from:",
		options: [
			"Carbon dioxide",
			"Glucose",
			"Water",
			"ATP"
		],
		answer: "Water",
		explain: "Photosystem II splits water (photolysis). O2 is a by-product of that split.",
		level: 11
	},
	{
		id: "q7",
		kind: "mcq",
		topic: "neuron",
		prompt: "Myelin sheaths mainly:",
		options: [
			"Make neurotransmitters",
			"Speed up impulse conduction",
			"Digest organelles",
			"Store glycogen"
		],
		answer: "Speed up impulse conduction",
		explain: "Myelin insulates axons so action potentials jump between nodes of Ranvier.",
		level: 10
	},
	{
		id: "q8",
		kind: "tf",
		topic: "heart",
		prompt: "The left ventricle pumps blood to the lungs.",
		options: ["True", "False"],
		answer: "False",
		explain: "The right ventricle pumps to the lungs. The left ventricle pumps oxygenated blood into the aorta.",
		level: 10
	},
	{
		id: "q9",
		kind: "mcq",
		topic: "dna",
		prompt: "DNA replication is described as:",
		options: [
			"Conservative",
			"Semi-conservative",
			"Dispersive only",
			"Random"
		],
		answer: "Semi-conservative",
		explain: "Each daughter helix keeps one parental strand and one newly synthesised strand.",
		level: 12
	},
	{
		id: "q10",
		kind: "sequence",
		topic: "dna",
		prompt: "Sequence the central dogma flow as taught in NCERT.",
		options: [
			"DNA",
			"mRNA",
			"Protein"
		],
		answer: [
			"DNA",
			"mRNA",
			"Protein"
		],
		explain: "Transcription copies DNA into mRNA; translation builds protein. There are known exceptions (e.g. reverse transcription).",
		level: 12
	},
	{
		id: "q11",
		kind: "mcq",
		topic: "leaf",
		prompt: "Stomata are pores that mainly allow:",
		options: [
			"Minerals in from soil",
			"Gas exchange",
			"Sugar export in xylem",
			"Root hair growth"
		],
		answer: "Gas exchange",
		explain: "CO2 enters and O2/water vapour leave through stomata, controlled by guard cells.",
		level: 9
	},
	{
		id: "q12",
		kind: "hotspot",
		topic: "animal-cell",
		prompt: "Click the nucleus of the cell.",
		answer: "nucleus",
		hotspotTarget: "nucleus",
		explain: "The large central sphere is the nucleus, which stores DNA.",
		level: 9
	},
	{
		id: "q13",
		kind: "mcq",
		topic: "cellular-respiration",
		prompt: "Which stage of aerobic respiration produces the most ATP?",
		options: [
			"Glycolysis",
			"Krebs cycle",
			"Oxidative phosphorylation",
			"Lactic fermentation"
		],
		answer: "Oxidative phosphorylation",
		explain: "The electron-transport chain and ATP synthase yield the bulk of ATP.",
		level: 11
	},
	{
		id: "q14",
		kind: "tf",
		topic: "chromosome",
		prompt: "Human somatic cells normally have 23 chromosomes.",
		options: ["True", "False"],
		answer: "False",
		explain: "Somatic cells are diploid with 46 chromosomes (23 pairs). Gametes have 23.",
		level: 10
	},
	{
		id: "q15",
		kind: "mcq",
		topic: "meiosis",
		prompt: "Crossing over typically occurs during:",
		options: [
			"Prophase I",
			"Metaphase II",
			"Anaphase of mitosis",
			"Cytokinesis"
		],
		answer: "Prophase I",
		explain: "Homologous chromosomes pair and may exchange segments in Prophase I.",
		level: 12
	},
	{
		id: "q16",
		kind: "mcq",
		topic: "heart",
		prompt: "Which vessel carries deoxygenated blood from the heart to the lungs?",
		options: [
			"Aorta",
			"Pulmonary vein",
			"Pulmonary artery",
			"Vena cava"
		],
		answer: "Pulmonary artery",
		explain: "Pulmonary arteries are an exception: they carry deoxygenated blood away from the heart.",
		level: 10
	},
	{
		id: "q17",
		kind: "hotspot",
		topic: "heart",
		prompt: "Click the left ventricle.",
		answer: "left-ventricle",
		hotspotTarget: "left-ventricle",
		explain: "The left ventricle is the thick-walled lower chamber that feeds the aorta.",
		level: 10
	},
	{
		id: "q18",
		kind: "mcq",
		topic: "ribosome",
		prompt: "Ribosomes are the site of:",
		options: [
			"DNA replication",
			"Photosynthesis",
			"Translation",
			"Glycolysis only"
		],
		answer: "Translation",
		explain: "Ribosomes read mRNA and assemble polypeptides.",
		level: 10
	},
	{
		id: "q19",
		kind: "tf",
		topic: "immune-response",
		prompt: "Vaccination works partly by generating immunological memory.",
		options: ["True", "False"],
		answer: "True",
		explain: "Memory lymphocytes enable a faster, stronger secondary response. This is educational, not medical advice.",
		level: 12
	},
	{
		id: "q20",
		kind: "sequence",
		topic: "photosynthesis",
		prompt: "Sequence these photosynthetic events.",
		options: [
			"Light absorption",
			"Water splitting",
			"Calvin cycle"
		],
		answer: [
			"Light absorption",
			"Water splitting",
			"Calvin cycle"
		],
		explain: "Light reactions (including photolysis) supply ATP and NADPH for the Calvin cycle.",
		level: 11
	}
];
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-md border border-border bg-surface-2 px-3 text-sm text-fg placeholder:text-fg-subtle", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", className),
		...props
	});
}
function SearchDialog() {
	const open = useAppStore((s) => s.searchOpen);
	const setOpen = useAppStore((s) => s.setSearchOpen);
	const setTopic = useAppStore((s) => s.setTopic);
	const setProcess = useAppStore((s) => s.setProcess);
	const [q, setQ] = (0, import_react.useState)("");
	const results = (0, import_react.useMemo)(() => {
		const s = q.trim().toLowerCase();
		if (s.length < 1) return {
			models: TOPICS.slice(0, 6),
			processes: PROCESSES.slice(0, 4),
			quizzes: QUESTIONS.slice(0, 3)
		};
		return {
			models: TOPICS.filter((t) => `${t.name} ${t.summary} ${t.parts.map((p) => p.name).join(" ")}`.toLowerCase().includes(s)),
			processes: PROCESSES.filter((p) => `${p.name} ${p.summary}`.toLowerCase().includes(s)),
			quizzes: QUESTIONS.filter((item) => item.prompt.toLowerCase().includes(s))
		};
	}, [q]);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 grid place-items-start bg-bg/60 p-4 pt-[12vh]",
		onClick: () => setOpen(false),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass w-full max-w-xl rounded-2xl p-4",
			onClick: (e) => e.stopPropagation(),
			role: "dialog",
			"aria-label": "Search biology",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					autoFocus: true,
					placeholder: "Search mitochondria, mitosis, heart…",
					value: q,
					onChange: (e) => setQ(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 max-h-[50vh] space-y-4 overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
							title: "3D models",
							children: results.models.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/lab",
								search: { topic: t.id },
								className: "block rounded-lg px-3 py-2 text-sm hover:bg-surface-3",
								onClick: () => {
									setTopic(t.id);
									setOpen(false);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-fg",
									children: t.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-2 text-fg-subtle",
									children: t.summary
								})]
							}, t.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
							title: "4D processes",
							children: results.processes.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/four-d",
								search: { process: p.id },
								className: "block rounded-lg px-3 py-2 text-sm hover:bg-surface-3",
								onClick: () => {
									setProcess(p.id);
									setOpen(false);
								},
								children: p.name
							}, p.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
							title: "Quizzes",
							children: results.quizzes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/quiz",
								className: "block rounded-lg px-3 py-2 text-sm hover:bg-surface-3",
								onClick: () => setOpen(false),
								children: item.prompt
							}, item.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
							title: "Also",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/tutor",
								className: "block rounded-lg px-3 py-2 text-sm hover:bg-surface-3",
								onClick: () => setOpen(false),
								children: "Ask BIO-BOT"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/learn",
								className: "block rounded-lg px-3 py-2 text-sm hover:bg-surface-3",
								onClick: () => setOpen(false),
								children: "Learning paths"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => setOpen(false),
						children: "Close"
					})
				})
			]
		})
	});
}
function Group({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-1 font-mono text-[10px] tracking-[0.2em] text-fg-subtle",
		children: title.toUpperCase()
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-0.5",
		children
	})] });
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var askBioBot = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("2252afb70cdb3ba2d68558a902897d512b17e0e5dd6299178c1542e7c916bafa"));
async function biologyTutor(message, context) {
	try {
		const res = await askBioBot({ data: {
			message,
			context
		} });
		if (res.ok && res.text) return res;
	} catch {}
	return {
		ok: true,
		source: "local",
		text: localTutor(context, message)
	};
}
var KEY = "bioverse-progress-v1";
function load() {
	if (typeof window === "undefined") return {};
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return {};
		return JSON.parse(raw);
	} catch {
		return {};
	}
}
function save(s) {
	if (typeof window === "undefined") return;
	const { hydrated: _h, ...rest } = s;
	localStorage.setItem(KEY, JSON.stringify({
		explored: rest.explored,
		simulations: rest.simulations,
		quizzes: rest.quizzes,
		badges: rest.badges,
		recent: rest.recent,
		chats: rest.chats
	}));
}
var BADGE_META = {
	"first-look": {
		name: "First Look",
		hint: "Open any 3D model"
	},
	"cell-navigator": {
		name: "Cell Navigator",
		hint: "Inspect three organelles"
	},
	"dna-decoder": {
		name: "DNA Decoder",
		hint: "Explore the DNA helix"
	},
	"time-traveler": {
		name: "Time Traveller",
		hint: "Finish a 4D simulation"
	},
	"quiz-ace": {
		name: "Quiz Ace",
		hint: "Score 90% or higher"
	},
	"tutor-chat": {
		name: "Lab Partner",
		hint: "Ask BIO-BOT a question"
	},
	"demo-complete": {
		name: "Demo Pilot",
		hint: "Complete the guided demo"
	},
	"body-explorer": {
		name: "Body Explorer",
		hint: "Open the human body lab"
	},
	"plant-scholar": {
		name: "Plant Scholar",
		hint: "Visit plant biology"
	}
};
var useProgress = create((set, get) => ({
	explored: [],
	simulations: [],
	quizzes: [],
	badges: [],
	recent: [],
	chats: 0,
	hydrated: false,
	hydrate: () => {
		if (get().hydrated) return;
		set({
			...load(),
			hydrated: true
		});
	},
	markExplored: (id) => set((s) => {
		const explored = s.explored.includes(id) ? s.explored : [...s.explored, id];
		const recent = [id, ...s.recent.filter((x) => x !== id)].slice(0, 8);
		const badges = new Set(s.badges);
		badges.add("first-look");
		if (id === "dna") badges.add("dna-decoder");
		if (id === "human-body") badges.add("body-explorer");
		if (id === "plant-cell" || id === "leaf" || id === "chloroplast") badges.add("plant-scholar");
		if (explored.filter((x) => [
			"animal-cell",
			"plant-cell",
			"mitochondria",
			"nucleus"
		].includes(x)).length + (id === "animal-cell" ? 1 : 0) >= 1) {
			if (explored.length >= 3) badges.add("cell-navigator");
		}
		const next = {
			...s,
			explored,
			recent,
			badges: [...badges]
		};
		save(next);
		return next;
	}),
	markSimulation: (id) => set((s) => {
		const simulations = s.simulations.includes(id) ? s.simulations : [...s.simulations, id];
		const badges = s.badges.includes("time-traveler") ? s.badges : [...s.badges, "time-traveler"];
		const next = {
			...s,
			simulations,
			badges
		};
		save(next);
		return next;
	}),
	addQuiz: (r) => set((s) => {
		const quizzes = [r, ...s.quizzes].slice(0, 40);
		const badges = r.total > 0 && r.score / r.total >= .9 && !s.badges.includes("quiz-ace") ? [...s.badges, "quiz-ace"] : s.badges;
		const next = {
			...s,
			quizzes,
			badges
		};
		save(next);
		return next;
	}),
	award: (id) => set((s) => {
		if (s.badges.includes(id)) return s;
		const next = {
			...s,
			badges: [...s.badges, id]
		};
		save(next);
		return next;
	}),
	bumpChat: () => set((s) => {
		const chats = s.chats + 1;
		const badges = s.badges.includes("tutor-chat") ? s.badges : [...s.badges, "tutor-chat"];
		const next = {
			...s,
			chats,
			badges
		};
		save(next);
		return next;
	})
}));
function Badge({ className, tone = "default", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium tracking-wide uppercase", tone === "default" && "bg-surface-3 text-fg-muted", tone === "accent" && "bg-accent/15 text-accent", tone === "muted" && "bg-transparent text-fg-subtle border border-border", tone === "warn" && "bg-warn/15 text-warn", className),
		children
	});
}
function TutorDrawer() {
	const open = useAppStore((s) => s.tutorOpen);
	const setOpen = useAppStore((s) => s.setTutorOpen);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex justify-end bg-bg/50",
		onClick: () => setOpen(false),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
			className: "flex h-full w-full max-w-md flex-col bg-surface",
			onClick: (e) => e.stopPropagation(),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TutorBody, { onClose: () => setOpen(false) })
		})
	});
}
function TutorBody({ onClose }) {
	const topicId = useAppStore((s) => s.selectedTopic);
	const processId = useAppStore((s) => s.selectedProcess);
	const selected = useAppStore((s) => s.selectedPart);
	const level = useAppStore((s) => s.classLevel);
	const progress = useAppStore((s) => s.progress);
	const topic = getTopic(topicId);
	const process = getProcess(processId);
	const stage = stageAt(process, progress);
	const bump = useProgress((s) => s.bumpChat);
	const [input, setInput] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [messages, setMessages] = (0, import_react.useState)([{
		role: "bot",
		text: `BIO-BOT online. You are viewing ${topic.name}${selected ? ` → ${selected}` : ""}. Ask anything about this model.`,
		source: "local"
	}]);
	const send = async (text) => {
		const message = text.trim();
		if (!message || busy) return;
		setInput("");
		setMessages((m) => [...m, {
			role: "user",
			text: message
		}]);
		setBusy(true);
		bump();
		const res = await biologyTutor(message, {
			model: topicId,
			topic: topicId,
			stage: stage.id,
			selected,
			level
		});
		setMessages((m) => [...m, {
			role: "bot",
			text: res.text,
			source: res.source
		}]);
		setBusy(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between border-b border-border px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-base",
					children: "BIO-BOT"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-fg-subtle",
					children: [
						"Context: ",
						topic.name,
						selected ? ` / ${selected}` : "",
						" · Class ",
						level
					]
				})] }), onClose ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: onClose,
					children: "Close"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 space-y-3 overflow-y-auto p-4",
				children: [messages.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: m.role === "user" ? "ml-8 rounded-xl bg-surface-3 px-3 py-2 text-sm" : "mr-6 rounded-xl bg-surface-2 px-3 py-2 text-sm whitespace-pre-wrap text-fg-muted",
					children: [m.role === "bot" && m.source ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: m.source === "ai" ? "accent" : "muted",
						className: "mb-2",
						children: m.source === "ai" ? "Grok" : "On-device"
					}) : null, m.text]
				}, i)), busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-fg-subtle",
					children: "Thinking…"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1 px-3 pb-2",
				children: SUGGESTED_PROMPTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "rounded-full border border-border px-2.5 py-1 text-[11px] text-fg-muted hover:text-fg",
					onClick: () => void send(p),
					children: p
				}, p))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2 border-t border-border p-3",
				onSubmit: (e) => {
					e.preventDefault();
					send(input);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: input,
					onChange: (e) => setInput(e.target.value),
					placeholder: "Ask about this structure…"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: busy,
					children: "Send"
				})]
			})
		]
	});
}
function SettingsDrawer() {
	const open = useAppStore((s) => s.settingsOpen);
	const setOpen = useAppStore((s) => s.setSettingsOpen);
	const quality = useAppStore((s) => s.quality);
	const setQuality = useAppStore((s) => s.setQuality);
	const highContrast = useAppStore((s) => s.highContrast);
	const setHighContrast = useAppStore((s) => s.setHighContrast);
	const reduced = useAppStore((s) => s.reducedMotion);
	const setReduced = useAppStore((s) => s.setReducedMotion);
	const level = useAppStore((s) => s.classLevel);
	const setLevel = useAppStore((s) => s.setClassLevel);
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex justify-end bg-bg/50",
		onClick: () => setOpen(false),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "glass flex h-full w-full max-w-sm flex-col gap-5 p-5",
			onClick: (e) => e.stopPropagation(),
			role: "dialog",
			"aria-label": "Settings",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg",
						children: "Lab settings"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => setOpen(false),
						children: "Close"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Graphics quality",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							"low",
							"medium",
							"high"
						].map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: quality === q ? "default" : "secondary",
							onClick: () => setQuality(q),
							children: q
						}, q))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Learning level",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-4 gap-2",
						children: [
							9,
							10,
							11,
							12
						].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: level === n ? "default" : "secondary",
							onClick: () => setLevel(n),
							children: n
						}, n))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center justify-between gap-3 text-sm",
					children: ["High contrast", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: highContrast,
						onChange: (e) => setHighContrast(e.target.checked)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center justify-between gap-3 text-sm",
					children: ["Reduced motion", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: reduced,
						onChange: (e) => setReduced(e.target.checked)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs leading-relaxed text-fg-subtle",
					children: "Default quality is lower on phones. 3D models are procedural so the lab still runs if a file is missing."
				})
			]
		})
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-[10px] tracking-[0.2em] text-fg-subtle",
			children: label.toUpperCase()
		}), children]
	});
}
var STEPS = [
	{
		title: "Lobby",
		copy: "BioVerse is a virtual biology laboratory. Next we enter the 3D lab.",
		to: "/",
		search: void 0
	},
	{
		title: "Enter the lab",
		copy: "The viewport is a real WebGL scene. Drag to orbit the cell.",
		to: "/lab",
		search: { topic: "animal-cell" }
	},
	{
		title: "Inspect mitochondria",
		copy: "Click a bean-shaped mitochondrion. The inspector updates from the model.",
		to: "/lab",
		search: { topic: "animal-cell" },
		part: "mitochondria"
	},
	{
		title: "4D mitosis",
		copy: "Time is the fourth axis. Press Play and watch chromosomes move through stages.",
		to: "/four-d",
		search: { process: "mitosis" },
		play: true
	},
	{
		title: "DNA explorer",
		copy: "Rotate the helix and tap A, T, G or C to see complementary pairing.",
		to: "/dna",
		search: void 0
	},
	{
		title: "Ask BIO-BOT",
		copy: "The tutor knows which model you are viewing. Try “Why is this important?”",
		to: "/tutor",
		search: void 0,
		tutor: true
	},
	{
		title: "Quiz",
		copy: "Finish with a hotspot question — click the real 3D structure.",
		to: "/quiz",
		search: void 0
	}
];
function DemoController() {
	const active = useAppStore((s) => s.demoActive);
	const step = useAppStore((s) => s.demoStep);
	const setDemo = useAppStore((s) => s.setDemo);
	const setTopic = useAppStore((s) => s.setTopic);
	const selectPart = useAppStore((s) => s.selectPart);
	const setProcess = useAppStore((s) => s.setProcess);
	const setPlaying = useAppStore((s) => s.setPlaying);
	const setTutorOpen = useAppStore((s) => s.setTutorOpen);
	const award = useProgress((s) => s.award);
	const navigate = useNavigate();
	const current = STEPS[step] ?? STEPS[0];
	(0, import_react.useEffect)(() => {
		if (!active) return;
		const s = STEPS[step];
		if (!s) return;
		if (s.search?.topic) setTopic(s.search.topic);
		if (s.search?.process) setProcess(s.search.process);
		if (s.part) selectPart(s.part);
		setPlaying(Boolean(s.play));
		setTutorOpen(Boolean(s.tutor));
		navigate({
			to: s.to,
			search: s.search
		});
	}, [
		active,
		step,
		navigate,
		setTopic,
		selectPart,
		setProcess,
		setPlaying,
		setTutorOpen
	]);
	if (!active) return null;
	const last = step >= STEPS.length - 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none fixed inset-x-0 top-16 z-40 flex justify-center px-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto glass max-w-lg rounded-2xl p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-[10px] tracking-[0.22em] text-accent",
					children: [
						"DEMO ",
						step + 1,
						"/",
						STEPS.length
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-1 font-display text-lg",
					children: current.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-fg-muted",
					children: current.copy
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => {
							if (last) {
								award("demo-complete");
								setDemo(false);
								setTutorOpen(false);
								setPlaying(false);
								return;
							}
							setDemo(true, step + 1);
						},
						children: last ? "Finish" : "Next"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => {
							setDemo(false);
							setTutorOpen(false);
							setPlaying(false);
						},
						children: "Skip demo"
					})]
				})
			]
		})
	});
}
function startDemo() {
	useAppStore.getState().setDemo(true, 0);
}
var NAV = [
	{
		to: "/",
		label: "Home",
		icon: House
	},
	{
		to: "/lab",
		label: "Explore",
		icon: FlaskConical
	},
	{
		to: "/four-d",
		label: "4D",
		icon: Layers
	},
	{
		to: "/learn",
		label: "Learn",
		icon: GraduationCap
	},
	{
		to: "/tutor",
		label: "AI",
		icon: Bot
	}
];
function AppShell({ children, lab }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const hydrate = useProgress((s) => s.hydrate);
	(0, import_react.useEffect)(() => {
		hydrate();
		hydrateClientSettings();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const tag = e.target?.tagName;
			const typing = tag === "INPUT" || tag === "TEXTAREA";
			if (e.key === "Escape") {
				const s = useAppStore.getState();
				s.setSearchOpen(false);
				s.setTutorOpen(false);
				s.setSettingsOpen(false);
			}
			if (!typing && e.key === "/") {
				e.preventDefault();
				useAppStore.getState().setSearchOpen(true);
			}
			if (!typing && e.key === " " && (pathname.includes("four-d") || pathname.includes("4d") || pathname.includes("dna") || pathname.includes("neuron"))) {
				e.preventDefault();
				const s = useAppStore.getState();
				s.setPlaying(!s.playing);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [pathname]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#main",
				className: "sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-accent focus:px-3 focus:py-2 focus:text-accent-fg",
				children: "Skip to content"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "main",
				className: cn(lab ? "h-[calc(100dvh-3.5rem)]" : "pb-20 md:pb-0"),
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-surface/95 backdrop-blur-md md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-5",
					children: NAV.map((item) => {
						const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: cn("flex h-14 flex-col items-center justify-center gap-0.5 text-[10px]", active ? "text-accent" : "text-fg-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), item.label]
						}) }, item.to);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchDialog, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TutorDrawer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsDrawer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoController, {})
		]
	});
}
//#endregion
export { TutorBody as a, useProgress as c, QUESTIONS as i, BADGE_META as n, startDemo as o, Badge as r, useAppStore as s, AppShell as t };
