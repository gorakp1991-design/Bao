import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { n as Button } from "./router-CT1d0R-w.mjs";
import { t as AppShell } from "./app-shell-B4clKprH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ar-dOH_lYJ3.js
var import_jsx_runtime = require_jsx_runtime();
function ARPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-lg px-4 py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-[0.22em] text-accent",
				children: "WEBXR"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl",
				children: "AR mode coming soon."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-fg-muted",
				children: "The lab is structured so a future WebXR session can mount the same procedural models in an immersive camera. This build does not fake AR in a 2D browser."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-6",
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/lab",
					children: "Return to 3D lab"
				})
			})
		]
	}) });
}
//#endregion
export { ARPage as component };
