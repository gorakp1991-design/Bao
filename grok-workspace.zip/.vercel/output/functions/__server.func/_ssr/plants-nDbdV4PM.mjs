import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { c as Vector3, f as require_jsx_runtime, o as CatmullRomCurve3, r as Html } from "../_libs/@react-three/drei+[...].mjs";
import { i as lerp } from "./router-CT1d0R-w.mjs";
import { s as useAppStore } from "./app-shell-B4clKprH.mjs";
import { n as usePart, t as partMaterial } from "./bio-part-8i2nKLAN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/plants-nDbdV4PM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Tag({ text, on }) {
	if (!on) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Html, {
		center: true,
		distanceFactor: 9,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "rounded-full border border-border bg-surface px-2 py-0.5 font-mono text-[10px] text-fg-muted whitespace-nowrap",
			children: text
		})
	});
}
function Chamber({ id, label, color, pos, explode, scale = [
	1,
	1,
	1
] }) {
	const { active, dimmed, transparency, exploded, bind } = usePart(id);
	const labels = useAppStore((s) => s.labels);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: exploded ? explode : pos,
		scale,
		...bind,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.72,
				24,
				18
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color,
				active,
				dimmed,
				transparency,
				opacity: .88
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
				text: label,
				on: labels && (active || exploded)
			})
		]
	});
}
function HeartModel() {
	const aorta = usePart("aorta");
	const pa = usePart("pulmonary-artery");
	const valves = usePart("valves");
	const exploded = useAppStore((s) => s.exploded);
	const labels = useAppStore((s) => s.labels);
	const k = exploded ? 1 : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		rotation: [
			.15,
			.4,
			0
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chamber, {
				id: "left-ventricle",
				label: "Left ventricle",
				color: "#e8897a",
				pos: [
					-.45,
					-.55,
					.1
				],
				explode: [
					-1.35,
					-.9,
					.2
				],
				scale: [
					1.05,
					1.2,
					.95
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chamber, {
				id: "right-ventricle",
				label: "Right ventricle",
				color: "#f0a898",
				pos: [
					.5,
					-.45,
					.05
				],
				explode: [
					1.4,
					-.8,
					.15
				],
				scale: [
					.9,
					1,
					.9
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chamber, {
				id: "left-atrium",
				label: "Left atrium",
				color: "#c45c6a",
				pos: [
					-.4,
					.55,
					.15
				],
				explode: [
					-1.3,
					1.15,
					.3
				],
				scale: [
					.85,
					.7,
					.8
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chamber, {
				id: "right-atrium",
				label: "Right atrium",
				color: "#d98b96",
				pos: [
					.48,
					.5,
					.1
				],
				explode: [
					1.35,
					1.1,
					.25
				],
				scale: [
					.82,
					.68,
					.78
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					lerp(0, 0, k),
					lerp(1.35, 2.1, k),
					0
				],
				...aorta.bind,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
						.16,
						.2,
						1.1,
						12
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
						color: "#e7c27a",
						active: aorta.active,
						dimmed: aorta.dimmed,
						opacity: .95
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
						text: "Aorta",
						on: labels && (aorta.active || exploded)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					lerp(.15, .8, k),
					lerp(1.15, 1.9, k),
					.15
				],
				rotation: [
					.4,
					0,
					.5
				],
				...pa.bind,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
						.13,
						.16,
						.9,
						12
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
						color: "#7aa2ff",
						active: pa.active,
						dimmed: pa.dimmed,
						opacity: .95
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
						text: "Pulmonary artery",
						on: labels && (pa.active || exploded)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.05,
					.55
				],
				...valves.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
					.22,
					.04,
					8,
					18
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#e8eef6",
					active: valves.active,
					dimmed: valves.dimmed,
					opacity: .85
				}) })]
			})
		]
	});
}
function LungsModel() {
	const lungs = usePart("alveoli");
	const bronchi = usePart("bronchi");
	const trachea = usePart("trachea");
	const dia = usePart("diaphragm");
	const exploded = useAppStore((s) => s.exploded);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: exploded ? [
				-1.6,
				.2,
				0
			] : [
				-.85,
				.15,
				0
			],
			scale: [
				.9,
				1.25,
				.7
			],
			...lungs.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				1,
				24,
				18
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#e8b4b8",
				active: lungs.active,
				dimmed: lungs.dimmed,
				transparency: true,
				opacity: .7
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: exploded ? [
				1.6,
				.2,
				0
			] : [
				.85,
				.15,
				0
			],
			scale: [
				.82,
				1.2,
				.68
			],
			...lungs.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				1,
				24,
				18
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#e8b4b8",
				active: lungs.active,
				dimmed: lungs.dimmed,
				transparency: true,
				opacity: .7
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				1.55,
				0
			],
			...trachea.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.16,
				.16,
				1.1,
				12
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#d7c4a3",
				active: trachea.active,
				dimmed: trachea.dimmed,
				opacity: 1
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				-.25,
				.9,
				0
			],
			rotation: [
				0,
				0,
				.6
			],
			...bronchi.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.1,
				.12,
				.7,
				10
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#d7c4a3",
				active: bronchi.active,
				dimmed: bronchi.dimmed,
				opacity: 1
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				.25,
				.9,
				0
			],
			rotation: [
				0,
				0,
				-.6
			],
			...bronchi.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.1,
				.12,
				.7,
				10
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#d7c4a3",
				active: bronchi.active,
				dimmed: bronchi.dimmed,
				opacity: 1
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				-1.5,
				0
			],
			rotation: [
				.2,
				0,
				0
			],
			...dia.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				1.4,
				24,
				12,
				0,
				Math.PI * 2,
				0,
				Math.PI / 3
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#c45c6a",
				active: dia.active,
				dimmed: dia.dimmed,
				opacity: .55
			}) })]
		})
	] });
}
function KidneyModel() {
	const cortex = usePart("cortex");
	const medulla = usePart("medulla");
	const nephron = usePart("nephron");
	const pelvis = usePart("pelvis");
	const exploded = useAppStore((s) => s.exploded);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		rotation: [
			0,
			.4,
			.15
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				scale: [
					1.1,
					1.45,
					.7
				],
				...cortex.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					1.1,
					28,
					20
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#c45c6a",
					active: cortex.active,
					dimmed: cortex.dimmed,
					transparency: true,
					opacity: .45
				}) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				scale: [
					.7,
					1,
					.45
				],
				position: exploded ? [
					1.3,
					0,
					0
				] : [
					0,
					0,
					0
				],
				...medulla.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					1,
					20,
					16
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#e8897a",
					active: medulla.active,
					dimmed: medulla.dimmed,
					opacity: .85
				}) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: exploded ? [
					.2,
					.4,
					.6
				] : [
					.15,
					.25,
					.35
				],
				...nephron.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
					.18,
					.05,
					8,
					16
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#3ee0c5",
					active: nephron.active,
					dimmed: nephron.dimmed,
					opacity: 1
				}) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: exploded ? [
					0,
					-1.8,
					0
				] : [
					0,
					-1.2,
					0
				],
				...pelvis.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("coneGeometry", { args: [
					.28,
					.7,
					10
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#e7c27a",
					active: pelvis.active,
					dimmed: pelvis.dimmed,
					opacity: .9
				}) })]
			})
		]
	});
}
function DigestiveModel() {
	const stomach = usePart("stomach");
	const si = usePart("small-intestine");
	const liver = usePart("liver");
	const pancreas = usePart("pancreas");
	const li = usePart("large-intestine");
	const exploded = useAppStore((s) => s.exploded);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: exploded ? [
				-1.6,
				1.1,
				0
			] : [
				-.6,
				.85,
				0
			],
			rotation: [
				.3,
				.2,
				-.4
			],
			scale: [
				1.1,
				.7,
				.7
			],
			...stomach.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.7,
				20,
				14
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#e8897a",
				active: stomach.active,
				dimmed: stomach.dimmed,
				opacity: .9
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: exploded ? [
				1.7,
				1.2,
				0
			] : [
				.7,
				1.05,
				0
			],
			rotation: [
				0,
				.3,
				.2
			],
			scale: [
				1.3,
				.7,
				.9
			],
			...liver.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.75,
				20,
				14
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#a84c3a",
				active: liver.active,
				dimmed: liver.dimmed,
				opacity: .92
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: exploded ? [
				0,
				.2,
				1.2
			] : [
				.1,
				.35,
				.4
			],
			rotation: [
				0,
				0,
				.4
			],
			...pancreas.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
				.12,
				.16,
				1.1,
				10
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#e7c27a",
				active: pancreas.active,
				dimmed: pancreas.dimmed,
				opacity: .95
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: exploded ? [
				0,
				-.6,
				0
			] : [
				0,
				-.2,
				0
			],
			...si.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
				.7,
				.12,
				8,
				32
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#d4a574",
				active: si.active,
				dimmed: si.dimmed,
				opacity: .9
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: exploded ? [
				0,
				-1.8,
				0
			] : [
				0,
				-1.15,
				0
			],
			...li.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
				1.05,
				.16,
				8,
				24,
				Math.PI * 1.4
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#c45c6a",
				active: li.active,
				dimmed: li.dimmed,
				opacity: .88
			}) })]
		})
	] });
}
function CirculatoryModel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeartModel, {}), Array.from({ length: 10 }).map((_, i) => {
		const a = i / 10 * Math.PI * 2;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				Math.cos(a) * 2.3,
				Math.sin(a * 1.4) * .4,
				Math.sin(a) * 2.3
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.06,
				8,
				8
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: i % 2 ? "#e8897a" : "#7aa2ff",
				emissive: i % 2 ? "#e8897a" : "#7aa2ff",
				emissiveIntensity: .4
			})]
		}, i);
	})] });
}
function RespiratoryModel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LungsModel, {});
}
function NucleusModel() {
	const envelope = usePart("envelope");
	const pore = usePart("pore");
	const nucleolus = usePart("nucleolus");
	const chromatin = usePart("chromatin");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			...envelope.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				1.6,
				32,
				24
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
				color: "#6b8cff",
				transparent: true,
				opacity: .25,
				roughness: .2
			})]
		}),
		Array.from({ length: 8 }).map((_, i) => {
			const a = i / 8 * Math.PI * 2;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					Math.cos(a) * 1.55,
					Math.sin(a * .7) * .4,
					Math.sin(a) * 1.55
				],
				...pore.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.12,
					10,
					10
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#3ee0c5",
					active: pore.active,
					dimmed: pore.dimmed,
					opacity: 1
				}) })]
			}, i);
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			...nucleolus.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.4,
				16,
				16
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#c4b5fd",
				active: nucleolus.active,
				dimmed: nucleolus.dimmed,
				opacity: 1
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			rotation: [
				.5,
				.3,
				0
			],
			...chromatin.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
				.85,
				.05,
				8,
				32
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#93a0b4",
				active: chromatin.active,
				dimmed: chromatin.dimmed,
				opacity: .8
			}) })]
		})
	] });
}
function MitochondriaModel() {
	const outer = usePart("outer-membrane");
	const inner = usePart("inner-membrane");
	const matrix = usePart("matrix");
	const cristae = usePart("cristae");
	const exploded = useAppStore((s) => s.exploded);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		rotation: [
			.3,
			.6,
			0
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				scale: [
					1.8,
					1,
					1
				],
				...outer.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					1.15,
					28,
					20
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
					color: "#e8897a",
					transparent: true,
					opacity: .22,
					roughness: .3
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				scale: [
					1.5,
					.82,
					.82
				],
				position: exploded ? [
					2.1,
					0,
					0
				] : [
					0,
					0,
					0
				],
				...inner.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					1.05,
					24,
					18
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
					color: "#c45c6a",
					transparent: true,
					opacity: .35,
					roughness: .35
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: exploded ? [
					2.1,
					0,
					0
				] : [
					0,
					0,
					0
				],
				...matrix.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.55,
					16,
					16
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#e7c27a",
					active: matrix.active,
					dimmed: matrix.dimmed,
					opacity: .7
				}) })]
			}),
			[
				-.35,
				0,
				.35
			].map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					exploded ? 2.1 : 0,
					y,
					0
				],
				rotation: [
					.2,
					.4,
					0
				],
				...cristae.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
					.55,
					.04,
					8,
					20
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#f0a898",
					active: cristae.active,
					dimmed: cristae.dimmed,
					opacity: .9
				}) })]
			}, y))
		]
	});
}
function RibosomeModel() {
	const small = usePart("small-subunit");
	const large = usePart("large-subunit");
	const epa = usePart("epa");
	const exploded = useAppStore((s) => s.exploded);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				exploded ? .7 : .28,
				0
			],
			...small.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.7,
				24,
				18
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#93a0b4",
				active: small.active,
				dimmed: small.dimmed,
				opacity: .95
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				exploded ? -.8 : -.45,
				0
			],
			scale: [
				1.15,
				.9,
				1.1
			],
			...large.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.95,
				24,
				18
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#6b7789",
				active: large.active,
				dimmed: large.dimmed,
				opacity: .95
			}) })]
		}),
		[
			-.25,
			0,
			.25
		].map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				x,
				0,
				.7
			],
			...epa.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.12,
				10,
				10
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: [
				"#3ee0c5",
				"#e7c27a",
				"#e8897a"
			][i] })]
		}, i))
	] });
}
function ChromosomeModel() {
	const chromatid = usePart("chromatid");
	const centromere = usePart("centromere");
	const telomere = usePart("telomere");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		rotation: [
			.2,
			.4,
			.1
		],
		children: [
			[-.18, .18].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
				position: [
					x,
					0,
					0
				],
				...chromatid.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						0,
						.7,
						0
					],
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("capsuleGeometry", { args: [
						.16,
						1.1,
						6,
						12
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
						color: "#6b8cff",
						active: chromatid.active,
						dimmed: chromatid.dimmed,
						opacity: 1
					}) })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						0,
						-.7,
						0
					],
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("capsuleGeometry", { args: [
						.16,
						1.1,
						6,
						12
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
						color: "#6b8cff",
						active: chromatid.active,
						dimmed: chromatid.dimmed,
						opacity: 1
					}) })]
				})]
			}, x)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				...centromere.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.22,
					12,
					12
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#e7c27a",
					active: centromere.active,
					dimmed: centromere.dimmed,
					opacity: 1
				}) })]
			}),
			[-1.35, 1.35].map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					.18,
					y,
					0
				],
				...telomere.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.12,
					10,
					10
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#3ee0c5",
					active: telomere.active,
					dimmed: telomere.dimmed,
					opacity: 1
				}) })]
			}, y))
		]
	});
}
function RNAModel() {
	const mrna = usePart("mrna");
	const trna = usePart("trna");
	const rrna = usePart("rrna");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		Array.from({ length: 18 }).map((_, i) => {
			const y = (i / 17 - .5) * 4.5;
			const x = Math.sin(i * .7) * .35;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					x,
					y,
					0
				],
				...mrna.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.14,
					10,
					10
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: [
					"#f07178",
					"#ffd166",
					"#06d6a0",
					"#64b5f6"
				][i % 4] })]
			}, i);
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				1.6,
				.4,
				.3
			],
			...trna.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("capsuleGeometry", { args: [
				.12,
				.7,
				6,
				10
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#e7c27a",
				active: trna.active,
				dimmed: trna.dimmed,
				opacity: 1
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				-1.5,
				-.2,
				0
			],
			...rrna.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.55,
				16,
				16
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#93a0b4",
				active: rrna.active,
				dimmed: rrna.dimmed,
				opacity: .9
			}) })]
		})
	] });
}
function NeuronModel({ signal = 0 }) {
	const dendrites = usePart("dendrites");
	const soma = usePart("soma");
	const axon = usePart("axon");
	const myelin = usePart("myelin");
	const terminals = usePart("terminals");
	useAppStore((s) => s.labels);
	const axonCurve = (0, import_react.useMemo)(() => {
		const pts = [
			new Vector3(.7, 0, 0),
			new Vector3(1.4, -.15, .1),
			new Vector3(2.4, -.05, 0),
			new Vector3(3.4, .2, -.15),
			new Vector3(4.3, .05, 0)
		];
		return new CatmullRomCurve3(pts);
	}, []);
	const pulse = axonCurve.getPoint(Math.min(.98, Math.max(0, signal)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			-1.4,
			.2,
			0
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				...soma.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.7,
					24,
					18
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#8bd3dd",
					active: soma.active,
					dimmed: soma.dimmed,
					opacity: .92
				}) })]
			}),
			[
				[
					.9,
					.8,
					.2
				],
				[
					1.1,
					.2,
					.7
				],
				[
					.7,
					-.7,
					.4
				],
				[
					1,
					.5,
					-.7
				]
			].map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
				...dendrites.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						-d[0],
						d[1],
						d[2]
					],
					rotation: [
						.3 * i,
						.2,
						.5
					],
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
						.03,
						.08,
						1.1,
						8
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
						color: "#7ee0c5",
						active: dendrites.active,
						dimmed: dendrites.dimmed,
						opacity: 1
					}) })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						-d[0] * 1.45,
						d[1] * 1.35,
						d[2] * 1.2
					],
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
						.08,
						8,
						8
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#7ee0c5" })]
				})]
			}, i)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				...axon.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tubeGeometry", { args: [
					axonCurve,
					48,
					.07,
					8,
					false
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#93a0b4",
					active: axon.active,
					dimmed: axon.dimmed,
					opacity: 1
				}) })]
			}),
			[
				.22,
				.4,
				.58,
				.75
			].map((t) => {
				const p = axonCurve.getPoint(t);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: p,
					...myelin.bind,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
						.16,
						12,
						10
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
						color: "#e8eef6",
						active: myelin.active,
						dimmed: myelin.dimmed,
						opacity: .85
					}) })]
				}, t);
			}),
			[
				0,
				1,
				2
			].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					4.4,
					.2 * (i - 1),
					.15 * (i - 1)
				],
				...terminals.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.14,
					12,
					12
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#e7c27a",
					active: terminals.active,
					dimmed: terminals.dimmed,
					opacity: 1
				}) })]
			}, i)),
			signal > .02 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: pulse,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.14,
					12,
					12
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#3ee0c5",
					emissive: "#3ee0c5",
					emissiveIntensity: 1.2
				})]
			}) : null,
			signal > .85 ? Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					4.6 + i % 3 * .12,
					Math.sin(i) * .2,
					Math.cos(i) * .2
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.045,
					8,
					8
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#e7c27a",
					emissive: "#e7c27a",
					emissiveIntensity: .8
				})]
			}, i)) : null
		]
	});
}
function ChloroplastModel() {
	const thylakoid = usePart("thylakoid");
	const granum = usePart("granum");
	const stroma = usePart("stroma");
	const exploded = useAppStore((s) => s.exploded);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		rotation: [
			.3,
			.5,
			0
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			scale: [
				1.7,
				1,
				.9
			],
			...stroma.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				1.15,
				28,
				18
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
				color: "#3d9a5f",
				transparent: true,
				opacity: .22,
				roughness: .3
			})]
		}), [
			-.35,
			.05,
			.4
		].map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
			position: [
				exploded ? x * 2.2 : x,
				0,
				0
			],
			...granum.bind,
			children: [
				0,
				1,
				2,
				3,
				4
			].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					n * .09 - .18,
					0
				],
				...thylakoid.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
					.38 - i * .04,
					.38 - i * .04,
					.07,
					16
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#2f7a4a",
					active: thylakoid.active || granum.active,
					dimmed: thylakoid.dimmed,
					opacity: .95
				}) })]
			}, n))
		}, i))]
	});
}
function FlowerModel() {
	const petal = usePart("petal");
	const sepal = usePart("sepal");
	const stamen = usePart("stamen");
	const carpel = usePart("carpel");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		Array.from({ length: 6 }).map((_, i) => {
			const a = i / 6 * Math.PI * 2;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					Math.cos(a) * .85,
					.15,
					Math.sin(a) * .85
				],
				rotation: [
					.9,
					a,
					0
				],
				...petal.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.45,
					12,
					10
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#e8b4c8",
					active: petal.active,
					dimmed: petal.dimmed,
					opacity: .9
				}) })]
			}, i);
		}),
		Array.from({ length: 5 }).map((_, i) => {
			const a = i / 5 * Math.PI * 2 + .3;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					Math.cos(a) * .55,
					-.25,
					Math.sin(a) * .55
				],
				rotation: [
					1.1,
					a,
					0
				],
				...sepal.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.28,
					10,
					8
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#3d9a5f",
					active: sepal.active,
					dimmed: sepal.dimmed,
					opacity: .9
				}) })]
			}, i);
		}),
		Array.from({ length: 5 }).map((_, i) => {
			const a = i / 5 * Math.PI * 2;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					Math.cos(a) * .25,
					.55,
					Math.sin(a) * .25
				],
				...stamen.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
					.03,
					.03,
					.7,
					6
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#e7c27a" })]
			}, i);
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: [
				0,
				.35,
				0
			],
			...carpel.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("capsuleGeometry", { args: [
				.12,
				.55,
				6,
				10
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#7ee0a8",
				active: carpel.active,
				dimmed: carpel.dimmed,
				opacity: 1
			}) })]
		})
	] });
}
function LeafModel() {
	const epi = usePart("epidermis");
	const pal = usePart("palisade");
	const spo = usePart("spongy");
	const sto = usePart("stomata");
	const vein = usePart("vein");
	const gap = useAppStore((s) => s.exploded) ? .35 : .08;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		rotation: [
			.4,
			.2,
			0
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					gap * 2,
					0
				],
				...epi.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					3.2,
					.08,
					1.6
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
					color: "#cde8c8",
					transparent: true,
					opacity: .35
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					gap,
					0
				],
				...pal.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					3,
					.35,
					1.4
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#3d9a5f",
					active: pal.active,
					dimmed: pal.dimmed,
					opacity: .9
				}) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					0,
					0
				],
				...spo.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					3,
					.4,
					1.4
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#5fb36f",
					active: spo.active,
					dimmed: spo.dimmed,
					opacity: .55
				}) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					-gap,
					0
				],
				...epi.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					3.2,
					.08,
					1.6
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
					color: "#cde8c8",
					transparent: true,
					opacity: .35
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					gap * .5,
					0
				],
				...vein.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					3.1,
					.06,
					.12
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#d7c4a3" })]
			}),
			[
				-.8,
				0,
				.8
			].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					x,
					-gap * 1.2,
					.55
				],
				...sto.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
					.08,
					.03,
					8,
					12
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#3ee0c5",
					active: sto.active,
					dimmed: sto.dimmed,
					opacity: 1
				}) })]
			}, x))
		]
	});
}
function RootModel() {
	const hair = usePart("root-hair");
	const cap = usePart("cap");
	const xylem = usePart("xylem");
	const phloem = usePart("phloem");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		rotation: [
			0,
			.3,
			0
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.4,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
					.45,
					.55,
					2.6,
					12
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#c4a574",
					roughness: .7
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					-1.15,
					0
				],
				...cap.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("coneGeometry", { args: [
					.5,
					.55,
					10
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#a8845a",
					active: cap.active,
					dimmed: cap.dimmed,
					opacity: 1
				}) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.3,
					0
				],
				...xylem.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
					.12,
					.12,
					2.1,
					8
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#e7c27a" })]
			}),
			Array.from({ length: 6 }).map((_, i) => {
				const a = i / 6 * Math.PI * 2;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						Math.cos(a) * .22,
						.3,
						Math.sin(a) * .22
					],
					...phloem.bind,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
						.05,
						.05,
						2.1,
						6
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#3d9a5f" })]
				}, i);
			}),
			Array.from({ length: 12 }).map((_, i) => {
				const a = i / 12 * Math.PI * 2;
				const y = -.2 + i % 4 * .25;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						Math.cos(a) * .7,
						y,
						Math.sin(a) * .7
					],
					rotation: [
						.6,
						a,
						0
					],
					...hair.bind,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
						.015,
						.03,
						.55,
						6
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
						color: "#e8d5b5",
						active: hair.active,
						dimmed: hair.dimmed,
						opacity: 1
					}) })]
				}, i);
			})
		]
	});
}
//#endregion
export { FlowerModel as a, LeafModel as c, NeuronModel as d, NucleusModel as f, RootModel as g, RibosomeModel as h, DigestiveModel as i, LungsModel as l, RespiratoryModel as m, ChromosomeModel as n, HeartModel as o, RNAModel as p, CirculatoryModel as r, KidneyModel as s, ChloroplastModel as t, MitochondriaModel as u };
