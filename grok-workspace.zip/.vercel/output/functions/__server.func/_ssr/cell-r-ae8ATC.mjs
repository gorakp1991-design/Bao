import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { n as Button } from "./router-CT1d0R-w.mjs";
import { s as useAppStore, t as AppShell } from "./app-shell-B4clKprH.mjs";
import { t as CanvasStage } from "./canvas-stage-CVhNXXzZ.mjs";
import { t as LabFrame } from "./lab-frame-Da2b-2HG.mjs";
import { t as BiologyModel } from "./model-registry-BrpWUkKC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cell-r-ae8ATC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CellPage() {
	const setTopic = useAppStore((s) => s.setTopic);
	const topic = useAppStore((s) => s.selectedTopic);
	const compare = useAppStore((s) => s.compare);
	const setCompare = useAppStore((s) => s.setCompare);
	const exploded = useAppStore((s) => s.exploded);
	const setExploded = useAppStore((s) => s.setExploded);
	const selected = useAppStore((s) => s.selectedPart);
	const setIsolated = useAppStore((s) => s.setIsolated);
	const isolated = useAppStore((s) => s.isolatedPart);
	const id = topic === "plant-cell" ? "plant-cell" : "animal-cell";
	(0, import_react.useEffect)(() => {
		if (topic !== "plant-cell" && topic !== "animal-cell") setTopic("animal-cell");
	}, [topic, setTopic]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		lab: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabFrame, {
			topicId: id,
			explore: [{
				id: "animal-cell",
				name: "Animal Cell"
			}, {
				id: "plant-cell",
				name: "Plant Cell"
			}],
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-full",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CanvasStage, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BiologyModel, { topicId: id }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute left-3 top-16 z-10 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: id === "animal-cell" ? "default" : "secondary",
							onClick: () => setTopic("animal-cell"),
							children: "Animal"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: id === "plant-cell" ? "default" : "secondary",
							onClick: () => setTopic("plant-cell"),
							children: "Plant"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: compare ? "default" : "secondary",
							onClick: () => setCompare(!compare),
							children: "Compare"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: exploded ? "default" : "secondary",
							onClick: () => setExploded(!exploded),
							children: "Explode view"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: isolated ? "default" : "secondary",
							onClick: () => setIsolated(isolated ? null : selected),
							children: "Isolate"
						})
					]
				})]
			})
		})
	});
}
//#endregion
export { CellPage as component };
