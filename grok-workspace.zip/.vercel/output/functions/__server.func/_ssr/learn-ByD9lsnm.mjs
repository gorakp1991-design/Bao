import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { n as Button } from "./router-CT1d0R-w.mjs";
import { s as getTopic } from "./knowledge-p4mtwHDd.mjs";
import { r as Badge, s as useAppStore, t as AppShell } from "./app-shell-B4clKprH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn-ByD9lsnm.js
var import_jsx_runtime = require_jsx_runtime();
var MODULES = [
	{
		id: "cell-basics",
		title: "The Fundamental Unit of Life",
		classLevels: [9, 10],
		topic: "animal-cell",
		ncert: "Class 9 — The Fundamental Unit of Life",
		points: [
			"All living organisms are made of cells (cell theory).",
			"Plasma membrane is selectively permeable.",
			"Nucleus houses DNA; cytoplasm holds organelles.",
			"Plant cells add wall, chloroplasts and a large vacuole."
		],
		exam: [
			"State the three main points of cell theory.",
			"Why is the plasma membrane called selectively permeable?",
			"List three differences between plant and animal cells."
		]
	},
	{
		id: "life-processes",
		title: "Life Processes",
		classLevels: [10],
		topic: "heart",
		process: "blood-circulation",
		ncert: "Class 10 — Life Processes",
		points: [
			"Nutrition, respiration, transport, excretion.",
			"Human heart: four chambers, double circulation.",
			"Alveoli are the site of gas exchange.",
			"Nephrons filter blood to form urine."
		],
		exam: [
			"Draw a labelled schematic of double circulation.",
			"Why is the left ventricle thicker than the right?",
			"Explain how alveoli are adapted for gas exchange."
		]
	},
	{
		id: "control",
		title: "Control and Coordination",
		classLevels: [10, 11],
		topic: "neuron",
		process: "neural-signal",
		ncert: "Class 10 Control and Coordination; Class 11 Neural Control",
		points: [
			"Neurons carry electrical impulses.",
			"Synapse uses chemical transmitters.",
			"Reflex arcs are rapid, involuntary pathways.",
			"Hormones provide slower chemical coordination."
		],
		exam: [
			"Trace the path of a spinal reflex.",
			"What is the role of myelin?",
			"Differentiate nervous and endocrine control."
		]
	},
	{
		id: "cell-cycle",
		title: "Cell Cycle and Cell Division",
		classLevels: [11, 12],
		topic: "chromosome",
		process: "mitosis",
		ncert: "Class 11 — Cell Cycle and Cell Division",
		points: [
			"Interphase includes G1, S and G2.",
			"Mitosis conserves chromosome number.",
			"Meiosis halves the number and increases variation.",
			"Crossing over occurs in prophase I."
		],
		exam: [
			"Compare mitosis and meiosis in a table.",
			"What is the significance of meiosis in sexual reproduction?",
			"Name the checkpoint that occurs at metaphase."
		]
	},
	{
		id: "molecular",
		title: "Molecular Basis of Inheritance",
		classLevels: [12],
		topic: "dna",
		process: "dna-replication",
		ncert: "Class 12 — Molecular Basis of Inheritance",
		points: [
			"DNA is a double helix with complementary bases.",
			"Replication is semi-conservative.",
			"Transcription produces RNA; translation produces protein.",
			"The genetic code is triplet, degenerate and nearly universal."
		],
		exam: [
			"State Chargaff’s rules.",
			"Describe Meselson and Stahl’s experiment in outline.",
			"Explain why the genetic code is described as degenerate."
		]
	},
	{
		id: "photo",
		title: "Photosynthesis in Higher Plants",
		classLevels: [11],
		topic: "chloroplast",
		process: "photosynthesis",
		ncert: "Class 11 — Photosynthesis in Higher Plants",
		points: [
			"Light reactions in thylakoids; Calvin cycle in stroma.",
			"Photolysis of water releases O2.",
			"ATP and NADPH fuel carbon fixation.",
			"C3, C4 and CAM differ in CO2 handling."
		],
		exam: [
			"Write the simplified net equation of photosynthesis.",
			"Where do light-dependent reactions occur?",
			"Why do C4 plants have an advantage in hot climates? (brief)"
		]
	},
	{
		id: "plant-anatomy",
		title: "Leaf, Root and Transport",
		classLevels: [
			9,
			10,
			11
		],
		topic: "leaf",
		ncert: "Class 9 Tissues; Class 11 Transport in Plants",
		points: [
			"Xylem transports water; phloem transports sugars.",
			"Stomata regulate gas exchange and transpiration.",
			"Root hairs increase absorption area.",
			"Transpiration pull helps xylem ascent."
		],
		exam: [
			"Describe the pathway of water from soil to leaf.",
			"How do guard cells open a stoma?",
			"Differentiate xylem and phloem."
		]
	},
	{
		id: "human-phys",
		title: "Human Physiology Overview",
		classLevels: [11, 12],
		topic: "human-body",
		ncert: "Class 11 Human Physiology unit",
		points: [
			"Systems cooperate to keep homeostasis.",
			"Cardiac output = stroke volume × heart rate.",
			"Nephrons perform filtration, reabsorption, secretion.",
			"Sliding filament theory explains skeletal muscle contraction."
		],
		exam: [
			"Define homeostasis with one example.",
			"Outline the cardiac cycle.",
			"Explain sliding filament theory in brief."
		]
	}
];
function modulesFor(level) {
	return MODULES.filter((m) => m.classLevels.includes(level));
}
function LearnPage() {
	const level = useAppStore((s) => s.classLevel);
	const setLevel = useAppStore((s) => s.setClassLevel);
	const modules = modulesFor(level);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-5xl px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-[0.22em] text-accent",
				children: "LEARNING MODE"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl",
				children: "Choose your class"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm text-fg-muted",
				children: "Explanations shift from simple Class 9 language to NCERT-level Class 12 terminology."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex flex-wrap gap-2",
				children: [
					9,
					10,
					11,
					12
				].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: level === n ? "default" : "secondary",
					onClick: () => setLevel(n),
					children: ["Class ", n]
				}, n))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-4 md:grid-cols-2",
				children: modules.map((m) => {
					const topic = getTopic(m.topic);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-2xl border border-border bg-surface p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "accent",
								children: m.ncert
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-xl",
								children: m.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-fg-muted",
								children: topic.explain[level]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 font-mono text-[10px] tracking-[0.18em] text-fg-subtle",
								children: "KEY POINTS"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-1 list-disc space-y-1 pl-4 text-sm text-fg-muted",
								children: m.points.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: p }, p))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 font-mono text-[10px] tracking-[0.18em] text-fg-subtle",
								children: "EXAM QUESTIONS"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-1 space-y-1 text-sm text-fg-muted",
								children: m.exam.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: p }, p))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/lab",
											search: { topic: m.topic },
											children: "3D model"
										})
									}),
									m.process ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "secondary",
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/four-d",
											search: { process: m.process },
											children: "Animation"
										})
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/quiz",
											children: "Quiz"
										})
									})
								]
							})
						]
					}, m.id);
				})
			})
		]
	}) });
}
//#endregion
export { LearnPage as component };
