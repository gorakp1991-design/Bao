import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { s as Route$8 } from "./router-CT1d0R-w.mjs";
import { n as PROCESSES, o as getProcess } from "./knowledge-p4mtwHDd.mjs";
import { c as useProgress, s as useAppStore, t as AppShell } from "./app-shell-B4clKprH.mjs";
import { t as CanvasStage } from "./canvas-stage-CVhNXXzZ.mjs";
import { t as LabFrame } from "./lab-frame-Da2b-2HG.mjs";
import { t as ProcessScene } from "./process-scene-CSudXVR9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/four-d-B1tfQohE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FourDPage() {
	const { process: q } = Route$8.useSearch();
	const selected = useAppStore((s) => s.selectedProcess);
	const setProcess = useAppStore((s) => s.setProcess);
	const setTopic = useAppStore((s) => s.setTopic);
	const progress = useAppStore((s) => s.progress);
	const mark = useProgress((s) => s.markSimulation);
	const navigate = useNavigate();
	const process = getProcess(q ?? selected ?? "mitosis");
	(0, import_react.useEffect)(() => {
		setProcess(process.id);
		setTopic(process.topic);
	}, [
		process.id,
		process.topic,
		setProcess,
		setTopic
	]);
	(0, import_react.useEffect)(() => {
		if (progress >= 1) mark(process.id);
	}, [
		progress,
		process.id,
		mark
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		lab: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabFrame, {
			topicId: process.topic,
			processId: process.id,
			explore: PROCESSES.map((p) => ({
				id: p.id,
				name: p.name
			})),
			onExplorePick: (pid) => {
				setProcess(pid);
				navigate({
					to: "/four-d",
					search: { process: pid }
				});
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CanvasStage, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProcessScene, {
				processId: process.id,
				t: progress
			}) })
		})
	});
}
//#endregion
export { FourDPage as component };
