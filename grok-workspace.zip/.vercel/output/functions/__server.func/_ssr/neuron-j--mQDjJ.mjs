import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { s as useAppStore, t as AppShell } from "./app-shell-B4clKprH.mjs";
import { t as CanvasStage } from "./canvas-stage-CVhNXXzZ.mjs";
import { t as LabFrame } from "./lab-frame-Da2b-2HG.mjs";
import { t as ProcessScene } from "./process-scene-CSudXVR9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/neuron-j--mQDjJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NeuronPage() {
	const setTopic = useAppStore((s) => s.setTopic);
	const setProcess = useAppStore((s) => s.setProcess);
	const t = useAppStore((s) => s.progress);
	(0, import_react.useEffect)(() => {
		setTopic("neuron");
		setProcess("neural-signal");
	}, [setTopic, setProcess]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		lab: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabFrame, {
			topicId: "neuron",
			processId: "neural-signal",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CanvasStage, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProcessScene, {
				processId: "neural-signal",
				t
			}) })
		})
	});
}
//#endregion
export { NeuronPage as component };
