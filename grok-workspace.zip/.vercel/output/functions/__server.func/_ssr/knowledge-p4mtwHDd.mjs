//#region node_modules/.nitro/vite/services/ssr/assets/knowledge-p4mtwHDd.js
var lv = (nine, ten, eleven, twelve) => ({
	9: nine,
	10: ten,
	11: eleven,
	12: twelve
});
var TOPICS = [
	{
		id: "animal-cell",
		name: "Animal Cell",
		category: "cell",
		summary: "The basic unit of animal life — a membrane-bound factory of organelles.",
		function: "Carries out metabolism, growth, response, and division for animal tissues.",
		structure: "Plasma membrane, cytoplasm, nucleus, and membrane-bound organelles. No cell wall or large central vacuole.",
		facts: [
			"Typical eukaryotic diameter is about 10–30 µm.",
			"Mitochondria and the nucleus contain their own DNA.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "membrane",
				name: "Plasma Membrane",
				function: "Selectively permeable barrier that controls entry and exit.",
				structure: "Phospholipid bilayer with proteins and cholesterol.",
				location: "Outer boundary of the cell",
				fact: "Described by the fluid mosaic model."
			},
			{
				id: "cytoplasm",
				name: "Cytoplasm",
				function: "Site of many metabolic reactions; suspends organelles.",
				structure: "Cytosol plus cytoskeleton.",
				location: "Interior of the cell",
				fact: "About 70% water by mass."
			},
			{
				id: "nucleus",
				name: "Nucleus",
				function: "Stores DNA and controls gene expression.",
				structure: "Double nuclear envelope with pores; contains chromatin.",
				location: "Usually central",
				fact: "The nucleolus inside assembles ribosome subunits."
			},
			{
				id: "nucleolus",
				name: "Nucleolus",
				function: "Ribosome subunit assembly.",
				structure: "Dense nuclear region of rRNA and protein.",
				location: "Inside the nucleus",
				fact: "Not membrane-bound."
			},
			{
				id: "mitochondria",
				name: "Mitochondrion",
				function: "Aerobic respiration and ATP synthesis.",
				structure: "Double membrane; inner membrane folded into cristae.",
				location: "Cytoplasm",
				fact: "Often called the powerhouse of the cell."
			},
			{
				id: "ribosome",
				name: "Ribosome",
				function: "Protein synthesis (translation).",
				structure: "Large and small rRNA-protein subunits.",
				location: "Cytosol or rough ER",
				fact: "Present in both prokaryotes and eukaryotes."
			},
			{
				id: "er",
				name: "Endoplasmic Reticulum",
				function: "Protein and lipid synthesis; intracellular transport.",
				structure: "Network of membranous cisternae; rough ER has ribosomes.",
				location: "Around the nucleus",
				fact: "Smooth ER also detoxifies some compounds."
			},
			{
				id: "golgi",
				name: "Golgi Apparatus",
				function: "Modifies, sorts and packages proteins and lipids.",
				structure: "Stacked flattened cisternae.",
				location: "Near the nucleus / ER",
				fact: "Has cis (receiving) and trans (shipping) faces."
			},
			{
				id: "lysosome",
				name: "Lysosome",
				function: "Digests macromolecules and worn-out organelles.",
				structure: "Membrane vesicle with hydrolytic enzymes.",
				location: "Cytoplasm",
				fact: "Internal pH is acidic (~5)."
			},
			{
				id: "centriole",
				name: "Centriole",
				function: "Helps organise the mitotic spindle in animal cells.",
				structure: "Cylinder of microtubule triplets.",
				location: "Centrosome near nucleus",
				fact: "Plant cells typically lack centrioles."
			}
		],
		related: [
			"plant-cell",
			"nucleus",
			"mitochondria",
			"dna"
		],
		processes: [
			"mitosis",
			"cellular-respiration",
			"translation"
		],
		ncert: "Class 9 The Fundamental Unit of Life; Class 11 Cell: The Unit of Life.",
		explain: lv("An animal cell is a tiny living room. A thin skin (membrane) holds jelly-like cytoplasm and a control centre called the nucleus.", "Animal cells are eukaryotic: they have a true nucleus and organelles. They lack a cell wall, unlike plant cells.", "The plasma membrane is a fluid mosaic bilayer. Organelles compartmentalise metabolism — mitochondria for ATP, RER/Golgi for the secretory pathway.", "Eukaryotic compartmentalisation allows oxidative phosphorylation on cristae, transcription in the nucleus, and vesicular trafficking via ER–Golgi. Lysosomal hydrolases are delivered by the mannose-6-phosphate pathway.")
	},
	{
		id: "plant-cell",
		name: "Plant Cell",
		category: "cell",
		summary: "A walled eukaryotic cell with chloroplasts and a large vacuole.",
		function: "Photosynthesis, support, storage, and growth in plant tissues.",
		structure: "Cell wall of cellulose, plasma membrane, chloroplasts, large central vacuole, nucleus and other organelles.",
		facts: [
			"The cell wall is freely permeable; the membrane is selective.",
			"The vacuole can occupy most of the cell volume.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "wall",
				name: "Cell Wall",
				function: "Rigid support and protection; prevents bursting in hypotonic solutions.",
				structure: "Cellulose microfibrils in a matrix of hemicellulose and pectin.",
				location: "Outside the plasma membrane",
				fact: "Primary walls are thinner; secondary walls may lignify."
			},
			{
				id: "membrane",
				name: "Plasma Membrane",
				function: "Selective transport and signalling.",
				structure: "Phospholipid bilayer with proteins.",
				location: "Inside the wall",
				fact: "Plasmodesmata connect neighbouring plant cells."
			},
			{
				id: "vacuole",
				name: "Central Vacuole",
				function: "Stores water, ions and wastes; maintains turgor.",
				structure: "Membrane (tonoplast) around cell sap.",
				location: "Most of the cell interior",
				fact: "Turgor pressure keeps non-woody plants upright."
			},
			{
				id: "chloroplast",
				name: "Chloroplast",
				function: "Photosynthesis — light energy to chemical energy.",
				structure: "Double membrane; thylakoids stacked as grana; stroma.",
				location: "Cytoplasm of green cells",
				fact: "Contains chlorophyll and its own circular DNA."
			},
			{
				id: "nucleus",
				name: "Nucleus",
				function: "Genetic control of the cell.",
				structure: "Nuclear envelope, chromatin, nucleolus.",
				location: "Often pushed aside by the vacuole",
				fact: "Connected to ER."
			},
			{
				id: "mitochondria",
				name: "Mitochondrion",
				function: "Respiration and ATP even in photosynthetic cells.",
				structure: "Double membrane with cristae.",
				location: "Cytoplasm",
				fact: "Plants respire day and night."
			},
			{
				id: "golgi",
				name: "Golgi Apparatus",
				function: "Builds cell-wall polysaccharides and sorts proteins.",
				structure: "Cisternae stacks (dictyosomes in plants).",
				location: "Cytoplasm",
				fact: "Active during cell-plate formation."
			}
		],
		related: [
			"animal-cell",
			"chloroplast",
			"leaf",
			"photosynthesis"
		],
		processes: ["photosynthesis", "mitosis"],
		ncert: "Class 9 The Fundamental Unit of Life; Class 11 Cell: The Unit of Life, Photosynthesis in Higher Plants.",
		explain: lv("Plant cells have a strong box (cell wall), a big water bag (vacuole) and green kitchens (chloroplasts) that make food.", "Compared with animal cells, plant cells have a cellulose wall, chloroplasts and a large vacuole. They usually lack centrioles.", "Turgor from the vacuole and cellulose walls provide hydrostatic skeletons. Chloroplasts perform light and dark reactions of photosynthesis.", "Primary walls are deposited at the cell plate (phragmoplast). Chloroplasts are semi-autonomous organelles of endosymbiotic origin with thylakoid membrane systems.")
	},
	{
		id: "dna",
		name: "DNA",
		category: "molecular",
		summary: "Deoxyribonucleic acid — the double helix that stores genetic information.",
		function: "Stores and transmits hereditary information; template for RNA synthesis.",
		structure: "Two antiparallel polynucleotide strands in a right-handed double helix, bases paired A–T and G–C.",
		facts: [
			"Chargaff’s rules: A equals T, G equals C in double-stranded DNA.",
			"One helical turn is about 10.5 base pairs in B-DNA.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "backbone",
				name: "Sugar–Phosphate Backbone",
				function: "Covalent scaffold of the strand.",
				structure: "Deoxyribose sugars linked by phosphodiester bonds.",
				location: "Outside of the helix",
				fact: "The 5′ to 3′ direction defines polarity."
			},
			{
				id: "adenine",
				name: "Adenine (A)",
				function: "Purine base; pairs with thymine.",
				structure: "Double-ring nitrogenous base.",
				location: "Inside the helix",
				fact: "Two hydrogen bonds with thymine."
			},
			{
				id: "thymine",
				name: "Thymine (T)",
				function: "Pyrimidine base; pairs with adenine.",
				structure: "Single-ring base with a methyl group.",
				location: "Inside the helix",
				fact: "RNA uses uracil instead of thymine."
			},
			{
				id: "guanine",
				name: "Guanine (G)",
				function: "Purine base; pairs with cytosine.",
				structure: "Double-ring base.",
				location: "Inside the helix",
				fact: "Three hydrogen bonds with cytosine — stronger pair."
			},
			{
				id: "cytosine",
				name: "Cytosine (C)",
				function: "Pyrimidine base; pairs with guanine.",
				structure: "Single-ring base.",
				location: "Inside the helix",
				fact: "GC-rich DNA is more thermally stable."
			},
			{
				id: "base-pair",
				name: "Base Pair",
				function: "Complementary hydrogen-bonded unit of information.",
				structure: "A–T or G–C pair stacked in the helix.",
				location: "Core of the helix",
				fact: "Stacking interactions also stabilise the helix."
			}
		],
		related: [
			"rna",
			"chromosome",
			"nucleus"
		],
		processes: [
			"dna-replication",
			"transcription",
			"translation"
		],
		ncert: "Class 12 Molecular Basis of Inheritance.",
		explain: lv("DNA is like a twisted ladder. The rungs are four letters — A, T, G, C — that store instructions for life.", "DNA is a double helix of two strands. A always pairs with T, and G with C. This pairing lets DNA copy itself.", "B-DNA is a right-handed helix. Antiparallel strands (5′–3′ vs 3′–5′) and complementary bases enable semi-conservative replication.", "Watson–Crick pairing, phosphodiester polarity and major/minor grooves allow sequence-specific protein binding (e.g. transcription factors, polymerases).")
	},
	{
		id: "rna",
		name: "RNA",
		category: "molecular",
		summary: "Ribonucleic acid — single-stranded messenger, transfer and ribosomal forms.",
		function: "Carries genetic messages, catalyses peptide bonds (rRNA), and brings amino acids (tRNA).",
		structure: "Ribose-phosphate backbone with bases A, U, G, C; often folded into secondary structure.",
		facts: [
			"mRNA is read in codons of three bases.",
			"rRNA is the catalytic core of the ribosome.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "mrna",
				name: "mRNA",
				function: "Carries coding sequence from DNA to ribosomes.",
				structure: "Single strand, often with 5′ cap and poly-A tail in eukaryotes.",
				location: "Nucleus then cytosol",
				fact: "Codons specify amino acids."
			},
			{
				id: "trna",
				name: "tRNA",
				function: "Adaptor that matches codon to amino acid.",
				structure: "Cloverleaf / L-shaped fold with anticodon.",
				location: "Cytosol",
				fact: "Aminoacyl-tRNA synthetases charge tRNAs."
			},
			{
				id: "rrna",
				name: "rRNA",
				function: "Structural and catalytic component of ribosomes.",
				structure: "Highly folded RNA-protein complex.",
				location: "Ribosomes",
				fact: "Peptidyl transferase is a ribozyme."
			}
		],
		related: ["dna", "ribosome"],
		processes: ["transcription", "translation"],
		ncert: "Class 12 Molecular Basis of Inheritance.",
		explain: lv("RNA is a working copy of DNA instructions. It helps the cell build proteins.", "Three main types: mRNA (message), tRNA (translator), rRNA (ribosome). RNA uses U instead of T.", "Transcription produces pre-mRNA in eukaryotes, processed by splicing. Translation reads mRNA 5′ to 3′.", "The central dogma: DNA → RNA → protein, with well-characterised exceptions (reverse transcriptase in retroviruses).")
	},
	{
		id: "chromosome",
		name: "Chromosome",
		category: "molecular",
		summary: "A condensed DNA–protein package visible during cell division.",
		function: "Organises and segregates the genome during mitosis and meiosis.",
		structure: "Chromatin fibre of DNA and histones; duplicated chromosomes have two sister chromatids joined at a centromere.",
		facts: [
			"Humans have 46 chromosomes (23 pairs) in somatic cells.",
			"Telomeres protect chromosome ends.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "chromatid",
				name: "Sister Chromatid",
				function: "Identical DNA copy after replication.",
				structure: "One of two arms of a duplicated chromosome.",
				location: "Joined at the centromere",
				fact: "Separated at anaphase of mitosis."
			},
			{
				id: "centromere",
				name: "Centromere",
				function: "Attachment site for kinetochore and spindle.",
				structure: "Constricted region of specialised chromatin.",
				location: "Centre or off-centre depending on type",
				fact: "Defines metacentric vs acrocentric shapes."
			},
			{
				id: "telomere",
				name: "Telomere",
				function: "Protects ends from shortening damage.",
				structure: "Repetitive DNA with shelterin proteins.",
				location: "Chromosome ends",
				fact: "Telomerase can extend telomeres in some cells."
			}
		],
		related: ["dna", "nucleus"],
		processes: [
			"mitosis",
			"meiosis",
			"dna-replication"
		],
		ncert: "Class 11 Cell Cycle and Cell Division; Class 12 Inheritance.",
		explain: lv("Chromosomes are packed DNA, like tightly coiled threads, so they can be shared fairly when a cell splits.", "Before a cell divides, each chromosome is copied. The two copies (chromatids) stay attached until they are pulled apart.", "Histone octamers wrap DNA into nucleosomes. Condensin and cohesin organise mitotic chromosomes.", "Kinetochores assemble on centromeric chromatin and capture microtubules, enabling the spindle assembly checkpoint.")
	},
	{
		id: "nucleus",
		name: "Nucleus",
		category: "cell",
		summary: "The membrane-bound archive of eukaryotic DNA.",
		function: "Stores the genome; site of transcription and ribosome-subunit assembly.",
		structure: "Double nuclear envelope with nuclear pores; nucleoplasm, chromatin and nucleolus.",
		facts: [
			"Nuclear pores are large protein complexes (nuclear pore complexes).",
			"Most human cells are uninucleate; skeletal muscle is multinucleate.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "envelope",
				name: "Nuclear Envelope",
				function: "Separates nucleoplasm from cytoplasm.",
				structure: "Two lipid bilayers continuous with ER.",
				location: "Boundary of the nucleus",
				fact: "Breaks down in open mitosis of animal cells."
			},
			{
				id: "pore",
				name: "Nuclear Pore",
				function: "Regulated transport of RNA and proteins.",
				structure: "Nucleoporin complex.",
				location: "Envelope",
				fact: "Small molecules diffuse; large cargos need signals."
			},
			{
				id: "nucleolus",
				name: "Nucleolus",
				function: "rRNA synthesis and ribosome assembly.",
				structure: "Fibrillar and granular components.",
				location: "Interior",
				fact: "Number of nucleoli varies with cell activity."
			},
			{
				id: "chromatin",
				name: "Chromatin",
				function: "Packaged DNA for regulation and storage.",
				structure: "DNA + histones (euchromatin / heterochromatin).",
				location: "Nucleoplasm",
				fact: "Euchromatin is more transcriptionally active."
			}
		],
		related: [
			"animal-cell",
			"dna",
			"chromosome"
		],
		processes: ["transcription", "mitosis"],
		ncert: "Class 11 Cell: The Unit of Life.",
		explain: lv("The nucleus is the cell’s control room. It keeps DNA safe and sends out RNA messages.", "A double membrane with pores surrounds DNA. The nucleolus makes parts of ribosomes.", "Importins and exportins ferry proteins and RNPs through nuclear pores using the Ran GTPase gradient.", "Nuclear lamina (lamins) provides mechanical support; mutations cause laminopathies. Chromosome territories occupy non-random nuclear positions.")
	},
	{
		id: "mitochondria",
		name: "Mitochondria",
		category: "cell",
		summary: "Double-membraned organelles that generate most of the cell’s ATP.",
		function: "Aerobic respiration: Krebs cycle and oxidative phosphorylation.",
		structure: "Smooth outer membrane, inner membrane folded into cristae, matrix with mtDNA and ribosomes.",
		facts: [
			"mtDNA is typically inherited from the mother in humans.",
			"Endosymbiotic origin from alphaproteobacteria.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "outer-membrane",
				name: "Outer Membrane",
				function: "Permeable barrier with porins.",
				structure: "Lipid bilayer with VDAC channels.",
				location: "Exterior",
				fact: "Intermembrane space lies beneath it."
			},
			{
				id: "inner-membrane",
				name: "Inner Membrane",
				function: "Electron transport and ATP synthase.",
				structure: "Highly folded cristae; rich in proteins.",
				location: "Interior folds",
				fact: "Impermeable to protons — essential for the proton gradient."
			},
			{
				id: "matrix",
				name: "Matrix",
				function: "Krebs cycle, mtDNA, mitochondrial translation.",
				structure: "Aqueous interior with enzymes.",
				location: "Inside inner membrane",
				fact: "Contains circular DNA molecules."
			},
			{
				id: "cristae",
				name: "Cristae",
				function: "Increase surface area for respiration.",
				structure: "Invaginations of inner membrane.",
				location: "Inner membrane",
				fact: "ATP synthase rows sit on cristae edges."
			}
		],
		related: ["animal-cell", "plant-cell"],
		processes: ["cellular-respiration"],
		ncert: "Class 11 Cell: The Unit of Life; Respiration in Plants; Class 11 Breathing and Exchange of Gases (context).",
		explain: lv("Mitochondria are tiny power stations. They burn food energy to make ATP, the cell’s rechargeable battery.", "Glucose products enter mitochondria. Oxygen is used; carbon dioxide and lots of ATP come out.", "Pyruvate is oxidised to acetyl-CoA. The Krebs cycle reduces NAD+ and FAD; the ETC pumps protons to drive ATP synthase.", "Chemiosmotic coupling (Mitchell): proton-motive force across the inner membrane powers FoF1 ATP synthase. Uncouplers dissipate the gradient as heat.")
	},
	{
		id: "ribosome",
		name: "Ribosome",
		category: "cell",
		summary: "The molecular machine that translates mRNA into polypeptide chains.",
		function: "Protein synthesis.",
		structure: "Two subunits (40S/60S in eukaryotes) made of rRNA and proteins.",
		facts: [
			"Antibiotics like tetracycline target bacterial ribosomes.",
			"A eukaryotic cell may contain millions of ribosomes.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "small-subunit",
				name: "Small Subunit",
				function: "Decodes mRNA.",
				structure: "40S (eukaryotes) or 30S (prokaryotes).",
				location: "Assembled on mRNA",
				fact: "Holds the mRNA path and decoding centre."
			},
			{
				id: "large-subunit",
				name: "Large Subunit",
				function: "Catalyses peptide-bond formation.",
				structure: "60S or 50S.",
				location: "Joined after initiation",
				fact: "Peptidyl transferase is rRNA-catalysed."
			},
			{
				id: "epa",
				name: "A, P and E Sites",
				function: "tRNA binding during elongation.",
				structure: "Three tRNA pockets.",
				location: "Interface of subunits",
				fact: "A = aminoacyl, P = peptidyl, E = exit."
			}
		],
		related: ["rna", "er"],
		processes: ["translation"],
		ncert: "Class 11 Cell: The Unit of Life; Class 12 Molecular Basis of Inheritance.",
		explain: lv("Ribosomes are protein factories. They read RNA and link amino acids like beads on a string.", "Free ribosomes make proteins for the cytosol. Ribosomes on rough ER make proteins for membranes or export.", "Initiation, elongation and termination use protein factors and GTP hydrolysis.", "The ribosome is a ribozyme. Shine–Dalgarno (prokaryotes) vs Kozak (eukaryotes) sequences help start-codon selection.")
	},
	{
		id: "neuron",
		name: "Neuron",
		category: "organ",
		summary: "An electrically excitable cell that transmits information in the nervous system.",
		function: "Receives, integrates and sends electrochemical signals.",
		structure: "Dendrites, soma, axon (often myelinated), and axon terminals forming synapses.",
		facts: [
			"Resting membrane potential is typically about −70 mV.",
			"Myelin greatly increases conduction speed (saltatory conduction).",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "dendrites",
				name: "Dendrites",
				function: "Receive synaptic input.",
				structure: "Branched cytoplasmic processes.",
				location: "Around the soma",
				fact: "Spines increase synaptic surface area."
			},
			{
				id: "soma",
				name: "Cell Body (Soma)",
				function: "Integrates signals; houses nucleus and metabolism.",
				structure: "Perikaryon with Nissl substance (RER).",
				location: "Centre of the neuron",
				fact: "Action potentials usually start at the axon hillock."
			},
			{
				id: "axon",
				name: "Axon",
				function: "Conducts action potentials away from the soma.",
				structure: "Long process, uniform diameter.",
				location: "From hillock to terminals",
				fact: "Can be over a metre long in humans."
			},
			{
				id: "myelin",
				name: "Myelin Sheath",
				function: "Insulates the axon and speeds conduction.",
				structure: "Wrapped glial membrane (Schwann cell or oligodendrocyte).",
				location: "Along the axon, interrupted at nodes",
				fact: "Nodes of Ranvier expose membrane for ion flux."
			},
			{
				id: "terminals",
				name: "Axon Terminals",
				function: "Release neurotransmitter onto a target.",
				structure: "Synaptic boutons with vesicles.",
				location: "End of the axon",
				fact: "Ca2+ influx triggers vesicle fusion."
			}
		],
		related: ["human-body"],
		processes: ["neural-signal"],
		ncert: "Class 10 Control and Coordination; Class 11 Neural Control and Coordination.",
		explain: lv("A neuron is a message cell. It picks up signals at branches, and sends a spark along a long wire to the next cell.", "Information travels as an electrical impulse (action potential). At the end, chemicals called neurotransmitters cross the gap.", "Voltage-gated Na+ and K+ channels produce the action potential. Myelinated axons fire in jumps between nodes of Ranvier.", "The Hodgkin–Huxley cycle: local depolarisation opens NaV channels (positive feedback), then KV and NaV inactivation restore polarity. Chemical synapses are usually unidirectional.")
	},
	{
		id: "heart",
		name: "Heart",
		category: "organ",
		summary: "A four-chambered muscular pump of the circulatory system.",
		function: "Drives pulmonary and systemic blood flow.",
		structure: "Two atria, two ventricles, valves, and great vessels; myocardium of cardiac muscle.",
		facts: [
			"Adult resting rate is often about 60–80 beats per minute.",
			"The left ventricle has the thickest wall because it pumps to the whole body.",
			"Visualization simplified for educational purposes — not a medical image."
		],
		parts: [
			{
				id: "left-ventricle",
				name: "Left Ventricle",
				function: "Pumps oxygenated blood into the aorta.",
				structure: "Thick myocardium; mitral inflow, aortic outflow.",
				location: "Lower left chamber",
				fact: "Generates the highest systolic pressure."
			},
			{
				id: "right-ventricle",
				name: "Right Ventricle",
				function: "Pumps deoxygenated blood to the lungs.",
				structure: "Thinner wall than the left ventricle.",
				location: "Lower right chamber",
				fact: "Pulmonary circuit is a lower-pressure system."
			},
			{
				id: "left-atrium",
				name: "Left Atrium",
				function: "Receives oxygenated blood from pulmonary veins.",
				structure: "Thin-walled chamber.",
				location: "Upper left",
				fact: "Four pulmonary veins typically enter it."
			},
			{
				id: "right-atrium",
				name: "Right Atrium",
				function: "Receives deoxygenated blood from venae cavae.",
				structure: "Thin-walled; contains SA node in its wall.",
				location: "Upper right",
				fact: "The pacemaker (SA node) starts each beat."
			},
			{
				id: "aorta",
				name: "Aorta",
				function: "Main artery carrying blood to the body.",
				structure: "Elastic artery.",
				location: "Leaving the left ventricle",
				fact: "The aortic valve prevents backflow."
			},
			{
				id: "pulmonary-artery",
				name: "Pulmonary Artery",
				function: "Carries deoxygenated blood to the lungs.",
				structure: "Arterial vessel from the right ventricle.",
				location: "Leaving the right ventricle",
				fact: "One of the few arteries with deoxygenated blood."
			},
			{
				id: "valves",
				name: "Valves",
				function: "Keep blood flowing in one direction.",
				structure: "Atrioventricular (mitral, tricuspid) and semilunar (aortic, pulmonary).",
				location: "Between chambers and at outflows",
				fact: "Heart sounds relate to valve closure."
			}
		],
		related: [
			"circulatory-system",
			"lungs",
			"human-body"
		],
		processes: ["blood-circulation"],
		ncert: "Class 10 Life Processes; Class 11 Body Fluids and Circulation.",
		explain: lv("The heart is a pump with four rooms. It sends blood to the lungs for oxygen, then around the body.", "Double circulation: pulmonary (heart–lungs) and systemic (heart–body). Valves stop blood flowing backwards.", "Cardiac muscle is myogenic. The SA node → AV node → bundle of His → Purkinje fibres coordinates contraction.", "The cardiac cycle includes atrial systole, ventricular systole (isovolumetric contraction then ejection) and diastole. Stroke volume × heart rate = cardiac output.")
	},
	{
		id: "lungs",
		name: "Lungs",
		category: "organ",
		summary: "Paired organs of gas exchange.",
		function: "Oxygenate blood and remove carbon dioxide.",
		structure: "Bronchial tree ending in alveoli, richly supplied with capillaries.",
		facts: [
			"The right lung has three lobes; the left has two (space for the heart).",
			"Alveoli provide a huge surface area — tens of square metres.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "trachea",
				name: "Trachea",
				function: "Conducts air to the bronchi.",
				structure: "C-shaped cartilage rings and ciliated epithelium.",
				location: "Neck to thorax",
				fact: "Lined with mucus that traps particles."
			},
			{
				id: "bronchi",
				name: "Bronchi",
				function: "Distribute air into each lung.",
				structure: "Cartilaginous airways that branch.",
				location: "From trachea into lungs",
				fact: "The right main bronchus is steeper."
			},
			{
				id: "alveoli",
				name: "Alveoli",
				function: "Site of gas exchange by diffusion.",
				structure: "Thin-walled air sacs with surfactant.",
				location: "Lung parenchyma",
				fact: "Respiratory membrane is extremely thin."
			},
			{
				id: "diaphragm",
				name: "Diaphragm",
				function: "Primary muscle of quiet inspiration.",
				structure: "Dome-shaped skeletal muscle.",
				location: "Floor of the thorax",
				fact: "Contraction increases thoracic volume."
			}
		],
		related: ["respiratory-system", "heart"],
		processes: ["cellular-respiration"],
		ncert: "Class 10 Life Processes; Class 11 Breathing and Exchange of Gases.",
		explain: lv("Lungs are spongy bags that fill with air. Oxygen goes into the blood; carbon dioxide comes out.", "Air travels trachea → bronchi → bronchioles → alveoli. Gases diffuse across the alveolar wall into capillaries.", "Fick’s law: rate of diffusion depends on surface area, thickness and partial-pressure gradient. Haemoglobin binds O2 cooperatively.", "Ventilation is tidal. Intrapleural pressure stays negative relative to atmosphere, keeping lungs inflated. Surfactant reduces alveolar surface tension.")
	},
	{
		id: "kidney",
		name: "Kidney",
		category: "organ",
		summary: "Bean-shaped organ that filters blood and forms urine.",
		function: "Osmoregulation, excretion of nitrogenous waste, and blood-pressure hormone (renin) roles.",
		structure: "Cortex, medulla (pyramids), pelvis; functional unit is the nephron.",
		facts: [
			"Each human kidney contains about a million nephrons.",
			"Urine is not just waste water — composition is tightly regulated.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "cortex",
				name: "Cortex",
				function: "Contains glomeruli; filtration begins here.",
				structure: "Outer renal tissue.",
				location: "Outer kidney",
				fact: "Cortical nephrons are the majority."
			},
			{
				id: "medulla",
				name: "Medulla",
				function: "Concentrates urine via the loop of Henle.",
				structure: "Pyramids of parallel tubules and vessels.",
				location: "Inner kidney",
				fact: "Osmotic gradient increases toward the papilla."
			},
			{
				id: "nephron",
				name: "Nephron",
				function: "Filtration, reabsorption, secretion.",
				structure: "Glomerulus + tubule + collecting duct connection.",
				location: "Cortex to medulla",
				fact: "Ultrafiltrate is modified into urine."
			},
			{
				id: "pelvis",
				name: "Renal Pelvis",
				function: "Collects urine toward the ureter.",
				structure: "Funnel of calyces.",
				location: "Medial kidney (hilum)",
				fact: "Leaves via the ureter."
			}
		],
		related: ["human-body"],
		processes: [],
		ncert: "Class 10 Life Processes; Class 11 Excretory Products and their Elimination.",
		explain: lv("Kidneys clean the blood and make urine. They keep the right amount of water and salts in the body.", "Blood is filtered in tiny knots (glomeruli). Useful things are taken back; wastes continue to the bladder.", "Ultrafiltration, selective reabsorption and tubular secretion. ADH increases water reabsorption in collecting ducts.", "Counter-current multiplier in the loop of Henle plus vasa recta creates a medullary osmotic gradient, allowing concentrated urine.")
	},
	{
		id: "digestive-system",
		name: "Digestive System",
		category: "system",
		summary: "The tubular system that ingests, digests, absorbs and egests food.",
		function: "Mechanical and chemical breakdown of food; absorption of nutrients.",
		structure: "Alimentary canal plus accessory glands (salivary, liver, pancreas).",
		facts: [
			"Most chemical digestion and absorption occur in the small intestine.",
			"The liver produces bile; the pancreas produces enzymes and bicarbonate.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "stomach",
				name: "Stomach",
				function: "Stores food; begins protein digestion.",
				structure: "Muscular sac with gastric glands.",
				location: "Upper abdomen",
				fact: "Gastric juice includes HCl and pepsinogen."
			},
			{
				id: "small-intestine",
				name: "Small Intestine",
				function: "Main site of digestion and absorption.",
				structure: "Duodenum, jejunum, ileum with villi.",
				location: "Abdomen",
				fact: "Villi and microvilli massively increase area."
			},
			{
				id: "liver",
				name: "Liver",
				function: "Produces bile; metabolic hub.",
				structure: "Largest internal organ; hepatocytes.",
				location: "Upper right abdomen",
				fact: "Bile emulsifies fats."
			},
			{
				id: "pancreas",
				name: "Pancreas",
				function: "Digestive enzymes and hormones (insulin, glucagon).",
				structure: "Exocrine acini + islets of Langerhans.",
				location: "Behind the stomach",
				fact: "Pancreatic juice is alkaline."
			},
			{
				id: "large-intestine",
				name: "Large Intestine",
				function: "Absorbs water and forms faeces.",
				structure: "Colon, rectum.",
				location: "Framing the small intestine",
				fact: "Hosts a large microbiome."
			}
		],
		related: ["human-body"],
		processes: [],
		ncert: "Class 10 Life Processes; Class 11 Digestion and Absorption.",
		explain: lv("The digestive system is a food tube. It breaks food into tiny bits the blood can carry to cells.", "Mouth, oesophagus, stomach, small intestine, large intestine. Liver and pancreas add juices that digest food.", "Peristalsis moves the bolus. Enzymes are specific: amylases (carbs), proteases (protein), lipases (fats).", "Brush-border enzymes complete digestion. Chylomicrons carry dietary lipids via lymph. Enteroendocrine hormones (gastrin, CCK, secretin) coordinate secretions.")
	},
	{
		id: "respiratory-system",
		name: "Respiratory System",
		category: "system",
		summary: "Airways and lungs that ventilate and exchange gases.",
		function: "Bring O2 in, expel CO2, help regulate blood pH.",
		structure: "Nose/mouth, pharynx, larynx, trachea, bronchi, lungs, respiratory muscles.",
		facts: [
			"Breathing is ventilation; respiration includes cellular energy release.",
			"CO2 is mainly carried as bicarbonate in plasma.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "airway",
				name: "Conducting Airways",
				function: "Filter, warm, moisten and conduct air.",
				structure: "Cartilage, smooth muscle, mucosa.",
				location: "Nose to terminal bronchioles",
				fact: "No gas exchange in the anatomical dead space."
			},
			{
				id: "lungs",
				name: "Lungs",
				function: "Gas exchange.",
				structure: "Elastic organs with alveoli.",
				location: "Thoracic cavity",
				fact: "Covered by pleura."
			},
			{
				id: "diaphragm",
				name: "Diaphragm",
				function: "Drives tidal breathing.",
				structure: "Skeletal muscle sheet.",
				location: "Thoracic floor",
				fact: "Phrenic nerves innervate it."
			}
		],
		related: ["lungs", "circulatory-system"],
		processes: ["cellular-respiration"],
		ncert: "Class 10 Life Processes; Class 11 Breathing and Exchange of Gases.",
		explain: lv("This system moves air in and out so blood can pick up oxygen and drop off carbon dioxide.", "Inhalation: chest expands, air flows in. Exhalation: chest relaxes, air flows out. Exchange happens in alveoli.", "Partial pressures drive O2 and CO2 diffusion. Chemoreceptors sense CO2/pH and adjust ventilation.", "Bohr effect: increased CO2/H+ shifts the O2–Hb curve right, unloading oxygen in active tissues. Central chemoreceptors are highly CO2-sensitive.")
	},
	{
		id: "circulatory-system",
		name: "Circulatory System",
		category: "system",
		summary: "Heart, blood and vessels that transport materials.",
		function: "Deliver O2, nutrients and hormones; remove wastes; immune cell traffic.",
		structure: "Closed double circuit of arteries, capillaries and veins driven by the heart.",
		facts: [
			"Arteries carry blood away from the heart; veins toward it.",
			"Capillaries are the exchange vessels.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "heart",
				name: "Heart",
				function: "Muscular pump.",
				structure: "Four chambers in humans.",
				location: "Mediastinum",
				fact: "Two pumps in series: pulmonary and systemic."
			},
			{
				id: "arteries",
				name: "Arteries",
				function: "High-pressure distribution.",
				structure: "Thick elastic/muscular walls.",
				location: "Throughout the body",
				fact: "Pulse is the arterial pressure wave."
			},
			{
				id: "veins",
				name: "Veins",
				function: "Return blood to the heart.",
				structure: "Thinner walls; valves in limbs.",
				location: "Throughout the body",
				fact: "Skeletal muscle pump helps venous return."
			},
			{
				id: "capillaries",
				name: "Capillaries",
				function: "Exchange of gases, nutrients, wastes.",
				structure: "Single endothelial layer.",
				location: "Beds in tissues",
				fact: "Blood flow here is slow — more time to exchange."
			}
		],
		related: [
			"heart",
			"lungs",
			"human-body"
		],
		processes: ["blood-circulation", "immune-response"],
		ncert: "Class 10 Life Processes; Class 11 Body Fluids and Circulation.",
		explain: lv("Blood travels in pipes. The heart pushes it so food, oxygen and messages reach every part.", "Oxygen-rich blood leaves the left heart in arteries. Oxygen-poor blood returns in veins to the right heart, then to the lungs.", "Closed circulation with a hepatic portal system. Lymph returns leaked plasma proteins.", "Poiseuille’s relationship: flow depends strongly on radius. Baroreflex and RAAS help maintain arterial pressure.")
	},
	{
		id: "chloroplast",
		name: "Chloroplast",
		category: "plant",
		summary: "The photosynthetic organelle of green plant cells.",
		function: "Convert light energy into chemical energy (sugars) and release O2.",
		structure: "Double membrane, thylakoid stacks (grana), stroma with Calvin-cycle enzymes and cpDNA.",
		facts: [
			"Chlorophyll a is the primary photosynthetic pigment.",
			"Oxygen gas comes from splitting water, not from CO2.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "thylakoid",
				name: "Thylakoid",
				function: "Light-dependent reactions; houses photosystems.",
				structure: "Flattened membrane sacs.",
				location: "Interior",
				fact: "Lumen is the inner thylakoid space."
			},
			{
				id: "granum",
				name: "Granum",
				function: "Stack of thylakoids increasing membrane area.",
				structure: "Pancake-like stack.",
				location: "Stroma",
				fact: "Connected by stroma lamellae."
			},
			{
				id: "stroma",
				name: "Stroma",
				function: "Calvin cycle (light-independent reactions).",
				structure: "Aqueous matrix with enzymes, DNA, ribosomes.",
				location: "Between inner membrane and thylakoids",
				fact: "CO2 is fixed here into sugars."
			}
		],
		related: ["plant-cell", "leaf"],
		processes: ["photosynthesis"],
		ncert: "Class 11 Photosynthesis in Higher Plants.",
		explain: lv("Chloroplasts are green solar panels. They catch sunlight and make food for the plant.", "Light reactions split water and make energy molecules. The Calvin cycle uses those to build glucose from CO2.", "Photosystem II then I in the Z-scheme. ATP and NADPH fuel carbon fixation by Rubisco.", "C3 vs C4 vs CAM are carbon-concentration strategies reducing photorespiration. Rubisco oxygenase activity rises with temperature and O2/CO2 ratio.")
	},
	{
		id: "flower",
		name: "Flower",
		category: "plant",
		summary: "The reproductive shoot of angiosperms.",
		function: "Sexual reproduction — produce seeds via pollination and fertilisation.",
		structure: "Whorls: calyx, corolla, androecium, gynoecium.",
		facts: [
			"Complete flowers have all four whorls.",
			"Double fertilisation is unique to angiosperms.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "petal",
				name: "Petal (Corolla)",
				function: "Attracts pollinators.",
				structure: "Often colourful, scented.",
				location: "Inner to sepals",
				fact: "Nectaries may lie at the base."
			},
			{
				id: "sepal",
				name: "Sepal (Calyx)",
				function: "Protects the bud.",
				structure: "Usually green leaf-like organs.",
				location: "Outermost whorl",
				fact: "Together with petals = perianth."
			},
			{
				id: "stamen",
				name: "Stamen",
				function: "Produces pollen (male gametophyte).",
				structure: "Anther + filament.",
				location: "Androecium",
				fact: "Pollen forms in anther locules."
			},
			{
				id: "carpel",
				name: "Carpel / Pistil",
				function: "Houses ovules; receives pollen.",
				structure: "Stigma, style, ovary.",
				location: "Centre of the flower",
				fact: "Ovary becomes fruit after fertilisation."
			}
		],
		related: ["plant-cell", "leaf"],
		processes: ["fertilization"],
		ncert: "Class 12 Sexual Reproduction in Flowering Plants.",
		explain: lv("A flower is the plant’s way of making seeds. Colourful parts invite insects; the middle makes seeds.", "Pollen from stamens lands on the stigma, grows a tube, and fertilises ovules in the ovary.", "Double fertilisation: one sperm + egg = zygote; the other + polar nuclei = endosperm (3n).", "ABC model of floral organ identity. Self-incompatibility systems prevent inbreeding in many species.")
	},
	{
		id: "leaf",
		name: "Leaf",
		category: "plant",
		summary: "The primary photosynthetic organ of most plants.",
		function: "Capture light, exchange gases, and in many species transpire water.",
		structure: "Epidermis with stomata, mesophyll (palisade and spongy), veins (xylem + phloem).",
		facts: [
			"Stomata open and close using guard cells.",
			"Most photosynthesis occurs in palisade mesophyll.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "epidermis",
				name: "Epidermis",
				function: "Protective layer; cuticle reduces water loss.",
				structure: "Tightly packed cells, often with waxy cuticle.",
				location: "Upper and lower surfaces",
				fact: "Usually lacks chloroplasts except guard cells."
			},
			{
				id: "palisade",
				name: "Palisade Mesophyll",
				function: "Main photosynthetic tissue.",
				structure: "Columnar chloroplast-rich cells.",
				location: "Upper leaf",
				fact: "Packed to intercept light."
			},
			{
				id: "spongy",
				name: "Spongy Mesophyll",
				function: "Gas circulation inside the leaf.",
				structure: "Loosely packed cells with air spaces.",
				location: "Lower leaf",
				fact: "Connects to stomatal pores."
			},
			{
				id: "stomata",
				name: "Stomata",
				function: "Pores for CO2 in and O2/water vapour out.",
				structure: "Guard-cell pair forming a pore.",
				location: "Mostly lower epidermis in many dicots",
				fact: "Close in drought to save water."
			},
			{
				id: "vein",
				name: "Vein",
				function: "Transport water (xylem) and sugars (phloem).",
				structure: "Vascular bundle.",
				location: "Throughout lamina",
				fact: "The midrib is the main vein."
			}
		],
		related: ["chloroplast", "root"],
		processes: ["photosynthesis"],
		ncert: "Class 9 Tissues; Class 10 Life Processes; Class 11 Photosynthesis, Transport in Plants.",
		explain: lv("Leaves are the plant’s solar kitchens. Tiny mouth-like stomata let gases in and out.", "Water arrives in xylem. CO2 enters stomata. Chloroplasts make sugar, which leaves in phloem.", "Transpiration pull helps xylem flow. Light, CO2 and water interact as limiting factors (Blackman).", "Farquhar model: photosynthesis limited by Rubisco or by RuBP regeneration. Stomatal conductance trades carbon gain against water loss.")
	},
	{
		id: "root",
		name: "Root",
		category: "plant",
		summary: "Anchoring organ specialised for absorption.",
		function: "Absorb water and minerals; anchor the plant; sometimes store food.",
		structure: "Root cap, meristem, epidermis with root hairs, cortex, endodermis, vascular cylinder.",
		facts: [
			"Root hairs greatly increase surface area.",
			"Casparian strip in the endodermis forces water through cell membranes.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "root-hair",
				name: "Root Hair",
				function: "Absorb water and minerals from soil.",
				structure: "Epidermal outgrowths.",
				location: "Maturation zone",
				fact: "Short-lived; constantly replaced."
			},
			{
				id: "cap",
				name: "Root Cap",
				function: "Protects the growing tip; senses gravity.",
				structure: "Parenchyma cells that slough off.",
				location: "Tip",
				fact: "Statoliths help gravitropism."
			},
			{
				id: "xylem",
				name: "Xylem",
				function: "Transports water and minerals upward.",
				structure: "Tracheary elements.",
				location: "Stele",
				fact: "Flow is one-way, largely passive."
			},
			{
				id: "phloem",
				name: "Phloem",
				function: "Transports sugars.",
				structure: "Sieve tubes and companion cells.",
				location: "Stele",
				fact: "Translocation can be bidirectional."
			}
		],
		related: ["leaf", "plant-cell"],
		processes: [],
		ncert: "Class 9 Tissues; Class 11 Morphology, Anatomy, Transport in Plants.",
		explain: lv("Roots hold the plant and drink water from the soil through tiny hairs.", "Water enters root hairs, crosses the cortex, and is loaded into xylem to travel to the leaves.", "Apoplast vs symplast pathways. Mineral uptake is often active (needs ATP).", "Casparian strip (suberin) of the endodermis is a checkpoint. Mycorrhizal fungi extend the absorptive network.")
	},
	{
		id: "human-body",
		name: "Human Body",
		category: "body",
		summary: "An integrated set of organ systems.",
		function: "Maintain homeostasis through coordinated systems.",
		structure: "Skeletal, muscular, nervous, circulatory, respiratory, digestive, urinary, endocrine, reproductive, integumentary.",
		facts: [
			"Homeostasis keeps internal conditions in a narrow range.",
			"Systems overlap — the pancreas is digestive and endocrine.",
			"Visualization simplified for educational purposes."
		],
		parts: [
			{
				id: "skeletal",
				name: "Skeletal System",
				function: "Support, protection, mineral storage, blood-cell formation.",
				structure: "Bones, cartilage, ligaments.",
				location: "Whole body",
				fact: "About 206 bones in the adult."
			},
			{
				id: "muscular",
				name: "Muscular System",
				function: "Movement, posture, heat.",
				structure: "Skeletal, cardiac and smooth muscle.",
				location: "Whole body",
				fact: "Skeletal muscle is voluntary and striated."
			},
			{
				id: "nervous",
				name: "Nervous System",
				function: "Rapid communication and control.",
				structure: "Brain, spinal cord, nerves, sense organs.",
				location: "Whole body",
				fact: "Uses electrical impulses and synapses."
			},
			{
				id: "circulatory",
				name: "Circulatory System",
				function: "Transport.",
				structure: "Heart, vessels, blood.",
				location: "Whole body",
				fact: "Closed double circulation in humans."
			},
			{
				id: "respiratory",
				name: "Respiratory System",
				function: "Gas exchange.",
				structure: "Airways and lungs.",
				location: "Thorax and head",
				fact: "Works closely with circulation."
			},
			{
				id: "digestive",
				name: "Digestive System",
				function: "Nutrition.",
				structure: "Canal and glands.",
				location: "Head and abdomen",
				fact: "Absorption mainly in the ileum/jejunum."
			},
			{
				id: "urinary",
				name: "Urinary System",
				function: "Excretion and water balance.",
				structure: "Kidneys, ureters, bladder, urethra.",
				location: "Abdomen and pelvis",
				fact: "Kidneys also help blood pressure."
			},
			{
				id: "endocrine",
				name: "Endocrine System",
				function: "Chemical coordination via hormones.",
				structure: "Glands without ducts.",
				location: "Dispersed",
				fact: "Slower but longer-lasting than nerves."
			},
			{
				id: "reproductive",
				name: "Reproductive System",
				function: "Produce gametes and enable fertilisation.",
				structure: "Gonads and accessory organs.",
				location: "Pelvis (and related glands)",
				fact: "Not required for individual survival."
			}
		],
		related: [
			"heart",
			"neuron",
			"lungs",
			"kidney"
		],
		processes: [
			"blood-circulation",
			"neural-signal",
			"muscle-contraction"
		],
		ncert: "Class 10 Life Processes, Control and Coordination; Class 11 Human Physiology unit.",
		explain: lv("Your body is a team of systems. Bones hold you up, muscles move you, blood delivers supplies, nerves send messages.", "Organ systems work together to keep a steady internal state called homeostasis — like a thermostat for life.", "Negative feedback loops dominate (e.g. blood glucose, temperature). Positive feedback is rarer (e.g. oxytocin in labour).", "Integration of neural and endocrine control, with hypothalamic–pituitary axes as master regulators of many hormones.")
	}
];
var TOPIC_BY_ID = Object.fromEntries(TOPICS.map((t) => [t.id, t]));
function getTopic(id) {
	if (id && TOPIC_BY_ID[id]) return TOPIC_BY_ID[id];
	return TOPIC_BY_ID["animal-cell"];
}
function getPart(topic, partId) {
	if (!partId) return null;
	return topic.parts.find((p) => p.id === partId) ?? null;
}
var CATEGORY_LABEL = {
	cell: "Cell biology",
	molecular: "Molecular",
	organ: "Organs",
	system: "Systems",
	plant: "Plant biology",
	body: "Human body"
};
var PROCESSES = [
	{
		id: "dna-replication",
		name: "DNA Replication",
		duration: 24,
		topic: "dna",
		summary: "Semi-conservative copying of the double helix before cell division.",
		note: "Visualization simplified for educational purposes. Fork geometry, primers and Okazaki fragments are stylised.",
		stages: [
			{
				id: "unwind",
				name: "Unwinding",
				start: 0,
				end: .16,
				summary: "Helicase unwinds the double helix at the origin.",
				detail: "Initiator proteins open the origin. Helicase (with topoisomerase relief) separates strands, forming a replication fork."
			},
			{
				id: "separate",
				name: "Strand separation",
				start: .16,
				end: .32,
				summary: "Hydrogen bonds break; SSB proteins keep strands apart.",
				detail: "Complementary bases are exposed as templates. Single-strand binding proteins prevent re-annealing."
			},
			{
				id: "primer",
				name: "Priming",
				start: .32,
				end: .48,
				summary: "Primase lays short RNA primers.",
				detail: "DNA polymerase cannot start a chain de novo; it needs a 3′-OH from an RNA primer."
			},
			{
				id: "polymerase",
				name: "Elongation",
				start: .48,
				end: .72,
				summary: "DNA polymerase adds complementary nucleotides.",
				detail: "Leading strand is continuous 5′→3′. Lagging strand is made as Okazaki fragments."
			},
			{
				id: "new-strands",
				name: "New strands form",
				start: .72,
				end: .88,
				summary: "Two daughter duplexes take shape.",
				detail: "DNA pol I (prokaryotes) or equivalent removes primers; ligase seals nicks."
			},
			{
				id: "complete",
				name: "Replication complete",
				start: .88,
				end: 1,
				summary: "Two identical double helices.",
				detail: "Each daughter DNA has one old strand and one new strand (semi-conservative)."
			}
		]
	},
	{
		id: "transcription",
		name: "Transcription",
		duration: 20,
		topic: "dna",
		summary: "Copying a gene into messenger RNA.",
		note: "Visualization simplified for educational purposes. Eukaryotic splicing is omitted unless noted.",
		stages: [
			{
				id: "init",
				name: "Initiation",
				start: 0,
				end: .22,
				summary: "RNA polymerase binds the promoter.",
				detail: "Transcription factors help RNA polymerase recognise the promoter (TATA box in many eukaryotes)."
			},
			{
				id: "open",
				name: "Open complex",
				start: .22,
				end: .4,
				summary: "The DNA bubble opens.",
				detail: "A short stretch of DNA unwinds so the template strand can be read."
			},
			{
				id: "elong",
				name: "Elongation",
				start: .4,
				end: .72,
				summary: "RNA nucleotides are added 5′→3′.",
				detail: "Uracil pairs with adenine. The RNA–DNA hybrid is short-lived."
			},
			{
				id: "term",
				name: "Termination",
				start: .72,
				end: .88,
				summary: "The transcript is released.",
				detail: "Terminator sequences or protein factors stop polymerase."
			},
			{
				id: "done",
				name: "mRNA ready",
				start: .88,
				end: 1,
				summary: "The RNA message leaves for translation.",
				detail: "In eukaryotes, capping, splicing and polyadenylation occur first."
			}
		]
	},
	{
		id: "translation",
		name: "Translation",
		duration: 22,
		topic: "ribosome",
		summary: "Ribosomes decode mRNA into a polypeptide.",
		note: "Visualization simplified for educational purposes.",
		stages: [
			{
				id: "init",
				name: "Initiation",
				start: 0,
				end: .2,
				summary: "Ribosome assembles on mRNA at the start codon.",
				detail: "AUG codes for methionine (formyl-Met in bacteria). Initiation factors and initiator tRNA join."
			},
			{
				id: "elong",
				name: "Elongation",
				start: .2,
				end: .55,
				summary: "tRNAs bring amino acids; peptide bonds form.",
				detail: "A site decoding, peptidyl transfer, then translocation. The chain grows N→C terminus."
			},
			{
				id: "term",
				name: "Termination",
				start: .55,
				end: .72,
				summary: "A stop codon ends the chain.",
				detail: "Release factors recognise UAA, UAG or UGA. The polypeptide is freed."
			},
			{
				id: "fold",
				name: "Folding",
				start: .72,
				end: 1,
				summary: "The chain folds into a functional shape.",
				detail: "Chaperones often assist. Some proteins need further modification."
			}
		]
	},
	{
		id: "mitosis",
		name: "Mitosis",
		duration: 28,
		topic: "animal-cell",
		summary: "Nuclear division that produces two identical nuclei.",
		note: "Visualization simplified for educational purposes. Chromosome count is schematic, not a karyotype.",
		stages: [
			{
				id: "interphase",
				name: "Interphase",
				start: 0,
				end: .16,
				summary: "Cell grows; DNA is replicated (S phase).",
				detail: "G1, S and G2 prepare the cell. Chromosomes are not yet condensed."
			},
			{
				id: "prophase",
				name: "Prophase",
				start: .16,
				end: .34,
				summary: "Chromosomes condense; spindle begins to form.",
				detail: "Nuclear envelope breaks down in open mitosis. Centrosomes move apart."
			},
			{
				id: "metaphase",
				name: "Metaphase",
				start: .34,
				end: .5,
				summary: "Chromosomes line up at the equator.",
				detail: "Kinetochores attach to microtubules from opposite poles. The checkpoint waits for all attachments."
			},
			{
				id: "anaphase",
				name: "Anaphase",
				start: .5,
				end: .68,
				summary: "Sister chromatids separate to opposite poles.",
				detail: "Cohesin is cleaved. Chromatids are now daughter chromosomes."
			},
			{
				id: "telophase",
				name: "Telophase",
				start: .68,
				end: .84,
				summary: "Nuclei reform around each set of chromosomes.",
				detail: "Envelope reassembles; chromosomes decondense."
			},
			{
				id: "cytokinesis",
				name: "Cytokinesis",
				start: .84,
				end: 1,
				summary: "Cytoplasm divides into two cells.",
				detail: "Animal cells use an actin–myosin contractile ring. Plant cells build a cell plate."
			}
		]
	},
	{
		id: "meiosis",
		name: "Meiosis",
		duration: 30,
		topic: "chromosome",
		summary: "Two divisions that produce haploid gametes and shuffle genes.",
		note: "Visualization simplified for educational purposes.",
		stages: [
			{
				id: "pro1",
				name: "Prophase I",
				start: 0,
				end: .22,
				summary: "Homologues pair and may recombine.",
				detail: "Synapsis and crossing over create chiasmata — a source of genetic variation."
			},
			{
				id: "meta1",
				name: "Metaphase I",
				start: .22,
				end: .38,
				summary: "Tetrads align; independent assortment.",
				detail: "Orientation of each pair is random, another source of variation."
			},
			{
				id: "ana1",
				name: "Anaphase I",
				start: .38,
				end: .52,
				summary: "Homologues separate; sisters stay together.",
				detail: "This is the reductional division (2n → n)."
			},
			{
				id: "telo1",
				name: "Telophase I",
				start: .52,
				end: .64,
				summary: "Two haploid cells form.",
				detail: "A brief interkinesis may follow; DNA is not replicated again."
			},
			{
				id: "meiosis2",
				name: "Meiosis II",
				start: .64,
				end: .86,
				summary: "Sister chromatids separate (equational).",
				detail: "Similar to mitosis but starting from haploid cells."
			},
			{
				id: "gametes",
				name: "Four haploid cells",
				start: .86,
				end: 1,
				summary: "Gametes (or spores) are produced.",
				detail: "In humans, sperm are four haploid cells; in oogenesis one ovum plus polar bodies is typical."
			}
		]
	},
	{
		id: "photosynthesis",
		name: "Photosynthesis",
		duration: 24,
		topic: "chloroplast",
		summary: "Light-driven synthesis of sugars from CO2 and water.",
		note: "Visualization simplified for educational purposes. The Z-scheme is stylised.",
		stages: [
			{
				id: "light",
				name: "Light absorption",
				start: 0,
				end: .2,
				summary: "Pigments capture photons.",
				detail: "Chlorophyll in photosystems becomes excited. Energy funnels to reaction centres."
			},
			{
				id: "split",
				name: "Water splitting",
				start: .2,
				end: .38,
				summary: "PSII splits H2O, releasing O2.",
				detail: "Electrons replace those lost by P680. Protons enter the thylakoid lumen."
			},
			{
				id: "etc",
				name: "Electron transport",
				start: .38,
				end: .58,
				summary: "Electrons flow; ATP and NADPH form.",
				detail: "The cytochrome b6f complex contributes to the proton gradient. PSI reduces NADP+."
			},
			{
				id: "calvin",
				name: "Calvin cycle",
				start: .58,
				end: .82,
				summary: "CO2 is fixed into carbohydrate.",
				detail: "Rubisco carboxylates RuBP. ATP and NADPH reduce the products to sugars."
			},
			{
				id: "product",
				name: "Glucose and oxygen",
				start: .82,
				end: 1,
				summary: "Sugars are stored or exported; O2 is released.",
				detail: "Overall: 6CO2 + 6H2O + light → C6H12O6 + 6O2 (simplified net)."
			}
		]
	},
	{
		id: "cellular-respiration",
		name: "Cellular Respiration",
		duration: 26,
		topic: "mitochondria",
		summary: "Oxidation of fuels to make ATP, with CO2 and H2O as products.",
		note: "Visualization simplified for educational purposes. ATP yields are approximate.",
		stages: [
			{
				id: "glyco",
				name: "Glycolysis",
				start: 0,
				end: .22,
				summary: "Glucose → two pyruvate in the cytosol.",
				detail: "Net 2 ATP and 2 NADH. Oxygen is not required for this stage."
			},
			{
				id: "pyruvate",
				name: "Pyruvate oxidation",
				start: .22,
				end: .4,
				summary: "Pyruvate becomes acetyl-CoA.",
				detail: "Occurs in the mitochondrial matrix in eukaryotes. CO2 is released."
			},
			{
				id: "krebs",
				name: "Krebs cycle",
				start: .4,
				end: .62,
				summary: "Acetyl-CoA is oxidised; coenzymes reduced.",
				detail: "Also called the citric acid cycle. More CO2, NADH and FADH2 are produced."
			},
			{
				id: "etc",
				name: "Electron transport",
				start: .62,
				end: .84,
				summary: "O2 is the terminal acceptor; protons are pumped.",
				detail: "Complexes I–IV. Oxygen is reduced to water."
			},
			{
				id: "atp",
				name: "ATP synthesis",
				start: .84,
				end: 1,
				summary: "ATP synthase uses the proton gradient.",
				detail: "Chemiosmosis. Aerobic respiration yields far more ATP than glycolysis alone."
			}
		]
	},
	{
		id: "blood-circulation",
		name: "Blood Circulation",
		duration: 20,
		topic: "heart",
		summary: "Double circuit of pulmonary and systemic flow.",
		note: "Visualization simplified for educational purposes.",
		stages: [
			{
				id: "ra",
				name: "Right atrium fills",
				start: 0,
				end: .16,
				summary: "Deoxygenated blood returns via venae cavae.",
				detail: "Systemic veins empty into the right atrium."
			},
			{
				id: "rv",
				name: "Right ventricle pumps",
				start: .16,
				end: .34,
				summary: "Blood is sent to the lungs.",
				detail: "Through the pulmonary valve into pulmonary arteries."
			},
			{
				id: "lungs",
				name: "Lungs oxygenate",
				start: .34,
				end: .52,
				summary: "Gas exchange in alveolar capillaries.",
				detail: "CO2 leaves, O2 binds haemoglobin."
			},
			{
				id: "la",
				name: "Left atrium fills",
				start: .52,
				end: .68,
				summary: "Oxygenated blood returns via pulmonary veins.",
				detail: "Enters the left atrium then left ventricle."
			},
			{
				id: "lv",
				name: "Left ventricle ejects",
				start: .68,
				end: .86,
				summary: "Aorta distributes blood to the body.",
				detail: "Highest pressure chamber of the heart."
			},
			{
				id: "body",
				name: "Systemic delivery",
				start: .86,
				end: 1,
				summary: "Tissues take O2; blood returns to the right heart.",
				detail: "The loop repeats with every cardiac cycle."
			}
		]
	},
	{
		id: "neural-signal",
		name: "Neural Signal Transmission",
		duration: 16,
		topic: "neuron",
		summary: "Action potential from dendrites to synaptic terminals.",
		note: "Visualization simplified for educational purposes.",
		stages: [
			{
				id: "stimulus",
				name: "Stimulus",
				start: 0,
				end: .14,
				summary: "Dendrites receive excitatory input.",
				detail: "Ligand-gated channels open; local depolarisation (EPSP) occurs."
			},
			{
				id: "hillock",
				name: "Threshold",
				start: .14,
				end: .3,
				summary: "Axon hillock reaches threshold.",
				detail: "If summed EPSPs exceed threshold, voltage-gated Na+ channels open."
			},
			{
				id: "propagate",
				name: "Propagation",
				start: .3,
				end: .62,
				summary: "The spike travels along the axon.",
				detail: "In myelinated axons, it jumps between nodes of Ranvier (saltatory conduction)."
			},
			{
				id: "terminal",
				name: "Terminal arrival",
				start: .62,
				end: .8,
				summary: "Depolarisation opens Ca2+ channels.",
				detail: "Calcium enters the bouton."
			},
			{
				id: "release",
				name: "Transmitter release",
				start: .8,
				end: 1,
				summary: "Vesicles fuse and transmitter crosses the cleft.",
				detail: "The next cell may be excited or inhibited depending on the receptor."
			}
		]
	},
	{
		id: "muscle-contraction",
		name: "Muscle Contraction",
		duration: 18,
		topic: "human-body",
		summary: "Sliding-filament contraction of skeletal muscle.",
		note: "Visualization simplified for educational purposes.",
		stages: [
			{
				id: "impulse",
				name: "Nerve impulse",
				start: 0,
				end: .18,
				summary: "A motor neuron fires at the neuromuscular junction.",
				detail: "Acetylcholine depolarises the motor end plate."
			},
			{
				id: "calcium",
				name: "Calcium release",
				start: .18,
				end: .36,
				summary: "T-tubules trigger SR to release Ca2+.",
				detail: "Ryanodine receptors open on the sarcoplasmic reticulum."
			},
			{
				id: "troponin",
				name: "Troponin–tropomyosin",
				start: .36,
				end: .52,
				summary: "Ca2+ binds troponin; binding sites open.",
				detail: "Tropomyosin shifts off actin’s myosin-binding sites."
			},
			{
				id: "bridge",
				name: "Cross-bridge cycling",
				start: .52,
				end: .78,
				summary: "Myosin pulls actin (power stroke).",
				detail: "ATP is required to detach myosin heads (rigor without ATP)."
			},
			{
				id: "relax",
				name: "Relaxation",
				start: .78,
				end: 1,
				summary: "Ca2+ is pumped back; filaments slide apart.",
				detail: "Acetylcholinesterase clears ACh. The fibre lengthens."
			}
		]
	},
	{
		id: "protein-folding",
		name: "Protein Folding",
		duration: 16,
		topic: "ribosome",
		summary: "A polypeptide finds a stable, functional 3D fold.",
		note: "Visualization simplified for educational purposes. Real folding landscapes are far more complex.",
		stages: [
			{
				id: "chain",
				name: "Nascent chain",
				start: 0,
				end: .22,
				summary: "Amino acids emerge from the ribosome.",
				detail: "Sequence (primary structure) is already determined."
			},
			{
				id: "secondary",
				name: "Secondary structure",
				start: .22,
				end: .48,
				summary: "Local helices and sheets form.",
				detail: "Hydrogen bonds along the backbone create α-helices and β-sheets."
			},
			{
				id: "tertiary",
				name: "Tertiary structure",
				start: .48,
				end: .78,
				summary: "The chain packs into a 3D domain.",
				detail: "Hydrophobic core, disulphides, ionic bonds and van der Waals contacts."
			},
			{
				id: "function",
				name: "Functional protein",
				start: .78,
				end: 1,
				summary: "The native fold can bind or catalyse.",
				detail: "Misfolding can lead to degradation or aggregation. Chaperones assist many proteins."
			}
		]
	},
	{
		id: "fertilization",
		name: "Fertilisation",
		duration: 20,
		topic: "flower",
		summary: "Fusion of gametes to form a zygote — shown as a general concept.",
		note: "Visualization simplified for educational purposes. Animal and plant details differ; this is a schematic concept, not a clinical model.",
		stages: [
			{
				id: "approach",
				name: "Approach",
				start: 0,
				end: .22,
				summary: "Gametes are brought together.",
				detail: "In animals, sperm swim toward the egg. In flowering plants, a pollen tube grows to the ovule."
			},
			{
				id: "contact",
				name: "Recognition",
				start: .22,
				end: .44,
				summary: "Species-specific recognition occurs.",
				detail: "Bindin (animals) or pollen–stigma interactions (plants) help prevent the wrong fusion."
			},
			{
				id: "fusion",
				name: "Membrane fusion",
				start: .44,
				end: .66,
				summary: "Haploid nuclei are delivered.",
				detail: "Blocks to polyspermy (fast and slow) operate in many animals."
			},
			{
				id: "zygote",
				name: "Zygote",
				start: .66,
				end: 1,
				summary: "A diploid cell is formed.",
				detail: "In angiosperms, double fertilisation also makes endosperm. Development then begins."
			}
		]
	},
	{
		id: "immune-response",
		name: "Immune Response",
		duration: 22,
		topic: "circulatory-system",
		summary: "Recognise, respond, remember — a schematic adaptive response.",
		note: "Visualization simplified for educational purposes. Not medical advice.",
		stages: [
			{
				id: "recognise",
				name: "Recognition",
				start: 0,
				end: .2,
				summary: "Innate sensors and lymphocytes detect antigen.",
				detail: "APCs process antigen and present peptides on MHC molecules."
			},
			{
				id: "activate",
				name: "Activation",
				start: .2,
				end: .42,
				summary: "Matching lymphocytes are activated.",
				detail: "Helper T cells provide signals; B cells can class-switch and affinity-mature."
			},
			{
				id: "expand",
				name: "Clonal expansion",
				start: .42,
				end: .62,
				summary: "Specific clones proliferate.",
				detail: "Clonal selection: only matching cells expand."
			},
			{
				id: "attack",
				name: "Effector phase",
				start: .62,
				end: .82,
				summary: "Antibodies and/or cytotoxic T cells act.",
				detail: "Neutralisation, opsonisation, killing of infected cells."
			},
			{
				id: "memory",
				name: "Memory",
				start: .82,
				end: 1,
				summary: "Memory cells remain.",
				detail: "A later exposure produces a faster, stronger secondary response — the principle of vaccination."
			}
		]
	}
];
var PROCESS_BY_ID = Object.fromEntries(PROCESSES.map((p) => [p.id, p]));
function getProcess(id) {
	if (id && PROCESS_BY_ID[id]) return PROCESS_BY_ID[id];
	return PROCESS_BY_ID["mitosis"];
}
function stageAt(process, t) {
	const x = Math.min(1, Math.max(0, t));
	return process.stages.find((s) => x >= s.start && x < s.end) ?? process.stages[process.stages.length - 1];
}
function levelText(topicId, level) {
	return getTopic(topicId).explain[level];
}
function localTutor(ctx, message) {
	const q = message.trim().toLowerCase();
	const topic = getTopic(ctx.topic || ctx.model);
	const part = getPart(topic, ctx.selected);
	const process = ctx.stage ? getProcess(ctx.model) : getProcess(topic.processes[0] ?? "mitosis");
	const stage = ctx.stage ? process.stages.find((s) => s.id === ctx.stage) ?? stageAt(process, 0) : null;
	if (!q) return intro(ctx, topic.name, part?.name ?? null, stage?.name ?? null);
	if (/quiz|question|exam|mcq|test me/.test(q)) return quizPrompt(topic, ctx.level);
	if (/next|what happens next|then what/.test(q)) return nextStep(ctx, topic, process);
	if (/why.*important|importance|why does this matter/.test(q)) return importance(topic, part, ctx.level);
	if (/class\s*9|explain like.*9|simple|eli5|easy/.test(q)) return `Class 9 view — ${topic.name}\n\n${topic.explain[9]}\n\n${part ? `Focus on ${part.name}: ${part.function}` : topic.facts[0]}`;
	if (/class\s*10/.test(q)) return `Class 10 view — ${topic.name}\n\n${topic.explain[10]}`;
	if (/class\s*11/.test(q)) return `Class 11 view — ${topic.name}\n\n${topic.explain[11]}\n\nNCERT: ${topic.ncert}`;
	if (/class\s*12|ncert/.test(q)) return `Class 12 / NCERT-level — ${topic.name}\n\n${topic.explain[12]}\n\n${topic.ncert}`;
	if (/what happens here|what's happening|what is happening|current stage/.test(q)) {
		if (stage) return `${stage.name}\n\n${stage.detail}\n\n${process.note}`;
		return `${topic.summary}\n\n${levelText(topic.id, ctx.level)}`;
	}
	const hit = matchTopic(q);
	if (hit) {
		const t = getTopic(hit);
		const p = t.parts.find((x) => q.includes(x.name.toLowerCase()) || q.includes(x.id.replace("-", " ")));
		if (p) return formatPart(t.name, p, ctx.level);
		return `${t.name}\n\n${t.explain[ctx.level]}\n\nFunction: ${t.function}\n\nStructure: ${t.structure}\n\n${t.facts[0]}`;
	}
	if (part && (q.includes(part.name.toLowerCase()) || /this structure|this organelle|this part|selected/.test(q))) return formatPart(topic.name, part, ctx.level);
	if (/hello|hi |hey |who are you|help/.test(q)) return intro(ctx, topic.name, part?.name ?? null, stage?.name ?? null);
	return `${topic.name}\n\n${topic.explain[ctx.level]}\n\n${part ? `You have ${part.name} selected: ${part.function}` : `Try selecting a labelled structure, or ask “Why is this important?”`}\n\n${topic.ncert}`;
}
function intro(ctx, topic, part, stage) {
	const bits = [`You are exploring ${topic} at Class ${ctx.level} level.`];
	if (part) bits.push(`Selected structure: ${part}.`);
	if (stage) bits.push(`Current 4D stage: ${stage}.`);
	bits.push("Ask me to explain, why it matters, what happens next, or to give you a quiz.");
	return `BIO-BOT ready.\n\n${bits.join(" ")}`;
}
function formatPart(topic, part, level) {
	return `${part.name} (${topic})\n\nFunction: ${part.function}\n\nStructure: ${part.structure}\n\nLocation: ${part.location}\n\nKey fact: ${part.fact}\n\n${level >= 11 ? "Use the Learn page for NCERT-linked exam phrasing." : "Remember the function in one sentence for your exam."}`;
}
function importance(topic, part, level) {
	if (part) return `${part.name} matters because: ${part.function}\n\nWithout it, the cell or organ cannot complete its job. ${part.fact}\n\n${level >= 11 ? topic.explain[11] : topic.explain[9]}`;
	return `Why ${topic.name} matters\n\n${topic.function}\n\n${topic.explain[level]}`;
}
function nextStep(ctx, topic, process) {
	if (ctx.stage) {
		const i = process.stages.findIndex((s) => s.id === ctx.stage);
		const n = process.stages[i + 1];
		if (n) return `Next: ${n.name}\n\n${n.detail}\n\nOpen 4D Simulator and press Play to watch this unfold.`;
		return `${process.name} is complete.\n\n${process.summary}\n\nTry a related process or take a quiz.`;
	}
	const pid = topic.processes[0];
	if (pid) {
		const p = getProcess(pid);
		return `A natural next step is the 4D process “${p.name}”.\n\nFirst stage: ${p.stages[0]?.name} — ${p.stages[0]?.summary}`;
	}
	return `Explore a related topic: ${topic.related.map((id) => getTopic(id).name).join(", ")}.`;
}
function quizPrompt(topic, level) {
	const q = {
		dna: "State Chargaff’s pairing rules and why they matter for replication.",
		"animal-cell": "Name three organelles and one function of each.",
		mitochondria: "Why are mitochondria called the powerhouse of the cell?",
		heart: "Why is the left ventricular wall thicker than the right?",
		neuron: "What is saltatory conduction?",
		"plant-cell": "How does the vacuole help a herbaceous plant stay upright?"
	}[topic.id] ?? `Write two key points about ${topic.name} at Class ${level} level.`;
	return `Exam-style prompt (${topic.name})\n\n${q}\n\nWhen you are ready, open Quizzes for auto-marked items, including 3D hotspot questions.`;
}
function matchTopic(q) {
	const keys = Object.keys(TOPIC_BY_ID);
	for (const id of keys) {
		const t = TOPIC_BY_ID[id];
		if (q.includes(t.name.toLowerCase()) || q.includes(id.replace(/-/g, " "))) return id;
	}
	for (const [k, v] of Object.entries({
		mito: "mitochondria",
		powerhouse: "mitochondria",
		helix: "dna",
		gene: "dna",
		"brain cell": "neuron",
		nerve: "neuron",
		pump: "heart",
		blood: "circulatory-system",
		breathe: "lungs",
		stoma: "leaf",
		chlorophyll: "chloroplast",
		sugar: "photosynthesis"
	})) if (q.includes(k)) return v;
	return null;
}
var SUGGESTED_PROMPTS = [
	"Explain this",
	"Why is this important?",
	"What happens next?",
	"Explain this like I am in Class 10.",
	"Explain this for Class 12.",
	"Give me a quiz",
	"Give me an exam question"
];
//#endregion
export { getPart as a, localTutor as c, TOPICS as i, stageAt as l, PROCESSES as n, getProcess as o, SUGGESTED_PROMPTS as r, getTopic as s, CATEGORY_LABEL as t };
