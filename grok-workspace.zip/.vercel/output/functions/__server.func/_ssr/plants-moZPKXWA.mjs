import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { s as useAppStore, t as AppShell } from "./app-shell-B4clKprH.mjs";
import { t as CanvasStage } from "./canvas-stage-CVhNXXzZ.mjs";
import { t as LabFrame } from "./lab-frame-Da2b-2HG.mjs";
import { t as BiologyModel } from "./model-registry-BrpWUkKC.mjs";
import { t as ProcessScene } from "./process-scene-CSudXVR9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/plants-moZPKXWA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PlantsPage() {
	const setTopic = useAppStore((s) => s.setTopic);
	const topic = useAppStore((s) => s.selectedTopic);
	const t = useAppStore((s) => s.progress);
	const id = [
		"plant-cell",
		"chloroplast",
		"flower",
		"leaf",
		"root"
	].includes(topic) ? topic : "leaf";
	(0, import_react.useEffect)(() => {
		if (![
			"plant-cell",
			"chloroplast",
			"flower",
			"leaf",
			"root"
		].includes(topic)) setTopic("leaf");
	}, [topic, setTopic]);
	const photo = id === "chloroplast";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		lab: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabFrame, {
			topicId: id,
			processId: photo ? "photosynthesis" : void 0,
			explore: [
				{
					id: "plant-cell",
					name: "Plant Cell"
				},
				{
					id: "chloroplast",
					name: "Chloroplast"
				},
				{
					id: "leaf",
					name: "Leaf"
				},
				{
					id: "root",
					name: "Root"
				},
				{
					id: "flower",
					name: "Flower"
				}
			],
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CanvasStage, { children: photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProcessScene, {
				processId: "photosynthesis",
				t
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BiologyModel, { topicId: id }) })
		})
	});
}
//#endregion
export { PlantsPage as component };
