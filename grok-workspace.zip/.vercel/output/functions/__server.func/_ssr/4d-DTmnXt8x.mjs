import { y as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { c as Route$13 } from "./router-CT1d0R-w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/4d-DTmnXt8x.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function Redirect4D() {
	const { process } = Route$13.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, {
		to: "/four-d",
		search: { process }
	});
};
//#endregion
export { SplitComponent as component };
