import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { c as useProgress, s as useAppStore } from "./app-shell-B4clKprH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bio-part-8i2nKLAN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function usePart(id) {
	const selectedPart = useAppStore((s) => s.selectedPart);
	const selectPart = useAppStore((s) => s.selectPart);
	const isolated = useAppStore((s) => s.isolatedPart);
	const exploded = useAppStore((s) => s.exploded);
	const transparency = useAppStore((s) => s.transparency);
	const topic = useAppStore((s) => s.selectedTopic);
	const markExplored = useProgress((s) => s.markExplored);
	const [hovered, setHovered] = (0, import_react.useState)(false);
	const selected = selectedPart === id;
	return {
		selected,
		hovered,
		dimmed: isolated !== null && isolated !== id,
		exploded,
		transparency,
		bind: {
			onClick: (e) => {
				e.stopPropagation();
				selectPart(id);
				markExplored(topic);
			},
			onPointerOver: (e) => {
				e.stopPropagation();
				setHovered(true);
			},
			onPointerOut: () => setHovered(false)
		},
		active: selected || hovered
	};
}
function partMaterial(opts) {
	const opacity = opts.dimmed ? .08 : opts.opacity ?? (opts.transparency ? .72 : .96);
	return {
		color: opts.color,
		emissive: opts.active ? "#3ee0c5" : opts.color,
		emissiveIntensity: opts.active ? .45 : .08,
		metalness: opts.metalness ?? .15,
		roughness: opts.roughness ?? .45,
		transparent: opacity < .98,
		opacity,
		depthWrite: opacity > .85
	};
}
//#endregion
export { usePart as n, partMaterial as t };
