import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { c as Vector3, f as require_jsx_runtime, o as CatmullRomCurve3, r as Html, s as Quaternion } from "../_libs/@react-three/drei+[...].mjs";
import { s as useAppStore } from "./app-shell-B4clKprH.mjs";
import { n as usePart, t as partMaterial } from "./bio-part-8i2nKLAN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dna-sHosS2ni.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAIR = [
	["A", "T"],
	["G", "C"],
	["T", "A"],
	["C", "G"],
	["A", "T"],
	["G", "C"],
	["A", "T"],
	["C", "G"],
	["T", "A"],
	["G", "C"],
	["A", "T"],
	["C", "G"],
	["G", "C"],
	["T", "A"]
];
var BASE_COLOR = {
	A: "#f07178",
	T: "#64b5f6",
	G: "#ffd166",
	C: "#06d6a0"
};
var BASE_ID = {
	A: "adenine",
	T: "thymine",
	G: "guanine",
	C: "cytosine"
};
function Nucleotide({ base, position, id, labels }) {
	const { active, dimmed, transparency, bind } = usePart(id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position,
		...bind,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.16,
				16,
				16
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: BASE_COLOR[base],
				active,
				dimmed,
				transparency,
				opacity: 1
			}) }),
			labels && active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Html, {
				distanceFactor: 8,
				center: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-surface px-2 py-0.5 font-mono text-[10px] text-accent shadow-panel",
					children: base
				})
			}) : null
		]
	});
}
function Bond({ from, to }) {
	const { bind } = usePart("base-pair");
	const mid = from.clone().lerp(to, .5);
	const len = from.distanceTo(to);
	const quat = new Quaternion().setFromUnitVectors(new Vector3(0, 1, 0), to.clone().sub(from).normalize());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: mid.toArray(),
		quaternion: quat,
		...bind,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
			.035,
			.035,
			Math.max(.05, len - .28),
			6
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			color: "#d7e3f0",
			transparent: true,
			opacity: .55
		})]
	});
}
function DNAModel({ replication = 0, transcription = 0, mutationAt = -1 }) {
	const labels = useAppStore((s) => s.labels);
	const { bind: backboneBind, active: bbActive, dimmed, transparency } = usePart("backbone");
	const strands = (0, import_react.useMemo)(() => {
		const ptsA = [];
		const ptsB = [];
		const n = PAIR.length;
		for (let i = 0; i < n; i++) {
			const t = i / (n - 1);
			const y = (t - .5) * 6.2;
			const a = i * .52;
			const unzip = replication > 0 ? smooth(Math.max(0, replication * 2 - Math.abs(t - .5) * 2)) : 0;
			const r = .95 + unzip * .55;
			const split = unzip * .85;
			ptsA.push(new Vector3(Math.cos(a) * r - split, y, Math.sin(a) * r));
			ptsB.push(new Vector3(Math.cos(a + Math.PI) * r + split, y, Math.sin(a + Math.PI) * r));
		}
		return {
			a: new CatmullRomCurve3(ptsA),
			b: new CatmullRomCurve3(ptsB),
			ptsA,
			ptsB
		};
	}, [replication]);
	const rna = (0, import_react.useMemo)(() => {
		if (transcription <= 0) return null;
		const pts = [];
		const count = Math.max(2, Math.floor(transcription * PAIR.length));
		for (let i = 0; i < count; i++) {
			const y = (i / (PAIR.length - 1) - .5) * 6.2;
			pts.push(new Vector3(1.7 + i * .02, y * .7, .2));
		}
		return new CatmullRomCurve3(pts);
	}, [transcription]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			...backboneBind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tubeGeometry", { args: [
				strands.a,
				64,
				.055,
				8,
				false
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#9fb0c4",
				active: bbActive,
				dimmed,
				transparency,
				metalness: .35,
				opacity: 1
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tubeGeometry", { args: [
			strands.b,
			64,
			.055,
			8,
			false
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
			color: "#7ee0c5",
			active: bbActive,
			dimmed,
			transparency,
			metalness: .35,
			opacity: 1
		}) })] }),
		PAIR.map((pair, i) => {
			const left = mutationAt === i && pair[0] === "C" ? "T" : pair[0];
			const a = strands.ptsA[i];
			const b = strands.ptsB[i];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bond, {
					from: a,
					to: b
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nucleotide, {
					base: left,
					position: a.toArray(),
					id: BASE_ID[left],
					labels
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nucleotide, {
					base: pair[1],
					position: b.toArray(),
					id: BASE_ID[pair[1]],
					labels
				})
			] }, i);
		}),
		replication > .45 ? PAIR.map((pair, i) => {
			const t = i / (PAIR.length - 1);
			if (Math.abs(t - .5) > replication * .55) return null;
			const a = strands.ptsA[i];
			const extra = new Vector3(a.x * 1.55, a.y, a.z * 1.55);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: extra.toArray(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.12,
					12,
					12
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: BASE_COLOR[pair[1]],
					emissive: BASE_COLOR[pair[1]],
					emissiveIntensity: .35
				})]
			}, `n${i}`);
		}) : null,
		rna ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tubeGeometry", { args: [
			rna,
			32,
			.04,
			6,
			false
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			color: "#e7c27a",
			emissive: "#e7c27a",
			emissiveIntensity: .3
		})] }) : null
	] });
}
function smooth(x) {
	const t = Math.min(1, Math.max(0, x));
	return t * t * (3 - 2 * t);
}
//#endregion
export { PAIR as n, DNAModel as t };
