import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { s as useAppStore, t as AppShell } from "./app-shell-B4clKprH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-nInXF4A4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SearchPage() {
	const setOpen = useAppStore((s) => s.setSearchOpen);
	(0, import_react.useEffect)(() => setOpen(true), [setOpen]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-xl px-4 py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl",
			children: "Search Biology"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-fg-muted",
			children: "The catalogue overlay is open. Query models, 4D processes, quizzes and BIO-BOT."
		})]
	}) });
}
//#endregion
export { SearchPage as component };
