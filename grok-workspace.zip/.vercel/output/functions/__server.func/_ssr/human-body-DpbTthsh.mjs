import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { s as useAppStore } from "./app-shell-B4clKprH.mjs";
import { n as usePart, t as partMaterial } from "./bio-part-8i2nKLAN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/human-body-DpbTthsh.js
var import_jsx_runtime = require_jsx_runtime();
function Bone({ position, radius, length, rotation }) {
	const { bind, active, dimmed } = usePart("skeletal");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position,
		rotation,
		...bind,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("capsuleGeometry", { args: [
			radius,
			length,
			4,
			8
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
			color: "#d7dce5",
			active,
			dimmed,
			opacity: .92
		}) })]
	});
}
function Skull() {
	const { bind, active, dimmed } = usePart("skeletal");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			0,
			1.85,
			0
		],
		...bind,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
			.38,
			16,
			12
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
			color: "#e8eef6",
			active,
			dimmed,
			opacity: .95
		}) })]
	});
}
function HumanBodyModel() {
	const systems = useAppStore((s) => s.bodySystems);
	const skin = usePart("skin");
	const muscular = usePart("muscular");
	const nervous = usePart("nervous");
	const circ = usePart("circulatory");
	const resp = usePart("respiratory");
	const dig = usePart("digestive");
	const uri = usePart("urinary");
	const endo = usePart("endocrine");
	const repro = usePart("reproductive");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			0,
			-.4,
			0
		],
		children: [
			systems.skin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.2,
					0
				],
				...skin.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("capsuleGeometry", { args: [
					.95,
					2.4,
					6,
					16
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
					color: "#e8c4b0",
					transparent: true,
					opacity: .18,
					roughness: .5
				})]
			}) : null,
			systems.skeletal ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skull, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bone, {
					position: [
						0,
						1.15,
						0
					],
					radius: .12,
					length: .7
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bone, {
					position: [
						0,
						.35,
						0
					],
					radius: .22,
					length: .9
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bone, {
					position: [
						-.55,
						.7,
						0
					],
					radius: .08,
					length: .9,
					rotation: [
						0,
						0,
						.7
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bone, {
					position: [
						.55,
						.7,
						0
					],
					radius: .08,
					length: .9,
					rotation: [
						0,
						0,
						-.7
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bone, {
					position: [
						-.22,
						-.85,
						0
					],
					radius: .1,
					length: 1.2
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bone, {
					position: [
						.22,
						-.85,
						0
					],
					radius: .1,
					length: 1.2
				})
			] }) : null,
			systems.muscular ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					-.42,
					.55,
					.12
				],
				rotation: [
					0,
					0,
					.5
				],
				...muscular.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("capsuleGeometry", { args: [
					.14,
					.7,
					4,
					8
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#c45c6a",
					active: muscular.active,
					dimmed: muscular.dimmed,
					opacity: .85
				}) })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					.42,
					.55,
					.12
				],
				rotation: [
					0,
					0,
					-.5
				],
				...muscular.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("capsuleGeometry", { args: [
					.14,
					.7,
					4,
					8
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#c45c6a",
					active: muscular.active,
					dimmed: muscular.dimmed,
					opacity: .85
				}) })]
			})] }) : null,
			systems.nervous ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					1.85,
					0
				],
				...nervous.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.28,
					12,
					12
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#e7c27a",
					emissive: "#e7c27a",
					emissiveIntensity: .25
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.6,
					.12
				],
				...nervous.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
					.05,
					.05,
					2.4,
					8
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#e7c27a" })]
			})] }) : null,
			systems.circulatory ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					.12,
					.85,
					.22
				],
				...circ.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.22,
					12,
					10
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#e8897a",
					emissive: "#e8897a",
					emissiveIntensity: .4
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.1,
					.18
				],
				...circ.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
					.04,
					.04,
					1.6,
					8
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#c45c6a" })]
			})] }) : null,
			systems.respiratory ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					-.18,
					.95,
					.2
				],
				scale: [
					.55,
					.8,
					.4
				],
				...resp.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.35,
					12,
					10
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#e8b4b8",
					active: resp.active,
					dimmed: resp.dimmed,
					opacity: .8
				}) })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					.22,
					.95,
					.2
				],
				scale: [
					.5,
					.75,
					.38
				],
				...resp.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.35,
					12,
					10
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#e8b4b8",
					active: resp.active,
					dimmed: resp.dimmed,
					opacity: .8
				}) })]
			})] }) : null,
			systems.digestive ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					.15,
					.22
				],
				...dig.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
					.28,
					.07,
					8,
					16
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#d4a574",
					active: dig.active,
					dimmed: dig.dimmed,
					opacity: .9
				}) })]
			}) : null,
			systems.urinary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					-.22,
					.35,
					.18
				],
				...uri.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.14,
					10,
					10
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#c45c6a" })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					.22,
					.35,
					.18
				],
				...uri.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.14,
					10,
					10
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { color: "#c45c6a" })]
			})] }) : null,
			systems.endocrine ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					1.45,
					.2
				],
				...endo.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.08,
					8,
					8
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					color: "#3ee0c5",
					emissive: "#3ee0c5",
					emissiveIntensity: .5
				})]
			}) : null,
			systems.reproductive ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					-.35,
					.2
				],
				...repro.bind,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.16,
					10,
					10
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#e7c27a",
					active: repro.active,
					dimmed: repro.dimmed,
					opacity: .85
				}) })]
			}) : null
		]
	});
}
//#endregion
export { HumanBodyModel as t };
