import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { n as Button, r as cn } from "./router-CT1d0R-w.mjs";
import { c as useProgress, s as useAppStore, t as AppShell } from "./app-shell-B4clKprH.mjs";
import { t as CanvasStage } from "./canvas-stage-CVhNXXzZ.mjs";
import { t as LabFrame } from "./lab-frame-Da2b-2HG.mjs";
import { t as HumanBodyModel } from "./human-body-DpbTthsh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/human-body-0aSe-Vav.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SYSTEMS = [
	["skeletal", "Skeletal"],
	["muscular", "Muscular"],
	["nervous", "Nervous"],
	["circulatory", "Circulatory"],
	["respiratory", "Respiratory"],
	["digestive", "Digestive"],
	["urinary", "Urinary"],
	["endocrine", "Endocrine"],
	["reproductive", "Reproductive"],
	["skin", "Skin"]
];
function BodyPage() {
	const setTopic = useAppStore((s) => s.setTopic);
	const systems = useAppStore((s) => s.bodySystems);
	const toggle = useAppStore((s) => s.toggleSystem);
	const mark = useProgress((s) => s.markExplored);
	(0, import_react.useEffect)(() => {
		setTopic("human-body");
		mark("human-body");
	}, [setTopic, mark]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		lab: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabFrame, {
			topicId: "human-body",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-full",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CanvasStage, {
					camera: [
						0,
						.4,
						7
					],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HumanBodyModel, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute left-3 top-16 z-10 max-w-[16rem] rounded-xl border border-border bg-surface/85 p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-[10px] tracking-[0.18em] text-fg-subtle",
							children: "SYSTEMS"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 space-y-1",
							children: SYSTEMS.map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => toggle(id),
								className: cn("flex h-10 w-full items-center justify-between rounded-md px-2 text-sm", systems[id] ? "bg-accent/15 text-accent" : "text-fg-muted"),
								children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-[10px]",
									children: systems[id] ? "ON" : "OFF"
								})]
							}) }, id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-2 w-full",
							variant: "secondary",
							size: "sm",
							onClick: () => {
								SYSTEMS.forEach(([id]) => {
									if (!systems[id]) toggle(id);
								});
							},
							children: "Show all"
						})
					]
				})]
			})
		})
	});
}
//#endregion
export { BodyPage as component };
