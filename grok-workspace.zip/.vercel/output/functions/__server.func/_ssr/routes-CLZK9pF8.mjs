import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useFrame, f as require_jsx_runtime, i as Canvas } from "../_libs/@react-three/drei+[...].mjs";
import { C as Bot, S as Box, _ as FlaskConical, g as GraduationCap, p as Layers, w as ArrowRight, x as Clock } from "../_libs/lucide-react.mjs";
import { n as Button } from "./router-CT1d0R-w.mjs";
import { i as TOPICS, n as PROCESSES } from "./knowledge-p4mtwHDd.mjs";
import { o as startDemo, t as AppShell } from "./app-shell-B4clKprH.mjs";
import { t as DNAModel } from "./dna-sHosS2ni.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CLZK9pF8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Drift() {
	const ref = (0, import_react.useRef)(null);
	useFrame((_, dt) => {
		if (!ref.current) return;
		const d = Math.min(dt, .1);
		ref.current.rotation.y += d * .18;
		ref.current.rotation.x = Math.sin(performance.now() / 4e3) * .12;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		ref,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DNAModel, {})
	});
}
function Dust({ count = 80 }) {
	const positions = (0, import_react.useMemo)(() => {
		const arr = new Float32Array(count * 3);
		for (let i = 0; i < count; i++) {
			arr[i * 3] = (Math.random() - .5) * 14;
			arr[i * 3 + 1] = (Math.random() - .5) * 10;
			arr[i * 3 + 2] = (Math.random() - .5) * 10;
		}
		return arr;
	}, [count]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("points", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("bufferGeometry", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("bufferAttribute", {
		attach: "attributes-position",
		args: [positions, 3]
	}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointsMaterial", {
		size: .035,
		color: "#3ee0c5",
		transparent: true,
		opacity: .55
	})] });
}
function HeroScene() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-full bg-bg-deep" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Canvas, {
		camera: {
			position: [
				0,
				.4,
				9
			],
			fov: 40
		},
		dpr: [1, 1.5],
		gl: {
			antialias: true,
			alpha: true
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("color", {
				attach: "background",
				args: ["#07090f"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", { intensity: .45 }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
				position: [
					4,
					6,
					6
				],
				intensity: 1.1,
				color: "#e8fff8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
				position: [
					-5,
					-2,
					-3
				],
				intensity: .4,
				color: "#7aa2ff"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drift, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dust, {})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative isolate min-h-[calc(100dvh-3.5rem)] overflow-hidden hud-grid",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 -z-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroScene, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 -z-10 bg-gradient-to-b from-bg/20 via-bg/55 to-bg" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col justify-center px-5 py-16 md:py-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs tracking-[0.32em] text-accent",
							children: "VIRTUAL BIOLOGY LABORATORY"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 max-w-3xl font-display text-5xl leading-[1.05] tracking-tight md:text-7xl",
							children: "BIOVERSE"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-xl font-display text-xl text-fg md:text-2xl",
							children: "Experience Biology Beyond the Textbook."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-xl text-base leading-relaxed text-fg-muted",
							children: "Explore cells, organs, DNA and biological processes in interactive 3D and 4D."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "lg",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/lab",
										search: { topic: "animal-cell" },
										children: ["Enter Bio Lab", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "lg",
									variant: "secondary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/lab",
										search: { topic: "dna" },
										children: "Explore 3D models"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "lg",
									variant: "outline",
									onClick: () => startDemo(),
									children: "Start demo"
								})
							]
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-[0.28em] text-fg-subtle",
					children: "WHY BIOVERSE?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-3xl md:text-4xl",
					children: "A lab, not a slideshow."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 grid gap-4 md:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
							icon: Box,
							title: "3D learning",
							copy: "Rotate, zoom and dissect structures. Click a mitochondrion and read what it actually does."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
							icon: Clock,
							title: "4D simulation",
							copy: "Scrub time through mitosis, replication, photosynthesis and more — spatial plus temporal."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
							icon: Bot,
							title: "AI biology tutor",
							copy: "BIO-BOT knows the model, stage and class level you are on. Works offline with a local tutor too."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
							icon: FlaskConical,
							title: "Virtual lab",
							copy: "Exploded views, isolation, labels and transparency — the tools of a teaching bench."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
							icon: GraduationCap,
							title: "Interactive quizzes",
							copy: "MCQ, true/false, sequence the process, and 3D hotspot questions."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
							icon: Layers,
							title: "Supported topics",
							copy: `${TOPICS.length} models and ${PROCESSES.length} time-based processes, from Class 9 to 12.`
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-border bg-surface/40 px-5 py-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-[0.28em] text-fg-subtle",
					children: "SUPPORTED TOPICS"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 flex flex-wrap gap-2",
					children: TOPICS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/lab",
						search: { topic: t.id },
						className: "rounded-full border border-border px-3 py-1.5 text-sm text-fg-muted hover:border-accent hover:text-accent",
						children: t.name
					}, t.id))
				})]
			})
		})
	] }) });
}
function Feature({ icon: Icon, title, copy }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-2xl border border-border bg-surface p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 text-accent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-3 font-display text-lg",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-fg-muted",
				children: copy
			})
		]
	});
}
//#endregion
export { Home as component };
