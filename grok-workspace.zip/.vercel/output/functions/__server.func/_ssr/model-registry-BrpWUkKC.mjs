import { f as require_jsx_runtime, r as Html } from "../_libs/@react-three/drei+[...].mjs";
import { s as getTopic } from "./knowledge-p4mtwHDd.mjs";
import { s as useAppStore } from "./app-shell-B4clKprH.mjs";
import { n as usePart, t as partMaterial } from "./bio-part-8i2nKLAN.mjs";
import { t as DNAModel } from "./dna-sHosS2ni.mjs";
import { a as FlowerModel, c as LeafModel, d as NeuronModel, f as NucleusModel, g as RootModel, h as RibosomeModel, i as DigestiveModel, l as LungsModel, m as RespiratoryModel, n as ChromosomeModel, o as HeartModel, p as RNAModel, r as CirculatoryModel, s as KidneyModel, t as ChloroplastModel, u as MitochondriaModel } from "./plants-nDbdV4PM.mjs";
import { t as HumanBodyModel } from "./human-body-DpbTthsh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/model-registry-BrpWUkKC.js
var import_jsx_runtime = require_jsx_runtime();
function Label({ text, show }) {
	if (!show) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Html, {
		distanceFactor: 10,
		center: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "rounded-full border border-border bg-surface/90 px-2 py-0.5 font-mono text-[10px] text-fg-muted whitespace-nowrap",
			children: text
		})
	});
}
function Bean({ id, position, explodedPos, rotation, color, label }) {
	const { active, dimmed, transparency, exploded, bind } = usePart(id);
	const labels = useAppStore((s) => s.labels);
	const pos = exploded ? explodedPos : position;
	const mat = partMaterial({
		color,
		active,
		dimmed,
		transparency,
		opacity: .95
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: pos,
		rotation,
		...bind,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.28,
				18,
				14
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...mat })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				scale: [
					1.55,
					.72,
					.78
				],
				position: [
					.08,
					0,
					0
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.28,
					18,
					14
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...mat })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
				.14,
				.018,
				8,
				16
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#5c2a24",
				roughness: .5
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				text: label,
				show: labels && (active || exploded)
			})
		]
	});
}
function AnimalCell() {
	const membrane = usePart("membrane");
	const cyto = usePart("cytoplasm");
	const nucleus = usePart("nucleus");
	const nucleolus = usePart("nucleolus");
	const er = usePart("er");
	const golgi = usePart("golgi");
	const lyso = usePart("lysosome");
	const centriole = usePart("centriole");
	const ribo = usePart("ribosome");
	const labels = useAppStore((s) => s.labels);
	const exploded = useAppStore((s) => s.exploded);
	const isolated = useAppStore((s) => s.isolatedPart);
	const hide = (id) => isolated !== null && isolated !== id && isolated !== "cytoplasm" && isolated !== "membrane";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			...membrane.bind,
			visible: !hide("membrane"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				2.55,
				48,
				32
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
				color: "#3d8f9e",
				transparent: true,
				opacity: membrane.transparency ? .14 : .32,
				roughness: .2,
				metalness: .05,
				transmission: membrane.transparency ? .6 : 0,
				thickness: .4,
				emissive: "#3ee0c5",
				emissiveIntensity: membrane.active ? .35 : .05
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			...cyto.bind,
			visible: !hide("cytoplasm"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				2.35,
				32,
				24
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
				color: "#16303a",
				transparent: true,
				opacity: .12,
				roughness: .8
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
			position: exploded ? [
				-.2,
				.15,
				.15
			] : [
				-.15,
				.2,
				.1
			],
			visible: !hide("nucleus"),
			...nucleus.bind,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.85,
					32,
					24
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#6b8cff",
					active: nucleus.active,
					dimmed: nucleus.dimmed,
					transparency: true,
					opacity: .55
				}) })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						.12,
						.1,
						.1
					],
					...nucleolus.bind,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
						.22,
						16,
						16
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
						color: "#c4b5fd",
						active: nucleolus.active,
						dimmed: nucleolus.dimmed,
						opacity: 1
					}) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					text: "Nucleus",
					show: labels && (nucleus.active || exploded)
				})
			]
		}),
		!hide("mitochondria") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bean, {
				id: "mitochondria",
				position: [
					1.15,
					.35,
					.45
				],
				explodedPos: [
					2.4,
					.8,
					.9
				],
				rotation: [
					.4,
					.6,
					.2
				],
				color: "#e8897a",
				label: "Mitochondrion"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bean, {
				id: "mitochondria",
				position: [
					-1.2,
					-.55,
					.7
				],
				explodedPos: [
					-2.5,
					-1.1,
					1.2
				],
				rotation: [
					.2,
					-.5,
					.4
				],
				color: "#e8897a",
				label: "Mitochondrion"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bean, {
				id: "mitochondria",
				position: [
					.35,
					-1.15,
					-.6
				],
				explodedPos: [
					.8,
					-2.2,
					-1.1
				],
				rotation: [
					-.4,
					.2,
					.1
				],
				color: "#e8897a",
				label: "Mitochondrion"
			})
		] }) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
			position: exploded ? [
				1.8,
				.9,
				-.4
			] : [
				.9,
				.55,
				-.55
			],
			visible: !hide("er"),
			...er.bind,
			children: [[
				0,
				1,
				2,
				3
			].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					i * .12 - .18,
					0
				],
				rotation: [
					.2,
					.4,
					.1
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
					.42,
					.045,
					8,
					24
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#d4a574",
					active: er.active,
					dimmed: er.dimmed,
					opacity: .9
				}) })]
			}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				text: "ER",
				show: labels && (er.active || exploded)
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
			position: exploded ? [
				-1.9,
				1.1,
				-.5
			] : [
				-.85,
				.85,
				-.7
			],
			visible: !hide("golgi"),
			...golgi.bind,
			children: [[
				0,
				1,
				2,
				3
			].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					i * .08,
					0
				],
				scale: [
					1 - i * .08,
					.35,
					.7
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.7,
					.07,
					.45
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#e7c27a",
					active: golgi.active,
					dimmed: golgi.dimmed,
					opacity: .92
				}) })]
			}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				text: "Golgi",
				show: labels && (golgi.active || exploded)
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: exploded ? [
				2.1,
				-.9,
				.2
			] : [
				1.35,
				-.55,
				.85
			],
			visible: !hide("lysosome"),
			...lyso.bind,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					.2,
					16,
					16
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#c084fc",
					active: lyso.active,
					dimmed: lyso.dimmed,
					opacity: .9
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					text: "Lysosome",
					show: labels && (lyso.active || exploded)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
			position: exploded ? [
				.2,
				-2.1,
				1.1
			] : [
				.55,
				-.85,
				1.15
			],
			visible: !hide("centriole"),
			...centriole.bind,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					rotation: [
						.6,
						.2,
						.1
					],
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
						.08,
						.08,
						.28,
						8
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
						color: "#94a3b8",
						active: centriole.active,
						dimmed: centriole.dimmed,
						opacity: 1
					}) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position: [
						.12,
						.05,
						0
					],
					rotation: [
						.1,
						.8,
						.6
					],
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cylinderGeometry", { args: [
						.08,
						.08,
						.28,
						8
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
						color: "#94a3b8",
						active: centriole.active,
						dimmed: centriole.dimmed,
						opacity: 1
					}) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					text: "Centriole",
					show: labels && (centriole.active || exploded)
				})
			]
		}),
		!hide("ribosome") ? [
			[
				.4,
				.9,
				1.1
			],
			[
				-1.4,
				.2,
				-.9
			],
			[
				1.5,
				-.2,
				-1
			],
			[
				-.6,
				-1.3,
				.3
			],
			[
				.1,
				1.4,
				-.8
			]
		].map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: p,
			...ribo.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.08,
				10,
				10
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#cbd5e1",
				active: ribo.active,
				dimmed: ribo.dimmed,
				opacity: 1
			}) })]
		}, i)) : null
	] });
}
function PlantCell() {
	const wall = usePart("wall");
	const membrane = usePart("membrane");
	const vacuole = usePart("vacuole");
	const nucleus = usePart("nucleus");
	const chloro = usePart("chloroplast");
	const golgi = usePart("golgi");
	const mito = usePart("mitochondria");
	const labels = useAppStore((s) => s.labels);
	const exploded = useAppStore((s) => s.exploded);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			...wall.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				4.4,
				3.2,
				2.6
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
				color: "#a3c585",
				transparent: true,
				opacity: .18,
				roughness: .35,
				emissive: "#7ee0a8",
				emissiveIntensity: wall.active ? .3 : .04
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			...membrane.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
				4.05,
				2.9,
				2.3
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
				color: "#3d8f9e",
				transparent: true,
				opacity: .1,
				roughness: .25
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: exploded ? [
				1.6,
				0,
				0
			] : [
				.35,
				-.15,
				0
			],
			...vacuole.bind,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					1.15,
					24,
					18
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
					color: "#67e8f9",
					transparent: true,
					opacity: .28,
					roughness: .15,
					emissive: "#67e8f9",
					emissiveIntensity: vacuole.active ? .25 : .06
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					text: "Vacuole",
					show: labels && (vacuole.active || exploded)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
			position: exploded ? [
				-1.8,
				.6,
				.4
			] : [
				-1.15,
				.55,
				.35
			],
			...nucleus.bind,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.55,
				24,
				18
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#6b8cff",
				active: nucleus.active,
				dimmed: nucleus.dimmed,
				opacity: .7
			}) })] })
		}),
		[
			[[
				-1.4,
				-.7,
				.55
			], [
				-2.4,
				-1.3,
				.9
			]],
			[[
				1.5,
				.85,
				.4
			], [
				2.5,
				1.4,
				.8
			]],
			[[
				.9,
				-.95,
				-.5
			], [
				1.8,
				-1.7,
				-.9
			]]
		].map((pair, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: exploded ? pair[1] : pair[0],
			rotation: [
				.4,
				.3 * i,
				.2
			],
			...chloro.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.32,
				16,
				12
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#3d9a5f",
				active: chloro.active,
				dimmed: chloro.dimmed,
				opacity: .95
			}) })]
		}, i)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
			position: exploded ? [
				-.2,
				1.6,
				-.6
			] : [
				-.4,
				.9,
				-.55
			],
			...golgi.bind,
			children: [
				0,
				1,
				2
			].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				position: [
					0,
					i * .07,
					0
				],
				scale: [
					1,
					.4,
					.7
				],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("boxGeometry", { args: [
					.55,
					.06,
					.35
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
					color: "#e7c27a",
					active: golgi.active,
					dimmed: golgi.dimmed,
					opacity: .9
				}) })]
			}, i))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			position: exploded ? [
				2.2,
				-1.1,
				.6
			] : [
				1.45,
				-.35,
				.7
			],
			rotation: [
				.2,
				.5,
				0
			],
			...mito.bind,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.22,
				14,
				12
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: "#e8897a",
				active: mito.active,
				dimmed: mito.dimmed,
				opacity: .95
			}) })]
		})
	] });
}
var PALETTE = [
	"#3ee0c5",
	"#7ee0a8",
	"#6b8cff",
	"#e7c27a",
	"#e8897a",
	"#93a0b4"
];
function GenericModel({ topicId }) {
	const topic = getTopic(topicId);
	const labels = useAppStore((s) => s.labels);
	const exploded = useAppStore((s) => s.exploded);
	const core = usePart(topic.parts[0]?.id ?? topic.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		...core.bind,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("icosahedronGeometry", { args: [.85, 1] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
			color: "#3ee0c5",
			active: core.active,
			dimmed: core.dimmed,
			opacity: .9
		}) })]
	}), topic.parts.map((part, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitPart, {
		id: part.id,
		name: part.name,
		index: i,
		total: topic.parts.length,
		exploded,
		labels
	}, part.id))] });
}
function OrbitPart({ id, name, index, total, exploded, labels }) {
	const { bind, active, dimmed } = usePart(id);
	const a = index / Math.max(1, total) * Math.PI * 2;
	const r = exploded ? 2.4 : 1.6;
	const y = Math.sin(index * 1.3) * (exploded ? 1.1 : .45);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			Math.cos(a) * r,
			y,
			Math.sin(a) * r
		],
		...bind,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				.22,
				14,
				12
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", { ...partMaterial({
				color: PALETTE[index % PALETTE.length],
				active,
				dimmed,
				opacity: .95
			}) }),
			labels && (active || exploded) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Html, {
				center: true,
				distanceFactor: 10,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full border border-border bg-surface px-2 py-0.5 font-mono text-[10px] text-fg-muted whitespace-nowrap",
					children: name
				})
			}) : null
		]
	});
}
function BiologyModel({ topicId }) {
	const compare = useAppStore((s) => s.compare);
	switch (topicId) {
		case "dna": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DNAModel, {});
		case "rna": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RNAModel, {});
		case "animal-cell": return compare ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
			position: [
				-2.4,
				0,
				0
			],
			scale: .72,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimalCell, {})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
			position: [
				2.4,
				0,
				0
			],
			scale: .72,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlantCell, {})
		})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimalCell, {});
		case "plant-cell": return compare ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
			position: [
				-2.4,
				0,
				0
			],
			scale: .72,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimalCell, {})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
			position: [
				2.4,
				0,
				0
			],
			scale: .72,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlantCell, {})
		})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlantCell, {});
		case "heart": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeartModel, {});
		case "lungs": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LungsModel, {});
		case "kidney": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KidneyModel, {});
		case "digestive-system": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DigestiveModel, {});
		case "respiratory-system": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RespiratoryModel, {});
		case "circulatory-system": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirculatoryModel, {});
		case "nucleus": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NucleusModel, {});
		case "mitochondria": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MitochondriaModel, {});
		case "ribosome": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RibosomeModel, {});
		case "chromosome": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChromosomeModel, {});
		case "neuron": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeuronModel, {});
		case "human-body": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HumanBodyModel, {});
		case "chloroplast": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChloroplastModel, {});
		case "flower": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowerModel, {});
		case "leaf": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeafModel, {});
		case "root": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RootModel, {});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GenericModel, { topicId });
	}
}
//#endregion
export { BiologyModel as t };
