import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { f as require_jsx_runtime, i as Canvas, n as OrbitControls, t as ContactShadows } from "../_libs/@react-three/drei+[...].mjs";
import { s as useAppStore } from "./app-shell-B4clKprH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/canvas-stage-CVhNXXzZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SceneErrorBoundary = class extends import_react.Component {
	state = { err: null };
	static getDerivedStateFromError(error) {
		return { err: error instanceof Error ? error.message : "Scene failed" };
	}
	render() {
		if (this.state.err) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("icosahedronGeometry", { args: [1.2, 1] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
			color: "#3ee0c5",
			wireframe: true
		})] });
		return this.props.children;
	}
};
function Platform() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		position: [
			0,
			-2.85,
			0
		],
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			receiveShadow: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circleGeometry", { args: [3.6, 48] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#0c1219",
				metalness: .25,
				roughness: .7
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			rotation: [
				-Math.PI / 2,
				0,
				0
			],
			position: [
				0,
				.01,
				0
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
				3.45,
				3.62,
				64
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
				color: "#3ee0c5",
				transparent: true,
				opacity: .28
			})]
		})]
	});
}
function CanvasStage({ children, camera = [
	0,
	.8,
	8
], autoRotate, className }) {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const quality = useAppStore((s) => s.quality);
	const reduced = useAppStore((s) => s.reducedMotion);
	const playing = useAppStore((s) => s.playing);
	const controls = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => setMounted(true), []);
	(0, import_react.useEffect)(() => {
		const onReset = () => {
			controls.current?.reset();
		};
		window.addEventListener("bioverse-reset-camera", onReset);
		return () => window.removeEventListener("bioverse-reset-camera", onReset);
	}, []);
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `relative grid place-items-center bg-bg-deep ${className ?? "h-full w-full"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-xs tracking-[0.25em] text-fg-subtle",
			children: "INITIALISING VIEWPORT"
		})
	});
	const dpr = quality === "high" ? [1, 2] : quality === "medium" ? [1, 1.5] : 1;
	const rotate = Boolean(autoRotate) && !reduced && !playing;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `relative h-full w-full touch-none ${className ?? ""}`,
		style: { touchAction: "none" },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Canvas, {
			dpr,
			shadows: quality === "high",
			gl: {
				antialias: quality !== "low",
				alpha: true,
				powerPreference: "high-performance"
			},
			camera: {
				position: camera,
				fov: 42,
				near: .1,
				far: 80
			},
			frameloop: playing || rotate ? "always" : "demand",
			performance: { min: .4 },
			onPointerMissed: () => useAppStore.getState().selectPart(null),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("color", {
					attach: "background",
					args: ["#07090f"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("fog", {
					attach: "fog",
					args: [
						"#07090f",
						12,
						28
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", { intensity: .42 }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
					position: [
						6,
						8,
						6
					],
					intensity: 1.15,
					color: "#d7fff6"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
					position: [
						-7,
						-2,
						-4
					],
					intensity: .45,
					color: "#7aa2ff"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("spotLight", {
					position: [
						0,
						10,
						2
					],
					intensity: .55,
					angle: .5,
					penumbra: .8,
					color: "#3ee0c5"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitControls, {
					ref: controls,
					makeDefault: true,
					enableDamping: true,
					dampingFactor: .08,
					autoRotate: rotate,
					autoRotateSpeed: .6,
					minDistance: 3,
					maxDistance: 18,
					maxPolarAngle: Math.PI * .92
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Platform, {}),
				quality !== "low" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactShadows, {
					position: [
						0,
						-2.84,
						0
					],
					opacity: .35,
					scale: 10,
					blur: 2.4,
					far: 6
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
					fallback: null,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SceneErrorBoundary, { children })
				})
			]
		})
	});
}
function resetCamera() {
	window.dispatchEvent(new Event("bioverse-reset-camera"));
}
//#endregion
export { resetCamera as n, CanvasStage as t };
