import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { n as Button } from "./router-CT1d0R-w.mjs";
import { r as Badge, s as useAppStore, t as AppShell } from "./app-shell-B4clKprH.mjs";
import { t as CanvasStage } from "./canvas-stage-CVhNXXzZ.mjs";
import { t as LabFrame } from "./lab-frame-Da2b-2HG.mjs";
import { n as PAIR, t as DNAModel } from "./dna-sHosS2ni.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dna-BAm_x2yV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DNAPage() {
	const setTopic = useAppStore((s) => s.setTopic);
	const [mode, setMode] = (0, import_react.useState)("intact");
	const [mutation, setMutation] = (0, import_react.useState)(false);
	const progress = useAppStore((s) => s.progress);
	const playing = useAppStore((s) => s.playing);
	(0, import_react.useEffect)(() => setTopic("dna"), [setTopic]);
	const seq = PAIR.map((p) => p[0]).join("");
	const mutSeq = mutation ? seq.slice(0, 3) + "T" + seq.slice(4) : seq;
	const t = mode === "intact" ? 0 : playing || progress > 0 ? progress : .65;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		lab: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabFrame, {
			topicId: "dna",
			processId: mode === "intact" ? void 0 : mode === "replication" ? "dna-replication" : "transcription",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-full",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CanvasStage, {
					autoRotate: mode === "intact",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DNAModel, {
						replication: mode === "replication" ? t : 0,
						transcription: mode === "transcription" ? t : 0,
						mutationAt: mutation ? 3 : -1
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto absolute left-3 top-16 z-10 flex max-w-[min(100%-1.5rem,20rem)] flex-col gap-2 rounded-xl border border-border bg-surface/85 p-3 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono tracking-[0.18em] text-fg-subtle",
							children: "DNA EXPLORER"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: mode === "intact" ? "default" : "secondary",
									onClick: () => setMode("intact"),
									children: "Helix"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: mode === "replication" ? "default" : "secondary",
									onClick: () => setMode("replication"),
									children: "Replication"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: mode === "transcription" ? "default" : "secondary",
									onClick: () => setMode("transcription"),
									children: "Transcription"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-fg",
							children: ["Normal ", seq.slice(0, 6)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: mutation ? "default" : "outline",
							onClick: () => setMutation((v) => !v),
							children: mutation ? "Clear mutation" : "Demonstrate mutation"
						}),
						mutation ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-fg-muted",
							children: [
								"Substitution at base 4: ",
								seq.slice(0, 6),
								" → ",
								mutSeq.slice(0, 6),
								". A single-letter change in the template. Educational only — no clinical interpretation."
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-fg-muted",
							children: "Tap A, T, G or C on the helix. Complementary pairing: A–T, G–C."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "muted",
							children: "Visualization simplified"
						})
					]
				})]
			})
		})
	});
}
//#endregion
export { DNAPage as component };
