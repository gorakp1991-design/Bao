import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { a as TutorBody, t as AppShell } from "./app-shell-B4clKprH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tutor-Dx2ryYpD.js
var import_jsx_runtime = require_jsx_runtime();
function TutorPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto h-[calc(100dvh-8rem)] max-w-2xl overflow-hidden rounded-2xl border border-border bg-surface md:mt-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TutorBody, {})
	}) });
}
//#endregion
export { TutorPage as component };
