import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { n as Button } from "./router-CT1d0R-w.mjs";
import { i as TOPICS, n as PROCESSES } from "./knowledge-p4mtwHDd.mjs";
import { c as useProgress, n as BADGE_META, r as Badge, t as AppShell } from "./app-shell-B4clKprH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-BTt8VKT7.js
var import_jsx_runtime = require_jsx_runtime();
function DashPage() {
	const explored = useProgress((s) => s.explored);
	const sims = useProgress((s) => s.simulations);
	const quizzes = useProgress((s) => s.quizzes);
	const badges = useProgress((s) => s.badges);
	const recent = useProgress((s) => s.recent);
	const quizAvg = quizzes.length === 0 ? 0 : Math.round(quizzes.reduce((a, q) => a + q.score / Math.max(1, q.total), 0) / quizzes.length * 100);
	const weak = weakTopics(quizzes);
	const recommended = TOPICS.filter((t) => !explored.includes(t.id)).slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-5xl px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-[0.22em] text-accent",
				children: "LEARNER DASHBOARD"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl",
				children: "Progress"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Topics completed",
						value: `${explored.length}/${TOPICS.length}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "3D models explored",
						value: String(explored.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "4D simulations",
						value: `${sims.length}/${PROCESSES.length}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Quiz average",
						value: `${quizAvg}%`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Badges"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: Object.keys(BADGE_META).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `rounded-full border px-3 py-1 text-xs ${badges.includes(id) ? "border-accent text-accent" : "border-border text-fg-subtle"}`,
						title: BADGE_META[id].hint,
						children: BADGE_META[id].name
					}, id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 grid gap-6 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Recent"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 space-y-2",
					children: [recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-sm text-fg-muted",
						children: "Explore a model to begin."
					}) : null, recent.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/lab",
						search: { topic: id },
						className: "text-sm text-accent hover:underline",
						children: TOPICS.find((t) => t.id === id)?.name ?? id
					}) }, id))]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Recommended"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: recommended.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "text-sm text-fg-muted",
						children: [
							t.name,
							" — ",
							t.summary
						]
					}, t.id))
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Weak areas"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-fg-muted",
					children: weak.length ? weak.join(", ") : "No quiz misses yet — take an assessment after a lab session."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10 rounded-2xl border border-border bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Coming soon"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-fg-muted",
						children: "Teacher dashboard, classroom mode, assignments, live quiz, AR/VR, 3D model upload, and teacher-created simulations are designed into the architecture but not enabled in this build."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [
							"Teacher dashboard",
							"Classroom mode",
							"Assignments",
							"Live quiz",
							"AR mode",
							"VR mode",
							"Model upload"
						].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "muted",
							children: x
						}, x))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						variant: "secondary",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/ar",
							children: "AR status"
						})
					})
				]
			})
		]
	}) });
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-[10px] tracking-[0.18em] text-fg-subtle",
			children: label.toUpperCase()
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 font-display text-3xl tabular-nums",
			children: value
		})]
	});
}
function weakTopics(quizzes) {
	const map = /* @__PURE__ */ new Map();
	for (const q of quizzes) {
		const cur = map.get(q.topic) ?? {
			s: 0,
			t: 0
		};
		cur.s += q.score;
		cur.t += q.total;
		map.set(q.topic, cur);
	}
	return [...map.entries()].filter(([, v]) => v.t > 0 && v.s / v.t < .6).map(([k]) => k);
}
//#endregion
export { DashPage as component };
