import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { o as Route$6 } from "./router-CT1d0R-w.mjs";
import { s as getTopic } from "./knowledge-p4mtwHDd.mjs";
import { c as useProgress, s as useAppStore, t as AppShell } from "./app-shell-B4clKprH.mjs";
import { t as CanvasStage } from "./canvas-stage-CVhNXXzZ.mjs";
import { t as LabFrame } from "./lab-frame-Da2b-2HG.mjs";
import { t as BiologyModel } from "./model-registry-BrpWUkKC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lab-CLegkadD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LabPage() {
	const { topic } = Route$6.useSearch();
	const selected = useAppStore((s) => s.selectedTopic);
	const setTopic = useAppStore((s) => s.setTopic);
	const mark = useProgress((s) => s.markExplored);
	const id = topic ?? selected ?? "animal-cell";
	(0, import_react.useEffect)(() => {
		setTopic(id);
		mark(id);
	}, [
		id,
		setTopic,
		mark
	]);
	const t = getTopic(id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		lab: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabFrame, {
			topicId: t.id,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CanvasStage, {
				autoRotate: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BiologyModel, { topicId: t.id })
			})
		})
	});
}
//#endregion
export { LabPage as component };
