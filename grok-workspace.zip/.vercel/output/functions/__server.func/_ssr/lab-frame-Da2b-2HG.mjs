import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { T as Aperture, b as EyeOff, c as Rewind, d as Maximize, f as List, l as Play, m as Info, o as Scan, p as Layers, r as SquareSplitHorizontal, s as RotateCcw, u as Pause, v as FastForward, y as Eye } from "../_libs/lucide-react.mjs";
import { n as Button, r as cn } from "./router-CT1d0R-w.mjs";
import { a as getPart, i as TOPICS, l as stageAt, o as getProcess, s as getTopic, t as CATEGORY_LABEL } from "./knowledge-p4mtwHDd.mjs";
import { c as useProgress, r as Badge, s as useAppStore } from "./app-shell-B4clKprH.mjs";
import { n as resetCamera } from "./canvas-stage-CVhNXXzZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lab-frame-Da2b-2HG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function InfoPanel({ topicId }) {
	const topic = getTopic(topicId);
	const selected = useAppStore((s) => s.selectedPart);
	const level = useAppStore((s) => s.classLevel);
	const part = getPart(topic, selected);
	const setTutorOpen = useAppStore((s) => s.setTutorOpen);
	const title = part?.name ?? topic.name;
	const fn = part?.function ?? topic.function;
	const structure = part?.structure ?? topic.structure;
	const fact = part?.fact ?? topic.facts[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col gap-4 overflow-y-auto p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[10px] tracking-[0.22em] text-fg-subtle",
					children: "SELECTED OBJECT"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 font-display text-xl text-fg",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "accent",
						children: part ? "Structure" : "Model"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: ["Class ", level] })]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				k: "Function",
				v: fn
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				k: "Structure",
				v: structure
			}),
			part ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				k: "Location",
				v: part.location
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				k: "Key fact",
				v: fact ?? ""
			}),
			!part ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-fg-muted",
				children: topic.explain[level]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] leading-relaxed text-fg-subtle",
				children: topic.ncert
			}),
			topic.facts[2] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] italic text-fg-subtle",
				children: topic.facts[2]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-auto flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setTutorOpen(true),
					children: "Ask BIO-BOT"
				}), topic.processes[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/four-d",
						search: { process: topic.processes[0] },
						children: "Open 4D process"
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/learn",
						children: "Learn more"
					})
				})]
			})
		]
	});
}
function Section({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-mono text-[10px] tracking-[0.18em] text-accent",
		children: k.toUpperCase()
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-1 text-sm leading-relaxed text-fg-muted",
		children: v
	})] });
}
function ViewerToolbar() {
	const labels = useAppStore((s) => s.labels);
	const transparency = useAppStore((s) => s.transparency);
	const exploded = useAppStore((s) => s.exploded);
	const isolated = useAppStore((s) => s.isolatedPart);
	const selected = useAppStore((s) => s.selectedPart);
	const compare = useAppStore((s) => s.compare);
	const setLabels = useAppStore((s) => s.setLabels);
	const setTransparency = useAppStore((s) => s.setTransparency);
	const setExploded = useAppStore((s) => s.setExploded);
	const setIsolated = useAppStore((s) => s.setIsolated);
	const setCompare = useAppStore((s) => s.setCompare);
	const resetView = useAppStore((s) => s.resetView);
	const fullscreen = () => {
		const el = document.getElementById("bio-viewport");
		if (!el) return;
		if (document.fullscreenElement) document.exitFullscreen();
		else el.requestFullscreen();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-auto flex flex-wrap gap-1 rounded-xl border border-border bg-surface/80 p-1 backdrop-blur-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
				icon: RotateCcw,
				label: "Reset camera",
				onClick: () => {
					resetCamera();
					resetView();
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
				icon: labels ? Eye : EyeOff,
				label: "Toggle labels",
				onClick: () => setLabels(!labels),
				active: labels
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
				icon: Aperture,
				label: "Transparency",
				onClick: () => setTransparency(!transparency),
				active: transparency
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
				icon: Layers,
				label: "Exploded view",
				onClick: () => setExploded(!exploded),
				active: exploded
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
				icon: Scan,
				label: "Isolate selection",
				onClick: () => setIsolated(isolated ? null : selected),
				active: Boolean(isolated)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
				icon: SquareSplitHorizontal,
				label: "Compare",
				onClick: () => setCompare(!compare),
				active: compare
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
				icon: Maximize,
				label: "Fullscreen",
				onClick: fullscreen
			})
		]
	});
}
function Tool({ icon: Icon, label, onClick, active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		size: "icon",
		variant: "ghost",
		"aria-label": label,
		title: label,
		onClick,
		className: cn("size-10", active && "bg-accent/15 text-accent"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
	});
}
function useIsMobile() {
	const [mobile, setMobile] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(max-width: 900px)");
		const apply = () => setMobile(mq.matches);
		apply();
		mq.addEventListener("change", apply);
		return () => mq.removeEventListener("change", apply);
	}, []);
	return mobile;
}
function usePlayback(duration) {
	const playing = useAppStore((s) => s.playing);
	const speed = useAppStore((s) => s.speed);
	(0, import_react.useEffect)(() => {
		if (!playing) return;
		let raf = 0;
		let last = performance.now();
		const loop = (now) => {
			const dt = Math.min((now - last) / 1e3, .1);
			last = now;
			const s = useAppStore.getState();
			const next = s.progress + dt * s.speed / Math.max(1, duration);
			if (next >= 1) {
				s.setProgress(1);
				s.setPlaying(false);
				return;
			}
			s.setProgress(next);
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, [
		playing,
		speed,
		duration
	]);
}
var SPEEDS = [
	.25,
	.5,
	1,
	2,
	4
];
function Timeline({ processId }) {
	const process = getProcess(processId);
	usePlayback(process.duration);
	const progress = useAppStore((s) => s.progress);
	const playing = useAppStore((s) => s.playing);
	const speed = useAppStore((s) => s.speed);
	const setPlaying = useAppStore((s) => s.setPlaying);
	const setProgress = useAppStore((s) => s.setProgress);
	const setSpeed = useAppStore((s) => s.setSpeed);
	const stage = stageAt(process, progress);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass rounded-xl p-3 md:p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[10px] tracking-[0.22em] text-fg-subtle",
					children: "4D TIMELINE"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-fg",
					children: stage.name
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-xs tabular-nums text-fg-muted",
					children: [(progress * process.duration).toFixed(1), "s"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "range",
				min: 0,
				max: 1e3,
				value: Math.round(progress * 1e3),
				"aria-label": "Scrub simulation timeline",
				onChange: (e) => {
					setPlaying(false);
					setProgress(Number(e.target.value) / 1e3);
				},
				className: "h-2 w-full cursor-pointer appearance-none rounded-full bg-surface-3 accent-accent"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 flex justify-between text-[10px] text-fg-subtle",
				children: process.stages.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("truncate px-0.5", s.id === stage.id ? "text-accent" : ""),
					onClick: () => setProgress(s.start + .01),
					children: s.name
				}, s.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "secondary",
						"aria-label": "Rewind",
						onClick: () => setProgress(Math.max(0, progress - .08)),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rewind, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						"aria-label": playing ? "Pause" : "Play",
						onClick: () => {
							if (progress >= 1) setProgress(0);
							setPlaying(!playing);
						},
						children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 ml-0.5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "secondary",
						"aria-label": "Reset",
						onClick: () => {
							setProgress(0);
							setPlaying(false);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "secondary",
						"aria-label": "Forward",
						onClick: () => setProgress(Math.min(1, progress + .08)),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FastForward, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "ml-auto flex items-center gap-1",
						children: SPEEDS.map((sp) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSpeed(sp),
							className: cn("h-9 min-w-11 rounded-md px-2 font-mono text-[11px]", speed === sp ? "bg-accent text-accent-fg" : "text-fg-muted hover:bg-surface-3"),
							children: [sp, "x"]
						}, sp))
					})
				]
			})
		]
	});
}
function LabFrame({ children, topicId, processId, explore, onExplorePick }) {
	const mobile = useIsMobile();
	const [left, setLeft] = (0, import_react.useState)(false);
	const [right, setRight] = (0, import_react.useState)(false);
	const setTopic = useAppStore((s) => s.setTopic);
	const current = processId ?? useAppStore((s) => s.selectedTopic);
	const mark = useProgress((s) => s.markExplored);
	const items = explore ?? TOPICS.map((t) => ({
		id: t.id,
		name: t.name
	}));
	const pick = (id) => {
		if (onExplorePick) onExplorePick(id);
		else {
			setTopic(id);
			mark(id);
		}
		setLeft(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-full bg-bg-deep",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden w-[260px] shrink-0 overflow-y-auto border-r border-border bg-surface/60 md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExploreList, {
					items,
					current,
					onPick: pick
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-w-0 flex-1",
				id: "bio-viewport",
				children: [
					children,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pointer-events-none absolute inset-x-0 top-3 z-10 flex justify-center px-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewerToolbar, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute bottom-3 left-3 right-3 z-10 md:left-4 md:right-4",
						children: processId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timeline, { processId }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniHint, {})
					}),
					mobile ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute bottom-28 left-3 right-3 z-10 flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "secondary",
							"aria-label": "Explore",
							onClick: () => setLeft(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "secondary",
							"aria-label": "Info",
							onClick: () => setRight(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-4" })
						})]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden w-[300px] shrink-0 overflow-hidden border-l border-border bg-surface/60 md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoPanel, { topicId })
			}),
			left ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				onClose: () => setLeft(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExploreList, {
					items,
					current,
					onPick: pick
				})
			}) : null,
			right ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				onClose: () => setRight(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoPanel, { topicId })
			}) : null
		]
	});
}
function MiniHint() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-center font-mono text-[10px] tracking-[0.2em] text-fg-subtle",
		children: "DRAG TO ORBIT · PINCH TO ZOOM · TAP STRUCTURES"
	});
}
function ExploreList({ items, current, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-2 pb-2 font-mono text-[10px] tracking-[0.22em] text-fg-subtle",
			children: "EXPLORE"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-0.5",
			children: items.map((item) => {
				const cat = TOPICS.find((t) => t.id === item.id)?.category;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onPick(item.id),
					className: cn("flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left text-sm", current === item.id ? "bg-accent/15 text-accent" : "text-fg-muted hover:bg-surface-3 hover:text-fg"),
					children: [item.name, cat ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] text-fg-subtle",
						children: CATEGORY_LABEL[cat]
					}) : null]
				}) }, item.id);
			})
		})]
	});
}
function Sheet({ children, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-20 bg-bg/50 md:hidden",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-x-0 bottom-0 max-h-[70vh] overflow-y-auto rounded-t-2xl bg-surface pb-16",
			onClick: (e) => e.stopPropagation(),
			children
		})
	});
}
//#endregion
export { LabFrame as t };
