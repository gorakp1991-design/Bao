//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D8AG1dYs.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/4d",
			"/ar",
			"/cell",
			"/dashboard",
			"/dna",
			"/four-d",
			"/human-body",
			"/lab",
			"/learn",
			"/neuron",
			"/plants",
			"/quiz",
			"/search",
			"/tutor"
		],
		preloads: [
			"/assets/index-BTS3mfAY.js",
			"/assets/link-j7cgWRc8.js",
			"/assets/preload-helper-C6NAzYlR.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BTS3mfAY.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CySwyYTK.js",
			"/assets/app-shell-DH1pb8Qg.js",
			"/assets/bio-part-BlFDbWtg.js",
			"/assets/dna-Cdtbnnes.js"
		]
	},
	"/4d": {
		filePath: "/workspace/src/routes/4d.tsx",
		children: void 0,
		preloads: ["/assets/4d-CmM489Y8.js"]
	},
	"/ar": {
		filePath: "/workspace/src/routes/ar.tsx",
		children: void 0,
		preloads: ["/assets/ar-DPj1izZI.js", "/assets/app-shell-DH1pb8Qg.js"]
	},
	"/cell": {
		filePath: "/workspace/src/routes/cell.tsx",
		children: void 0,
		preloads: [
			"/assets/cell-Ba37_GHc.js",
			"/assets/app-shell-DH1pb8Qg.js",
			"/assets/lab-frame-Bas4jDGg.js",
			"/assets/canvas-stage-wvH6YUrL.js",
			"/assets/model-registry-CuEtqBhr.js"
		]
	},
	"/dashboard": {
		filePath: "/workspace/src/routes/dashboard.tsx",
		children: void 0,
		preloads: ["/assets/dashboard-DCk1PYBd.js", "/assets/app-shell-DH1pb8Qg.js"]
	},
	"/dna": {
		filePath: "/workspace/src/routes/dna.tsx",
		children: void 0,
		preloads: [
			"/assets/dna-T1VvHnQO.js",
			"/assets/app-shell-DH1pb8Qg.js",
			"/assets/lab-frame-Bas4jDGg.js",
			"/assets/dna-Cdtbnnes.js",
			"/assets/canvas-stage-wvH6YUrL.js"
		]
	},
	"/four-d": {
		filePath: "/workspace/src/routes/four-d.tsx",
		children: void 0,
		preloads: [
			"/assets/four-d-BIFxtMrw.js",
			"/assets/app-shell-DH1pb8Qg.js",
			"/assets/lab-frame-Bas4jDGg.js",
			"/assets/canvas-stage-wvH6YUrL.js",
			"/assets/process-scene-B8Siay27.js"
		]
	},
	"/human-body": {
		filePath: "/workspace/src/routes/human-body.tsx",
		children: void 0,
		preloads: [
			"/assets/human-body-EyJL0n68.js",
			"/assets/app-shell-DH1pb8Qg.js",
			"/assets/lab-frame-Bas4jDGg.js",
			"/assets/canvas-stage-wvH6YUrL.js",
			"/assets/human-body-dBVp7Ihr.js"
		]
	},
	"/lab": {
		filePath: "/workspace/src/routes/lab.tsx",
		children: void 0,
		preloads: [
			"/assets/lab-CKKWQqrm.js",
			"/assets/app-shell-DH1pb8Qg.js",
			"/assets/lab-frame-Bas4jDGg.js",
			"/assets/canvas-stage-wvH6YUrL.js",
			"/assets/model-registry-CuEtqBhr.js"
		]
	},
	"/learn": {
		filePath: "/workspace/src/routes/learn.tsx",
		children: void 0,
		preloads: ["/assets/learn-BwVdlDMf.js", "/assets/app-shell-DH1pb8Qg.js"]
	},
	"/neuron": {
		filePath: "/workspace/src/routes/neuron.tsx",
		children: void 0,
		preloads: [
			"/assets/neuron-C60qV1Rj.js",
			"/assets/app-shell-DH1pb8Qg.js",
			"/assets/lab-frame-Bas4jDGg.js",
			"/assets/canvas-stage-wvH6YUrL.js",
			"/assets/process-scene-B8Siay27.js"
		]
	},
	"/plants": {
		filePath: "/workspace/src/routes/plants.tsx",
		children: void 0,
		preloads: [
			"/assets/plants-BTbMMGta.js",
			"/assets/app-shell-DH1pb8Qg.js",
			"/assets/lab-frame-Bas4jDGg.js",
			"/assets/canvas-stage-wvH6YUrL.js",
			"/assets/model-registry-CuEtqBhr.js",
			"/assets/process-scene-B8Siay27.js"
		]
	},
	"/quiz": {
		filePath: "/workspace/src/routes/quiz.tsx",
		children: void 0,
		preloads: [
			"/assets/quiz-DgynBKDs.js",
			"/assets/app-shell-DH1pb8Qg.js",
			"/assets/canvas-stage-wvH6YUrL.js",
			"/assets/model-registry-CuEtqBhr.js"
		]
	},
	"/search": {
		filePath: "/workspace/src/routes/search.tsx",
		children: void 0,
		preloads: ["/assets/search-BRs8F47O.js", "/assets/app-shell-DH1pb8Qg.js"]
	},
	"/tutor": {
		filePath: "/workspace/src/routes/tutor.tsx",
		children: void 0,
		preloads: ["/assets/tutor-Dq81CWJe.js", "/assets/app-shell-DH1pb8Qg.js"]
	}
} });
//#endregion
export { tsrStartManifest };
